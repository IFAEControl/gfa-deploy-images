#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 80 #32000
APORT = 442 #32001
IP='10.1.1.1'
IP='131.243.51.10'
print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)

gfa.adccontroller.set_adc_reset_pin(0)
gfa.adccontroller.set_adc_reset_pin(1)
gfa.adccontroller.set_adc_powerdown_pin(False)
gfa.adccontroller.reset_adc_controller()

gfa.adccontroller.adc_init_calib()
gfa.adccontroller.remote_get_status()
if gfa.adccontroller.status.init_status.state != 's_init':
    raise Exception('System should be at calibration')

# reset adc chip by spi
gfa.adccontroller.spi_write(0x0, 0x1)
time.sleep(0.1)
gfa.adccontroller.spi_write(0x0, 0x0)
time.sleep(0.1)

# configure serialization on adc
gfa.adccontroller.spi_write(0x46, 0x8801)

# set expected data pattern
gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)

# set adc to output sync pattern
time.sleep(0.1)
gfa.adccontroller.spi_write(0x45, 0x2)

# start align frame
gfa.adccontroller.adc_calib_align_frame()

# check it has finished aligning frame
for i in range(10):
    gfa.adccontroller.remote_get_status()
    if gfa.adccontroller.status.init_status.frame_aligned:
        break
else:
    raise Exception('Frame could not be aligned')

# align data
gfa.adccontroller.adc_calib_align_data()

# check it has finished aligning frame
# for i in range(10):
#     gfa.adccontroller.remote_get_status()
#     if gfa.adccontroller.status.init_status.frame_aligned:
#         break
# else:
#     raise Exception('Frame could not be aligned')

# gfa.adccontroller.remote_get_status()
# gfa.adccontroller.remote_get_init_rx_expected_pattern()
# gfa.adccontroller.remote_get_init_rx_data()
# print gfa.adccontroller.status

gfa.adccontroller.adc_calib_bitslip()

gfa.adccontroller.remote_get_status()
gfa.adccontroller.remote_get_init_rx_expected_pattern()
gfa.adccontroller.remote_get_init_rx_data()
print(gfa.adccontroller.status)


# remove pattern
gfa.adccontroller.spi_write(0x45, 0x0)

gfa.adccontroller.adc_stop_calib()



gfa.close()
