# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file './mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(886, 867)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout(self.frame_2)
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.plot_widget = QtWidgets.QWidget(self.frame_2)
        self.plot_widget.setStyleSheet("")
        self.plot_widget.setObjectName("plot_widget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.plot_widget)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.widget = QtWidgets.QStackedWidget(self.plot_widget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy)
        self.widget.setObjectName("widget")
        self.verticalLayout_2.addWidget(self.widget)
        self.horizontalLayout_5.addWidget(self.plot_widget)
        self.gridLayout.addWidget(self.frame_2, 0, 0, 1, 2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.actionTest = QtWidgets.QAction(MainWindow)
        self.actionTest.setObjectName("actionTest")
        self.actionAdvanced = QtWidgets.QAction(MainWindow)
        self.actionAdvanced.setObjectName("actionAdvanced")
        self.actionPlot_viewer = QtWidgets.QAction(MainWindow)
        self.actionPlot_viewer.setObjectName("actionPlot_viewer")
        self.actionApply_settings = QtWidgets.QAction(MainWindow)
        self.actionApply_settings.setObjectName("actionApply_settings")
        self.actionStop_monitoring = QtWidgets.QAction(MainWindow)
        self.actionStop_monitoring.setObjectName("actionStop_monitoring")
        self.actionStart_monitoring = QtWidgets.QAction(MainWindow)
        self.actionStart_monitoring.setObjectName("actionStart_monitoring")
        self.actionConnect = QtWidgets.QAction(MainWindow)
        self.actionConnect.setObjectName("actionConnect")
        self.actionDisconnect = QtWidgets.QAction(MainWindow)
        self.actionDisconnect.setObjectName("actionDisconnect")
        self.actionGet_settings = QtWidgets.QAction(MainWindow)
        self.actionGet_settings.setObjectName("actionGet_settings")

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.actionTest.setText(_translate("MainWindow", "Test"))
        self.actionAdvanced.setText(_translate("MainWindow", "Advanced"))
        self.actionPlot_viewer.setText(_translate("MainWindow", "Plot viewer"))
        self.actionApply_settings.setText(_translate("MainWindow", "Apply settings"))
        self.actionStop_monitoring.setText(_translate("MainWindow", "Stop monitoring"))
        self.actionStart_monitoring.setText(_translate("MainWindow", "Start monitoring"))
        self.actionConnect.setText(_translate("MainWindow", "Connect"))
        self.actionDisconnect.setText(_translate("MainWindow", "Disconnect"))
        self.actionGet_settings.setText(_translate("MainWindow", "Get settings"))

