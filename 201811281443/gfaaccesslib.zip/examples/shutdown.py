#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os

import argparse

__author__ = 'otger'

POWERDOWN_TIME_STEP_MS = 250

IP_EMBEDDED = '172.16.17.141'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
IP='131.243.51.10'
PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
parser.add_argument("-p", "--programmed-values", action="store_true", help="Do not program default values, "
                                                                          "leave the ones on the device")
parser.add_argument("--display", action="store_true", help="display data received graphically")
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT)

# This is not needed anymore on newest boards
## Due to an error on schematics, VSS must be disables through dac
#gfa.powercontroller.remote_get_configured_voltages()
#gfa.powercontroller.voltages.VSS.volts = 0
#gfa.powercontroller.remote_set_voltages()
time.sleep(1.0)
gfa.powercontroller.powerdown_timing_ms = POWERDOWN_TIME_STEP_MS
gfa.powercontroller.remote_set_phase_timing()

gfa.exposecontroller.remote_power_down()
time.sleep(4*POWERDOWN_TIME_STEP_MS/1000)

gfa.exposecontroller.remote_get_status()
print(gfa.exposecontroller.status)

gfa.powercontroller.remote_get_enables()
print(gfa.powercontroller.enables)

