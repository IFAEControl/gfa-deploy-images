#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import sys
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)

if len(sys.argv) == 3:
    address = int(sys.argv[1])
    value = int(sys.argv[2])
else:
    address = 0x0
    value = 0x0000
print("Write {0} to {1}".format(hex(value), hex(address)))
gfa.adccontroller.spi_write(address, value)

gfa.close()
