import sys
import json
from threading import Thread
from datetime import datetime

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QSizePolicy
from guiqwt.styles import style_generator
from guiqwt.builder import make
from guiqwt.plot import CurveDialog

import numpy as np

from gfaaccesslib.gfa import GFA
from mainwindow_ui import Ui_MainWindow


def generate_styles(num_curves):
    styles = style_generator()
    return [next(styles) for _ in range(num_curves)]


def make_curves(styles, sensors):
    curves = []
    for s, sensor in zip(styles, sensors):
        l = sensor["label"]
        c = make.curve([], [], color=s[0], linestyle=s[1:], title=l)
        curves.append(c)

    return curves


def create_curves_from_config():
    sensors = [{"label": "XADC"}, {"label": "HOTPELTIER"}, {"label": "COLDPELTIER"}, {"label": "AMBIENT"}, {"label": "FILTER"}]
    num_sensors = len(sensors)
    styles = generate_styles(num_sensors)
    return make_curves(styles, sensors)

def create_plot_from_cfg(main):
    title = "GFA TEMPERATURES"
    xlabel = "TIME"
    ylabel = "TEMP"
    xunit = "s"
    yunit = "ºC"
    return Plot(main, title, ylabel, xlabel, yunit, xunit)


def set_size_policy(widget, v_policy, h_policy):
    policy = QSizePolicy(v_policy, h_policy)
    widget.setSizePolicy(policy)


def add_curves_to_plot(plot, curves):
    for c in curves:
        plot.add(c)


class Plot(QtWidgets.QWidget):

    def __init__(self, main, title, ylabel, xlabel, yunit, xunit):
        super(Plot, self).__init__()

        self._plot = CurveDialog(toolbar=True, wintitle=title,
                                 options=dict(ylabel=ylabel, yunit=yunit,
                                              xlabel=xlabel, xunit=xunit))

        self._plot.get_itemlist_panel().show()

        set_size_policy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        set_size_policy(self._plot, QSizePolicy.Expanding, QSizePolicy.Expanding)

        QtCore.QMetaObject.connectSlotsByName(self)
        self.setObjectName("Plot")

        main.widget.addWidget(self._plot)

    def add(self, item):
        self._plot.get_plot().add_item(item)


class Window(QtWidgets.QMainWindow):
    update_signal = QtCore.pyqtSignal(float, dict)

    def __init__(self):
        super(Window, self).__init__()

        # First create the main window
        self._main_window = Ui_MainWindow()
        self._main_window.setupUi(self)

        self._g = GFA("172.16.17.82", 32000, 32001)
        self._g.async.add_sensors_reading_callback(self.sensors_callback)
        self._start = datetime.now()

        # Signals and slots connections
        self.update_signal.connect(self._on_signal_update)

        self._curves = create_curves_from_config()
        self._plot = create_plot_from_cfg(self._main_window)
        add_curves_to_plot(self._plot, self._curves)

        # Finally start the thread
        #self._stop_reading = False
        #self._reader_thread = Thread(target=self._data_reader)
        #self._reader_thread.start()

    @QtCore.pyqtSlot()
    def closeEvent(self, event):
        self._g.close()
        #self._stop_reading = True
        #self._reader_thread.join()
        #event.accept()
        #g.close()

    @QtCore.pyqtSlot(float, dict)
    def _on_signal_update(self, offset, data):
        s = ["xadc_temp", "sensor0t_value", "sensor1t_value", "sensor2t_value", "sensor3t_value"]
        for i, t in zip(self._curves, s):
            val = data[t]
            x, y = i.get_data()
            x = np.append(x, offset)
            y = np.append(y, val)
            i.set_data(x, y)

    def sensors_callback(self, header, data):
        if isinstance(data, bytes):
            data = data.decode('UTF-8')

        j = json.loads(data)
        print(j)
        offset = (datetime.now() - self._start).total_seconds()
        self.update_signal.emit(offset, j)


if __name__ == "__main__":
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts)
    app = QtWidgets.QApplication(sys.argv)
    form = Window()
    form.show()
    ret = app.exec_()
    sys.exit(ret)

