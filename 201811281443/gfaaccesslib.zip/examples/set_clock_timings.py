#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import sys
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)
gfa.clockmanager.remote_get_clock_timings()
# gfa.clockmanager.time_conf.hor_acq =
# gfa.clockmanager.time_conf.hor_acq_skip =
# gfa.clockmanager.time_conf.hor_acq =
# gfa.clockmanager.time_conf.hor_del =
# gfa.clockmanager.time_conf.hor_del_skip =
# gfa.clockmanager.time_conf.hor_overlap =
# gfa.clockmanager.time_conf.hor_overlap_skip =
# gfa.clockmanager.time_conf.hor_postrg =
# gfa.clockmanager.time_conf.hor_postrg_skip =
# gfa.clockmanager.time_conf.hor_prerg =
# gfa.clockmanager.time_conf.hor_prerg_skip =
# gfa.clockmanager.time_conf.hor_rg =
# gfa.clockmanager.time_conf.hor_rg_skip =
# gfa.clockmanager.time_conf.vert_tdgr =
# gfa.clockmanager.time_conf.vert_tdrg =
# gfa.clockmanager.time_conf.vert_tdrt =
# gfa.clockmanager.time_conf.vert_tdtr =
# gfa.clockmanager.time_conf.vert_toi =

gfa.clockmanager.remote_set_clock_timings()
gfa.clockmanager.remote_get_clock_timings()
print("Current clock timings:")
print(gfa.clockmanager.time_conf)

gfa.close()
