import numpy as np
from functools import reduce


class RawDataManager(object):
    def __init__(self, amplifiers=4):
        self._images = {}
        self._row_callbacks = []
        self.num_amps = amplifiers

    def rem_image(self, image_id):
        return self._images.pop(image_id, None)

    def get_image(self, image_id):
        im = self._images.get(image_id, None)
        if im is None:
            im = RawDataImage(image_id, parent=self)
            self._images[image_id] = im
        return im

    def list_images(self):
        return self._images.keys()

    # def register_row_callback(self, callback, kwargs={}):
    #     """
    #     register a function to be executed as a callback when a new row is ready to be accessed
    #     :param callback: function with at least one argument called amp_rows
    #     :param kwargs: any other argument the function may need
    #     :return:
    #     """
    #     self._row_callbacks.append((callback, kwargs))
    #
    # def exec_row_callbacks(self, amp_rows):
    #     """
    #     execute sequentially all registered callbacks
    #     :param amp_rows: list of RawDataAmpRow
    #     :return:
    #     """
    #     for cb, kwargs in self._row_callbacks:
    #         cb(amp_rows=amp_rows, **kwargs)


class RawDataImage(object):
    def __init__(self, image_id, parent):
        self._image_id = image_id
        self.parent = parent
        self.amplifiers = []
        for ix in range(self.parent.num_amps):
            self.amplifiers.append(RawDataAmplifier(ix, parent=self))
        self._meta = {}

    @property
    def meta(self):
        return self._meta

    def _get_im_id(self):
        return self._image_id
    image_id = property(_get_im_id)

    def add_meta(self, key, value):
        self._meta[key] = value

    def update_meta(self, meta_dict):
        self._meta.update(meta_dict)

    def get_rows(self, ccd_row_init, ccd_row_end):
        """
        get a set of rows
        :param ccd_row_init:
        :param ccd_row_end:
        :return:
        """
        return [amp.get_rows(ccd_row_init, ccd_row_end) for amp in self.amplifiers]

    def get_ampdata(self, image_id):
        """
            Returns 4 numpy arrays one per amplifier with 0,0 being pixel closest to the readout amplifier.
        """
        rval = []
        for amp in self.amplifiers:
            if not amp.rows:
                continue
            if amp.check_rows_shape() is False:
                raise Exception("Not all rows have same size")
            data = np.vstack([el.data for el in amp.rows])
            # data = np.array(amp.rows[0].data)
            # for j in range(1, len(amp.rows)):
            #     data = np.vstack((data, amp.rows[j].data))
            rval.append(data)
        return rval

    def get_im(self):
        images = []

        from scipy.misc import toimage
        for amp in self.amplifiers:
            if not amp.rows:
                continue
            if amp.check_rows_shape() is False:
                raise Exception("Not all rows have same size")
            ndata = np.concatenate(amp.data)
            ndata.shape = len(amp.rows), amp.rows[0].data.size
            images.append(toimage(ndata))

        return images
    
    def show_im(self):
        for im in self.get_im():
            im.show()            

    def _check_fake_2(self):
        # All amplifiers and rows should have same size
        size = self.amplifiers[0].rows[0].data.size

        # not all amplifiers have same data
        for ix, amp in enumerate(self.amplifiers):
            comparer = np.ones(size) * ix * 1000
            for row in amp.rows:
                if np.array_equal(comparer, row.data) is False:
                    # print row.data
                    raise Exception('Error on fake image')
        return True

    def _check_fake_4(self):
        # All amplifiers and rows should have same size
        size = self.amplifiers[0].rows[0].data.size

        # not all amplifiers have same data
        cmp_array = np.empty(size)
        for ix, amp in enumerate(self.amplifiers):
            for row in amp.rows:
                cmp_array.fill(row.meta.get("ccd_row_num", -1))
                comparer = np.array(cmp_array, dtype=int)
                if np.array_equal(comparer, row.data) is False:
                    print(row.meta)
                    print(row.data)
                    print(comparer)
                    raise Exception('Error on fake image')
        return True

    def check_fake_im(self, mode):
        # -----------------------------------------------------------------------------
        # -- datamode
        # --  0: output zeros
        # --  1: output ones
        # --  2: e: 0, f: 1000, g: 2000, h: 3000
        # --  3: e: row + col, f: row + col + 1000, g: row + col + 2000, h: row + col + 3000
        # --  4: pixel value = row
        # --  5: pixel value = column
        # --  6: pixel value = row
        # x
        # col
        # --  7: output is a
        # checker
        # 2
        # x2(TBI)
        # -----------------------------------------------------------------------------

        # All amplifiers and rows should have same size
        size = self.amplifiers[0].rows[0].data.size

        if mode == 0:
            comparer = np.zeros(size)
        elif mode == 1:
            comparer = np.ones(size)
        elif mode == 2:
            return self._check_fake_2()
        elif mode == 3:
            return self._check_fake_3()
        elif mode == 4:
            return self._check_fake_4()
        elif mode == 5:
            comparer = np.array(range(1, size + 1))
            for amp in self.amplifiers:
                for row in amp.rows:
                    inc_1 = [y == (x + 1) for x, y in zip(row.data, row.data[1:])]
                    product = reduce((lambda x, y: x * y), inc_1)
                    if product is False:
                        print("row is not monotonically increasing")
        else:
            raise Exception('Bad mode')
        rowerr = []
        for amp in self.amplifiers:
            for row in amp.rows:
                if np.array_equal(comparer, row.data) is False:
                    print(row.meta, len(row.data), row.data)
                    rowerr = row.data
        if len(rowerr) > 0:
            for x in rowerr:
                print(x)
            raise Exception('Error on fake image')
        return True


class RawDataAmplifier(object):
    def __init__(self, amp_id, parent):
        self.amp_id = amp_id
        self.keywords = {}
        self.rows = []
        self.parent = parent

    def _get_data(self):
        return [row.data for row in self.rows]
    data = property(_get_data)

    def _get_matrix(self):
        return np.matrix(self.data)
    matrix = property(_get_matrix)

    def check_rows_shape(self):
        sizes = [row.data.size for row in self.rows]
        return max(sizes) == min(sizes)

    def get_im_shape(self):
        sizes = [row.data.size for row in self.rows]
        return len(self.rows), min(sizes)

    def add_row(self, data, meta):
        """
        add a new row of raw data
        :param data: list of uints
        :param meta: dictionary of metadata. At least it must contains 'image_id', 'row_num', 'row_width'
        :return: RawDataAmpRow instance
        """
        row = RawDataAmpRow(data, meta)
        self.rows.append(row)
        return row

    def get_rows(self, ccd_row_init, ccd_row_end):
        """
        Return list of rows
        :param row_init: Index of lowest row to return. Index referred to ccd position
        :param row_end: Index of highest row to return. Index referred to ccd position
        :return: list of RawDataRow
        """
        return [el for el in self.rows if (not el.ccd_row > ccd_row_end and not el.ccd_row < ccd_row_init)]


class RawDataAmpRow(object):
    def __init__(self, data, meta={}):
        self.data = np.array(data)
        self.meta = meta

    def _get_ccd_row(self):
        return self.meta.get('ccd_row_num', -1)

    ccd_row = property(_get_ccd_row)

if __name__ == '__main__':


    def callback1(amp_rows):
        print('callback 1')

    def callbackwithargs(caller_id, amp_rows):
        print("callback with arguments: {0} - {1}".format(caller_id, amp_rows))

    man = RawDataManager()
    man.register_row_callback(callback=callback1)
    man.register_row_callback(callback=callbackwithargs, kwargs={'caller_id': 1})

    image = man.get_image(1)
    rows = []
    for amp in image.amplifiers:
        r = amp.add_row(data=range(5), meta={})
        rows.append(r)

    man.exec_row_callbacks(rows)
