from PyQt5.QtWidgets import QFrame

from .base import Widget
from .ui import pwm_ui


class PWM(Widget):

    def __init__(self, gfa):
        self._gfa = gfa

        self._pwm_frame = QFrame()
        self._pwm_widget = alarms_ui.Ui_Frame()
        self._pwm_widget.setupUi(self._pwm_frame)

    def show(self):
        self._pwm_frame.show()
