#!/bin/bash

for i in *.ui; do
    file_name=$(echo -n "$i" | rev | cut -d . -f 2- | rev)_ui.py
    pyuic5 "$i" -o "$file_name"
done
