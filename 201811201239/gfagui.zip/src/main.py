#!/usr/bin/python3
# -*- coding: utf-8 -*-


from PyQt5 import QtWidgets, QtCore

import sys
import traceback

import gui
import coloredlogs
from pyqt_tools import messages

coloredlogs.install(level='DEBUG',  fmt='%(asctime)s,%(msecs)03d %(name)s[%(process)d] %(levelname)s %(message)s')

if __name__ == "__main__":
    try:
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_ShareOpenGLContexts)
        app = QtWidgets.QApplication(sys.argv)
        form = gui.MainWindow()
        form.show()
        ret = app.exec_()
        form.gfa.close()
        sys.exit(ret)
    except Exception as ex:
        traceback.print_tb(ex)
        msg = "Can not run client: {}".format(ex)
        messages.show_fatal(msg, "Error during startup")
