# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file './src/widgets/ui/pwm.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Frame(object):
    def setupUi(self, Frame):
        Frame.setObjectName("Frame")
        Frame.resize(458, 178)
        self.horizontalLayout = QtWidgets.QHBoxLayout(Frame)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.widget = QtWidgets.QWidget(Frame)
        self.widget.setObjectName("widget")
        self.gridLayout = QtWidgets.QGridLayout(self.widget)
        self.gridLayout.setObjectName("gridLayout")
        self.high_clocks = QtWidgets.QSpinBox(self.widget)
        self.high_clocks.setObjectName("high_clocks")
        self.gridLayout.addWidget(self.high_clocks, 1, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.widget)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 0, 2, 1, 1)
        self.frequency = QtWidgets.QSpinBox(self.widget)
        self.frequency.setObjectName("frequency")
        self.gridLayout.addWidget(self.frequency, 0, 1, 1, 1)
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.duty_cycle = QtWidgets.QSpinBox(self.widget)
        self.duty_cycle.setObjectName("duty_cycle")
        self.gridLayout.addWidget(self.duty_cycle, 0, 3, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.widget)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 1, 2, 1, 1)
        self.low_clocks = QtWidgets.QSpinBox(self.widget)
        self.low_clocks.setObjectName("low_clocks")
        self.gridLayout.addWidget(self.low_clocks, 1, 3, 1, 1)
        self.get = QtWidgets.QPushButton(self.widget)
        self.get.setObjectName("get")
        self.gridLayout.addWidget(self.get, 2, 1, 1, 1)
        self.set = QtWidgets.QPushButton(self.widget)
        self.set.setObjectName("set")
        self.gridLayout.addWidget(self.set, 2, 0, 1, 1)
        self.horizontalLayout.addWidget(self.widget)

        self.retranslateUi(Frame)
        QtCore.QMetaObject.connectSlotsByName(Frame)

    def retranslateUi(self, Frame):
        _translate = QtCore.QCoreApplication.translate
        Frame.setWindowTitle(_translate("Frame", "PWM"))
        self.label_3.setText(_translate("Frame", "Duty Cycle:"))
        self.label.setText(_translate("Frame", "Frequency:"))
        self.label_2.setText(_translate("Frame", "High clock:"))
        self.label_4.setText(_translate("Frame", "Low clocks:"))
        self.get.setText(_translate("Frame", "GET"))
        self.set.setText(_translate("Frame", "SET"))

