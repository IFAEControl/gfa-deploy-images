#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
from pprint import pprint
import json
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
IP='172.16.17.82'
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

"""
Example of an exposure which uses all functionalities of the TimeRegisters

Instead of using a simple wait statement, we will trigger a timer and wait until that timer value is >= than 
another register.

There are 32 TR available.

TR configuration
    - TR0 : total time of both exposures
    - TR1 : time spent clearing the CCD
    - TR2 : time spent exposing
    - TR3 : time spent transferring image to storage
    - TR4 : time spent reading storage
    - TR5 : second exposing time, while storage is being read
    - TR28 : Time spent reading storage
    - TR29 : Copy of transfer time
    - TR30 : Copy of the exposure time
    - TR31 : Desired time exposing



"""


# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()

    #################################################################################
    # Acquisition definition
    #################################################################################


    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:
    g = gfa.clockmanager.stack
    # Clear stack
    g.clear()
    # Load desired expose time to TR31
    # We will check expose time with 1us resolution and we want to expose it for 4 seconds -> 4000000
    # Doing this it would allow us to run on a loop and by writing to register 31 externally change the exposing
    # time without breaking the loop
    g.add_tr_load_value(31, 4000000)
    # Enable all amplifiers and both image and storage vertical clocks
    g.add_set_modes_cmd(True, True, True, True)
    # First we clear all TimeRegisters
    g.add_tr_clear(0, all=True)
    g.add_tr_start_timer(0, resolution='1us')  # Full duration of both acquisitions
    g.add_tr_start_timer(1, resolution='10ns')  # Duration of dumping all rows of the CCD
    # Clear CCD : Dump all rows
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    # Stop timer for clear ccd
    g.add_tr_stop_timer(1)
    # First exposing time starts here. Start timer 2
    g.add_tr_start_timer(2, resolution='1us')
    # We start the new_exposure here, otherwise, it counts the dump of rows to the rows processed counter
    # If we don't set an image_id, it will update its internal counter
    g.add_new_image_cmd()

    # We wait until timer 2 is >= than TR31
    g.add_wait_until_tra_goet_trb_cmd(address_tra=2, address_trb=31)
    # we copy value of timer 2 to TR 30
    g.add_tr_copy_trb_2_tra(tra_address=30, trb_address=2)

    # Start timer 3 to check how long it takes to transfer image to storage
    g.add_tr_start_timer(3)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.storage_rows)
    g.add_tr_stop_timer(3)
    g.add_tr_copy_trb_2_tra(29, 3)
    # We start the timer for two reasons, to start counting exposure time for next exposure and to know how long
    # it takes to read the storage
    g.add_tr_clear(2, all=False)
    g.add_tr_start_timer(2, resolution='1us')
    # When reading we don't want to move image section vertically, only storage section
    g.add_set_modes_cmd(eh_en=True, fg_en=True, image_en=False, storage_en=True)
    g.add_read_rows_cmd(gfa.clockmanager.geom_conf.image_rows)
    # enable vertical movement onimage again
    g.add_set_modes_cmd(eh_en=True, fg_en=True, image_en=True, storage_en=True)
    # Do not stop the timer, we are counting exposure time of second exposure
    # g.add_tr_stop_timer(4)
    g.add_tr_copy_trb_2_tra(28, 2)
    # we declare the new exposure.
    g.add_new_image_cmd()
    # we wait until image section has been exposed for desired expose time
    g.add_wait_until_tra_goet_trb_cmd(2, 31)
    # Copy time exposed to register 30
    g.add_tr_copy_trb_2_tra(2, 30)
    # we copy value of timer 2 to TR 30
    g.add_tr_copy_trb_2_tra(tra_address=30, trb_address=2)

    # Start timer 3 to check how long it takes to transfer image to storage
    g.add_tr_start_timer(3)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.storage_rows)
    g.add_tr_stop_timer(3)
    g.add_tr_copy_trb_2_tra(29, 3)
    # We start the timer for two reasons, to start counting exposure time for next exposure and to know how long
    # it takes to read the storage
    g.add_tr_clear(2, all=False)
    g.add_tr_start_timer(2, resolution='1us')
    # When reading we don't want to move image section vertically, only storage section
    g.add_set_modes_cmd(eh_en=True, fg_en=True, image_en=False, storage_en=True)
    g.add_read_rows_cmd(gfa.clockmanager.geom_conf.image_rows)
    # enable vertical movement onimage again
    g.add_set_modes_cmd(eh_en=True, fg_en=True, image_en=True, storage_en=True)
    # Do not stop the timer, we are counting exposure time of second exposure
    # g.add_tr_stop_timer(4)
    g.add_tr_copy_trb_2_tra(28, 2)

    # Finish second acquisition
    g.add_none_cmd()

    # Stack can be printed so we can see its contents and also translates its commands
    # to human
    print('Exposure stack contents: {0}'.format(g))

    # Then we have to set to GFA
    gfa.clockmanager.remote_set_stack_contents()

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)


    def print_meta(header, jsondata):
        log.info("Received end of exposure:")
        log.info(header)
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)
        pprint(j)
        log.info(j)

    gfa.async.add_end_image_callback(print_meta)
    
    acq_lock = GFAExposureLock()
    gfa.async.add_end_image_callback(acq_lock.async_callback_release)
    
    acq_lock.acquire()
    print('acquired')

    # So we can expose
    gfa.exposecontroller.remote_start_stack_exec()
    
    # we wait, that should be done by registering at an async message (TBI)
    acq_lock.acquire()
    print('acquired')
    acq_lock.release()
    print('released')

    acq_lock.acquire()
    print('acquired')

    # So we can expose
    gfa.exposecontroller.remote_start_stack_exec()

    # we wait, that should be done by registering at an async message (TBI)
    acq_lock.acquire()
    print('acquired')
    acq_lock.release()
    print('released')



    gfa.buffers.remote_get_buffers_status()
    print(gfa.buffers.status)
    gfa.buffers.remote_clear_buffers()
    #  gfa.buffers.remote_get_buffers_status()
    #  print gfa.buffers.status

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
