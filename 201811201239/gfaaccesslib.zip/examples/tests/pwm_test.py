#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 7/8/18
# @Author  : Otger Ballester (otger@ifae.es)
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import argparse
import time
import os


IP = "172.16.17.82"
IP = "10.1.1.1"
IP = "131.243.51.228"

PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)


def pp(ans):
    for k in sorted(ans.answer.keys()):
        print("{}: {}".format(k, ans.answer[k]))


print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT)

ans = gfa.telemetry.remote_force_pwm(duty_100=40, freq_hz=5000)
pp(ans)


gfa.close()