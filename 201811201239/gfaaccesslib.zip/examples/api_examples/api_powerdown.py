#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 7/10/18
# @Author  : Otger Ballester (otger@ifae.es)
#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.api import GFAApi
import time
from gfaaccesslib.logger import log, formatter
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

IP='10.1.1.1'
print("Connecting to GFAApi @{0}".format(IP))
log.info('Configured GFAApi to ip {0}'.format(IP))

# We want to receive data (which is sent through async path), so we must enable sync
api = GFAApi(IP, True)
try:
    ans = api.get_status()
    print(ans)
    api.bias_powerdown()
finally:

    api.close()