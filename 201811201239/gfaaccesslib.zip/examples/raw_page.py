#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
from gfaaccesslib.modules.memorydump import MemoryDump
import time
import sys
import os

__author__ = 'otger'

IP = os.environ.get('GFA_IP', '140.252.52.122')
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))

gfa = GFA(IP, PORT, APORT)
ans = gfa.buffers.remote_get_memory_dump(0, 400)
for i in range(10):
	print(gfa.buffers.mem_dump_manager[0][i].data.as_base64())

#print("Data Page Number", ans.get_ans('page_array'))
gfa.close()
