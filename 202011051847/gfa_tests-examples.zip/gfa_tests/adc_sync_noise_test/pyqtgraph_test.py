#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" A simple python script

"""
__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2020'
__date__ = '27/04/2020'
__credits__ = ['Otger Ballester', ]
__license__ = 'GPL'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

from pickle import load
import pyqtgraph as pg
from gfafunctionality.raws import RawRepresentation
from time import sleep
from PyQt5.QtCore import QCoreApplication, Qt
from PyQt5.QtWidgets import QApplication
import sys

QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
app = QApplication(sys.argv)

file_name = "20200311141738/images/0000_image.pickle"
if len(sys.argv) == 2:
    file_name = sys.argv[1]

f = open(file_name, "rb")
o = load(f)

im = o
raw = RawRepresentation(im)
m = raw.get_matrix()
pg.image(m)


ret = app.exec_()
