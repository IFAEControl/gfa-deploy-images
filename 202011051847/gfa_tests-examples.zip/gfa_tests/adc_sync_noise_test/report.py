#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np
import datetime
from itertools import groupby

""" A python script to process information of the adc_sync_noise test and generate a report in html

"""
__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2020'
__date__ = '15/03/2020'
__credits__ = ['Otger Ballester', ]
__license__ = 'GPL'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

THRESHOLD = 10
MID_THRESHOLD = 2500


class DataAnalysis(object):
    def __init__(self, file_path, threshold=THRESHOLD, mid_threshold=MID_THRESHOLD):
        self.data_file_path = file_path
        self.threshold = threshold
        self.mid_threshold = mid_threshold
        self.data = None
        self.header_lines = None
        self.header = None

        self.load_and_process()

    @property
    def info(self):
        return {
            'events': len(self.data),
            'threshold': self.threshold,
            'mid_threshold': self.mid_threshold
        }

    def load_and_process(self):
        self.load_file()
        self.process_header()

    def load_file(self):
        data = []
        self.header_lines = []
        with open(self.data_file_path) as df:
            for line in df:
                if not line.startswith('#'):
                    data.append([float(x) for x in line.split(',')])
                else:
                    self.header_lines.append(line)
        self.data = np.array(data)

    def process_header(self):
        ## ADC Synchronize Noise Test
        ## Started on: 12/03/2020 10:57:13
        ## GFA API: {'version': '0.6'}
        ## GFA FW versions: {'firmware': '2018111501', 'firmware_hash': '60d9e61', 'lib': 'unstaged-files-build-202002191203', 'module': '182aaf25e0c28e65dc4c4ff0f3cbfb18acaac9b3', 'server': 'ed2222d2131940a1248ad2a7c0c017da04511805'}
        ## GFA MAC address: {'mac': '54:10:ec:92:5d:27'}
        self.header = {}
        for line in self.header_lines:
            try:
                if line.startswith('## Started on: '):
                    self.header['started_on_txt'] = line[15:-1]
                    self.header['started_on_dt'] = datetime.datetime.strptime(line[15:-1], "%d/%m/%Y %H:%M:%S")
                    self.header['test_id'] = self.header['started_on_dt'].strftime("%Y%m%d%H%M%S")
                    continue
                if line.startswith('## GFA API:'):
                    self.header['gfa_api_version'] = eval(line[12:-1])
                    continue
                if line.startswith('## GFA FW versions:'):
                    self.header['gfa_fw_versions'] = eval(line[20:-1])
                    continue
                if line.startswith('## GFA MAC address:'):
                    self.header['gfa_mac_addr'] = eval(line[20:-1])
                    continue
            except:
                print("Error while parsing header line: '{}'".format(line))
        self.header['num_of_loops'] = self.data.shape[0]

    def get_prescan(self, amp=0):
        """if amp == 0 it returns prescan of all amps. if amp in [1,2,3,4] it returns the prescan of selected amp"""
        if amp == 0:
            return self.prescans
        if amp in [1, 2, 3, 4]:
            return self.data[:, amp]
        raise Exception("Invalid amp value")

    def get_overscan(self, amp=0):
        """if amp == 0 it returns overscan of all amps. if amp in [1,2,3,4] it returns the overscan of selected amp"""
        if amp == 0:
            return self.overscans
        if amp in [1, 2, 3, 4]:
            return self.data[:, amp + 4]
        raise Exception("Invalid amp value")

    @property
    def overscans(self):
        return self.data[:, 5:9]

    @property
    def prescans(self):
        return self.data[:, 1:5]

    @property
    def pre_and_overscan(self):
        return self.data[:, 1:9]

    def _get_masks(self, events):
        if events.shape[1] == 4:
            mask_amp1_ok = events[:, 0] <= self.threshold
            mask_amp1_fail = events[:, 0] > self.threshold
            mask_amp2_ok = events[:, 1] <= self.threshold
            mask_amp2_fail = events[:, 1] > self.threshold
            mask_amp3_ok = events[:, 2] <= self.threshold
            mask_amp3_fail = events[:, 2] > self.threshold
            mask_amp4_ok = events[:, 3] <= self.threshold
            mask_amp4_fail = events[:, 3] > self.threshold

        elif events.shape[1] == 8:
            mask_amp1_ok = (events[:, 0] <= self.threshold) & (events[:, 4] <= self.threshold)
            mask_amp1_fail = (events[:, 0] > self.threshold) | (events[:, 4] > self.threshold)
            mask_amp2_ok = (events[:, 1] <= self.threshold) & (events[:, 5] <= self.threshold)
            mask_amp2_fail = (events[:, 1] > self.threshold) | (events[:, 5] > self.threshold)
            mask_amp3_ok = (events[:, 2] <= self.threshold) & (events[:, 6] <= self.threshold)
            mask_amp3_fail = (events[:, 2] > self.threshold) | (events[:, 6] > self.threshold)
            mask_amp4_ok = (events[:, 3] <= self.threshold) & (events[:, 7] <= self.threshold)
            mask_amp4_fail = (events[:, 3] > self.threshold) | (events[:, 7] > self.threshold)
        else:
            print("wrong events shape: {}".format(events.shape))
            return

        all_below_cond = mask_amp1_ok & mask_amp2_ok & mask_amp3_ok & mask_amp4_ok

        one_amp_below_cond = (mask_amp1_ok & mask_amp2_fail & mask_amp3_fail & mask_amp4_fail) | \
                             (mask_amp1_fail & mask_amp2_ok & mask_amp3_fail & mask_amp4_fail) | \
                             (mask_amp1_fail & mask_amp2_fail & mask_amp3_ok & mask_amp4_fail) | \
                             (mask_amp1_fail & mask_amp2_fail & mask_amp3_fail & mask_amp4_ok)

        two_amp_below_cond = (mask_amp1_ok & mask_amp2_ok & mask_amp3_fail & mask_amp4_fail) | \
                             (mask_amp1_ok & mask_amp2_fail & mask_amp3_ok & mask_amp4_fail) | \
                             (mask_amp1_ok & mask_amp2_fail & mask_amp3_fail & mask_amp4_ok) | \
                             (mask_amp1_fail & mask_amp2_ok & mask_amp3_ok & mask_amp4_fail) | \
                             (mask_amp1_fail & mask_amp2_ok & mask_amp3_fail & mask_amp4_ok) | \
                             (mask_amp1_fail & mask_amp2_fail & mask_amp3_ok & mask_amp4_ok)

        three_amp_below_cond = (mask_amp1_fail & mask_amp2_ok & mask_amp3_ok & mask_amp4_ok) | \
                               (mask_amp1_ok & mask_amp2_fail & mask_amp3_ok & mask_amp4_ok) | \
                               (mask_amp1_ok & mask_amp2_ok & mask_amp3_fail & mask_amp4_ok) | \
                               (mask_amp1_ok & mask_amp2_ok & mask_amp3_ok & mask_amp4_fail)
        all_above_cond = mask_amp1_fail & mask_amp2_fail & mask_amp3_fail & mask_amp4_fail

        return {
            'all_below_cond': all_below_cond,
            'one_amp_below_cond': one_amp_below_cond,
            'two_amp_below_cond': two_amp_below_cond,
            'three_amp_below_cond': three_amp_below_cond,
            'all_above_cond': all_above_cond
        }

    def _check_by_amps(self, events):
        """Return the statistic of events that are below and above the threshold
        if events.shape = (x, 4) means that we are only checking overscans or prescans
        if events.shape = (x, 8) means that we are checking both overscans and prescans
        """
        masks = self._get_masks(events)
        allAmpBelow = events[masks['all_below_cond']]
        allAmpAbove = events[masks['all_above_cond']]
        oneAmpBelow = events[masks['one_amp_below_cond']]

        twoAmpBelow = events[masks['two_amp_below_cond']]
        threeAmpBelow = events[masks['three_amp_below_cond']]

        # all_below_consecutive_events = [(k, sum(1 for i in g)) for k, g in groupby(allAmpBelow)]
        info = {
            'counts': {
                'all_below': len(allAmpBelow),
                'one_amp_below': len(oneAmpBelow),
                'two_amp_below': len(twoAmpBelow),
                'three_amp_below': len(threeAmpBelow),
                'all_above': len(allAmpAbove)
            },
            'indexes': self._masks_to_indexes(masks)

        }
        # print("Num of events where all amps below th: {}".format(len(allAmpBelow)))
        # print("Num of events where only one amp below th: {}".format(len(oneAmpBelow)))
        # print("Num of events where two amps below th: {}".format(len(twoAmpBelow)))
        # print("Num of events where three amps below th: {}".format(len(threeAmpBelow)))
        # print("Num of events where no amp below th: {}".format(len(allAmpAbove)))
        return info

    def _masks_to_indexes(self, masks):
        return {k: np.where(v == True) for k, v in masks.items()}

    def stats_scan_th(self, scan_type, get_ids=False):
        """Returns the information on how many events are above or below the threshold
        scan_type can be one of 'prescan', 'overscan', 'both'"""
        if not get_ids:
            if scan_type == 'prescan':
                return self._check_by_amps(self.prescans)
            if scan_type == 'overscan':
                return self._check_by_amps(self.overscans)
            if scan_type == 'both':
                return self._check_by_amps(self.pre_and_overscan)
        if scan_type == 'prescan':
            events = self.data[:, 1:5]
        if scan_type == 'overscan':
            events = self.data[:, 5:9]
        if scan_type == 'both':
            events = self.data[:, 1:9]
        masks = self._get_masks(events)
        return self._masks_to_indexes(masks)

    def get_event(self, event_id):
        return self.data[event_id]

    def get_consecutives(self):
        ev = self.data[:, 1:9]
        m = self._get_masks(ev)

        ok_consec = [sum(1 for _ in group) for key, group in groupby(m['all_below_cond']) if key]
        fail_consec = [sum(1 for _ in group) for key, group in groupby(m['all_below_cond']) if not key]

        return ok_consec, fail_consec


def fill_template(**kwargs):
    template_env = jinja2.Environment(loader=jinja2.FileSystemLoader('./'))
    template = template_env.get_template('report_template.html')
    return template.render(**kwargs)


def print_args(**kwargs):
    pprint.pprint(kwargs)


if __name__ == '__main__':
    import sys
    import os
    import pprint
    import jinja2
    from plotly.subplots import make_subplots
    import plotly.express as px
    import plotly.graph_objects as go
    from io import StringIO

    if len(sys.argv) != 2:
        print("report needs the path to the folder with the data")
    base_path = sys.argv[1]

    if not os.path.exists(base_path):
        print("Path not found: {}".format(base_path))

    report_folder_path = os.path.join(base_path, 'report')
    os.makedirs(report_folder_path, exist_ok=True)

    data_file_path = os.path.join(base_path, 'noise_levels.csv')
    da = DataAnalysis(file_path=data_file_path, threshold=10, mid_threshold=2500)
    da.load_file()
    da.process_header()

    stats_scans = {}
    stats_scans['overscan'] = da.stats_scan_th('overscan')
    stats_scans['prescan'] = da.stats_scan_th('prescan')
    stats_scans['both'] = da.stats_scan_th('both')


    def get_histograms(hist1, hist2=None, hist3=None, hist4=None, title_text=None):
        t = [hist1, hist2, hist3, hist4]
        num_subplots = sum(x is not None for x in t)
        fig_titles = [x[1] for x in t if x]
        fig = make_subplots(1, num_subplots, subplot_titles=fig_titles)
        if hist1:
            fig.add_trace(go.Histogram(x=hist1[0]), 1, 1)
        if hist2:
            fig.add_trace(go.Histogram(x=hist2[0]), 1, 2)
        if hist3:
            fig.add_trace(go.Histogram(x=hist3[0]), 1, 3)
        if hist4:
            fig.add_trace(go.Histogram(x=hist4[0]), 1, 4)
        fig.update_layout(title_text=title_text,
                          showlegend=False)
        tmpf = StringIO()
        fig.write_html(file=tmpf, include_plotlyjs='cdn', include_mathjax='cdn', full_html=False,
                       auto_open=False)
        tmp = tmpf.getvalue()
        tmpf.close()
        return tmp


    histograms = {}

    # Prescans
    p1 = da.get_prescan(1).ravel()
    p2 = da.get_prescan(2).ravel()
    p3 = da.get_prescan(3).ravel()
    p4 = da.get_prescan(4).ravel()
    histograms['prescan_full'] = get_histograms((p1, 'Prescan Amp 1'),
                                                (p2, 'Prescan Amp 2'),
                                                (p3, 'Prescan Amp 3'),
                                                (p4, 'Prescan Amp 4'),
                                                title_text='Prescans std dev')
    histograms['prescan_below_th'] = get_histograms((p1[p1 < da.threshold], 'Prescan Amp 1'),
                                                    (p2[p2 < da.threshold], 'Prescan Amp 2'),
                                                    (p3[p3 < da.threshold], 'Prescan Amp 3'),
                                                    (p4[p4 < da.threshold], 'Prescan Amp 4'),
                                                    title_text='Prescans std dev < {}'.format(da.threshold))

    histograms['prescan_mid_range'] = get_histograms(
        (p1[(p1 > da.threshold) & (p1 < da.mid_threshold)], 'Prescan Amp 1'),
        (p2[(p2 > da.threshold) & (p2 < da.mid_threshold)], 'Prescan Amp 2'),
        (p3[(p3 > da.threshold) & (p3 < da.mid_threshold)], 'Prescan Amp 3'),
        (p4[(p4 > da.threshold) & (p4 < da.mid_threshold)], 'Prescan Amp 4'),
        title_text='Prescans where {} < std dev < {}'.format(da.threshold, da.mid_threshold))

    histograms['prescan_high_range'] = get_histograms((p1[p1 > da.mid_threshold], 'Prescan Amp 1'),
                                                      (p2[p2 > da.mid_threshold], 'Prescan Amp 2'),
                                                      (p3[p3 > da.mid_threshold], 'Prescan Amp 3'),
                                                      (p4[p4 > da.mid_threshold], 'Prescan Amp 4'),
                                                      title_text='Prescans where std dev > {}'.format(da.mid_threshold))
    o1 = da.get_overscan(1).ravel()
    o2 = da.get_overscan(2).ravel()
    o3 = da.get_overscan(3).ravel()
    o4 = da.get_overscan(4).ravel()
    histograms['overscan_full'] = get_histograms((o1, 'Overscan Amp 1'),
                                                 (o2, 'Overscan Amp 2'),
                                                 (o3, 'Overscan Amp 3'),
                                                 (o4, 'Overscan Amp 4'),
                                                 title_text='Overscans std dev')
    histograms['overscan_below_th'] = get_histograms((o1[o1 < da.threshold], 'Overscan Amp 1'),
                                                     (o2[o2 < da.threshold], 'Overscan Amp 2'),
                                                     (o3[o3 < da.threshold], 'Overscan Amp 3'),
                                                     (o4[o4 < da.threshold], 'Overscan Amp 4'),
                                                     title_text='Overscans std dev < {}'.format(da.threshold))

    histograms['overscan_mid_range'] = get_histograms(
        (o1[(o1 > da.threshold) & (o1 < da.mid_threshold)], 'Overscan Amp 1'),
        (o2[(o2 > da.threshold) & (o2 < da.mid_threshold)], 'Overscan Amp 2'),
        (o3[(o3 > da.threshold) & (o3 < da.mid_threshold)], 'Overscan Amp 3'),
        (o4[(o4 > da.threshold) & (o4 < da.mid_threshold)], 'Overscan Amp 4'),
        title_text='Overscans where {} < std dev < {}'.format(da.threshold, da.mid_threshold))

    histograms['overscan_high_range'] = get_histograms((o1[o1 > da.mid_threshold], 'Overscan Amp 1'),
                                                       (o2[o2 > da.mid_threshold], 'Overscan Amp 2'),
                                                       (o3[o3 > da.mid_threshold], 'Overscan Amp 3'),
                                                       (o4[o4 > da.mid_threshold], 'Overscan Amp 4'),
                                                       title_text='Overscans where std dev > {}'.format(
                                                           da.mid_threshold))

    histograms['counts'] = {'prescan': {'low_range': {'amp1': len(p1[p1 < da.threshold]),
                                                      'amp2': len(p2[p2 < da.threshold]),
                                                      'amp3': len(p3[p3 < da.threshold]),
                                                      'amp4': len(p4[p4 < da.threshold])},
                                        'mid_range': {'amp1': len(p1[(p1 > da.threshold) & (p1 < da.mid_threshold)]),
                                                      'amp2': len(p2[(p2 > da.threshold) & (p2 < da.mid_threshold)]),
                                                      'amp3': len(p3[(p3 > da.threshold) & (p3 < da.mid_threshold)]),
                                                      'amp4': len(p4[(p4 > da.threshold) & (p4 < da.mid_threshold)])},
                                        'high_range': {'amp1': len(p1[p1 > da.mid_threshold]),
                                                       'amp2': len(p2[p2 > da.mid_threshold]),
                                                       'amp3': len(p3[p3 > da.mid_threshold]),
                                                       'amp4': len(p4[p4 > da.mid_threshold])},
                                        'full_range': {'amp1': len(p1),
                                                       'amp2': len(p2),
                                                       'amp3': len(p3),
                                                       'amp4': len(p4)}
                                        },
                            'overscan': {'low_range': {'amp1': len(o1[o1 < da.threshold]),
                                                       'amp2': len(o2[o2 < da.threshold]),
                                                       'amp3': len(o3[o3 < da.threshold]),
                                                       'amp4': len(o4[o4 < da.threshold])},
                                         'mid_range': {'amp1': len(o1[(o1 > da.threshold) & (o1 < da.mid_threshold)]),
                                                       'amp2': len(o2[(o2 > da.threshold) & (o2 < da.mid_threshold)]),
                                                       'amp3': len(o3[(o3 > da.threshold) & (o3 < da.mid_threshold)]),
                                                       'amp4': len(o4[(o4 > da.threshold) & (o4 < da.mid_threshold)])},
                                         'high_range': {'amp1': len(o1[o1 > da.mid_threshold]),
                                                        'amp2': len(o2[o2 > da.mid_threshold]),
                                                        'amp3': len(o3[o3 > da.mid_threshold]),
                                                        'amp4': len(o4[o4 > da.mid_threshold])},
                                         'full_range': {'amp1': len(o1),
                                                        'amp2': len(o2),
                                                        'amp3': len(o3),
                                                        'amp4': len(o4)}
                                         }
                            }
    consec = da.get_consecutives()
    histograms['consecutive'] = get_histograms((consec[0], 'Correct'), (consec[1], 'Fail'),
                                               title_text="Consecutive events")

    t = fill_template(header=da.header, info=da.info, stats_scans=stats_scans, histograms=histograms)
    print_args(header=da.header, info=da.info, stats_scans=stats_scans)

    # ToDo: Add histogram for up to 10 failed events for both prescan and overscan if the image is stored at ./images
    # ToDo: Add statistics for image sections
    
    with open(os.path.join(report_folder_path, 'report.html'), 'w') as rhtml:
        rhtml.write(t)
