#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import logging
import time
import os

import argparse

__author__ = 'otger'

IP_EMBEDDED = '172.16.17.141'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

IP='131.243.51.10'
PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT)

# We have to configure ccd geometry

try:
    # we can check all registers that must be configured are configured by
    gfa.clockmanager.remote_get_clock_timings()
    print("Pixel time: {}ns".format(gfa.clockmanager.time_conf.pixel_time))
    print(gfa.clockmanager.time_conf)

finally:
    gfa.close()
