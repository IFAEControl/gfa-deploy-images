#!/usr/bin/env python
# -*- coding: utf-8 -*-
import time

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"


def init_adc(gfa):
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()


def set_default_ccd_expose_stack(gfa, exposure_time_ms: int = 20000):
    g = gfa.clockmanager.stack

    g.clear()
    # If we don't set an image_id, it will update its internal counter
    g.add_new_image_cmd()
    g.add_set_modes_cmd(True, True, True, True)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    g.add_wait_cmd(exposure_time_ms)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.storage_rows)
    g.add_read_rows_cmd(gfa.clockmanager.geom_conf.image_rows)
    g.add_none_cmd()
    # print(f'rows: {gfa.clockmanager.geom_conf.total_rows}')
    # print(f'columns: {gfa.clockmanager.geom_conf.amplifier_active_cols}')

    # Then we have to set the stack at the GFA
    gfa.clockmanager.remote_set_stack_contents()


def set_default_geom(gfa):
    # geometry values are stored at
    geom = gfa.clockmanager.geom_conf

    # it has default values when created
    # print(geom.amplifier_cols)

    # To change geometry values
    # geom.amplifier_cols = 300

    # if we are sure GFA has not been configured, we have to configure geometry.
    gfa.clockmanager.remote_set_ccd_geom()


def set_default_timings(gfa):
    # to set clocks timing default values:
    gfa.clockmanager.remote_set_clock_timings()


def set_default_voltages(gfa):
    # Another important settings to be able to power up the system is to set the voltage values and the configuration of
    # offsets and internal gains of the dac
    # To set default values:
    gfa.powercontroller.remote_set_dac_conf()

    gfa.powercontroller.voltages.set_default_values()

    gfa.powercontroller.remote_set_voltages()


def gfa_powerup_bias(gfa):
    gfa.exposecontroller.remote_get_status()
    if not gfa.exposecontroller.status.is_powered:
        set_default_voltages(gfa)

        # finally we can power up the system:
        gfa.exposecontroller.remote_power_up()
        itr = 0
        while gfa.exposecontroller.status.ready_state is False:
            if itr > 10:
                gfa.powercontroller.remote_get_configured_channels()
                print(gfa.powercontroller.dac_channels)
                raise Exception("gfa should be in ready state")
            print(gfa.exposecontroller.status)
            time.sleep(0.4)
            gfa.exposecontroller.remote_get_status()
            itr += 1
        print(gfa.exposecontroller.status)
