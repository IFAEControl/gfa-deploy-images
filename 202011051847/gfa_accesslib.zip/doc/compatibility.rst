.. _compatibility:

API Compatibility
==================

To ensure that gfaaccesslib works properly we check if the API_VERSION match the one in the remote system. If it doesn't it will show a warning. 
