## HISTORY

### 1.1.0

- removed get\_calib\_debug\_signals from api_helpers.py 
- added bit_time commands
- stylistic changes and other improvements