#!/usr/bin/bash
tar -zcvf $(date +%Y%m%d_%H%M%S)-gfaaccesslib.tar.gz --exclude=.git --exclude=.idea --exclude=*.pyc -C .. gfaaccesslib
