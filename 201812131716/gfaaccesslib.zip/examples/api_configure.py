#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.api import GFAApi
import time
from gfaaccesslib.logger import log, formatter
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

IP='10.1.1.1'
print("Connecting to GFAApi @{0}".format(IP))
log.info('Configured GFAApi to ip {0}'.format(IP))

IMAGE_ID = 3155413

# We want to receive data (which is sent through async path), so we must enable sync
api = GFAApi(IP, True)

# Fastest way to configure GFA (if it has not been configured before is to set default values
# If GFA has been powered, not all settings can be changed (voltage values won't change)
# set default values, sets voltages, clocks timing values and ccd geometry
api.set_default_values()

# To access geometry values:
geom = api.get_ccd_geometry()

# we can print this information
    # print geom
# or we can access each one of the fields:
    # geom.cols_2_be_read

# Same can be done with timings and voltages:
timings = api.get_clocks_timings()
voltages = api.get_voltages_config()


# Next step is to enable voltages
api.bias_powerup()

# To check if it has been powered, it is easier to use the library instead of the api
itr = 0
gfa = api.get_lib_instance()
while gfa.exposecontroller.status.ready_state is False:
    if itr > 10:
        gfa.powercontroller.remote_get_configured_channels()
        print(gfa.powercontroller.dac_channels)
        raise Exception("gfa should be in ready state")
    print(gfa.exposecontroller.status)
    time.sleep(0.4)
    gfa.exposecontroller.remote_get_status()
    itr += 1

print(gfa.exposecontroller.status)



