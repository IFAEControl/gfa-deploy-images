#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)

# if we need to recover geometry:
gfa.clockmanager.remote_get_ccd_geom()

# values recovered from GFA are automatically stored at
print(gfa.clockmanager.geom_conf)

# to get clocks timing values:
gfa.clockmanager.remote_get_clock_timings()

# values are stored at:
print(gfa.clockmanager.time_conf)

# we can check all registers that must be configured are configured by
gfa.clockmanager.remote_get_info()
print(gfa.clockmanager.info.status)
print(gfa.clockmanager.info)

# volatges on DACS
# to recover current configured values
gfa.powercontroller.remote_get_configured_voltages()
print(gfa.powercontroller.voltages)

# Expose controller status
gfa.exposecontroller.remote_get_status()
print(gfa.exposecontroller.status)

# Voltage enables:
gfa.powercontroller.remote_get_enables()
print(gfa.powercontroller.enables)


gfa.powercontroller.remote_get_phase_timing()
print(gfa.powercontroller.powerup_timing_ms)


gfa.powercontroller.remote_get_configured_channels()
print(gfa.powercontroller.dac_channels)

gfa.exposecontroller.remote_get_status()
print(gfa.exposecontroller.status)

gfa.irq.remote_get_status()
print(gfa.irq.status)

gfa.buffers.remote_get_buffers_status()
print(gfa.buffers.status)

gfa.close()
