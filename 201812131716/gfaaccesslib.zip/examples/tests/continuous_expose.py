#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
from pprint import pprint
import json
import logging
import sys
import os
import time
import datetime
import pickle
try:
    import psutil
except Exception:
    psutil = None

from gfafunctionality.raws import RawImageFile

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

IP = '172.16.17.82'
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

MINUTES_RUNNING = 3
EXPOSE_TIME_IN_10NS = 500000000  # 5 seconds * 1000ms/1s * 1000us/1ms * 100*(units of 10ns)/1us

SAVE_FITS = True

DATA_PATH = os.path.expanduser("~/gfatimes")
NOW = datetime.datetime.utcnow()
NOW_STRING = NOW.strftime("%Y%m%d_%H%M%S")
PICKLE_FILE_NAME = NOW.strftime("%Y%m%d_%H%M%S.timestats.pickle")
CSV_FILE_NAME = NOW.strftime("%Y%m%d_%H%M%S.csv")
CSV_MEMO_NAME = NOW.strftime("%Y%m%d_%H%M%S.memo.csv")

"""

There are 32 TR available.

- The operation of continuous mode is:
    
    - clear and start TR26 (1ms resolution)
    - clear TR0
    - clear TR2
    - clear TR3 (used to stop the loop externally)
    - Load desired expose time at TR 1 (in 10ns units)
    - Dump CCD
    
    - start TR0 (10ns) to control image exposure
    
    - start loop
    - expose for x seconds (wait until TR0 >= TR1)
    - copy TR0 to TR20
    - copy TS to TR14, TR13
    - new_exposure (to take into account dumping of rows into row numbers)
    - start TR2 (10ns)
    - transfer image to storage, dumping storage
    - copy TR2 to TR19 (save time transfer im-> storage)
    - clear TR2
    - clear TR0
    - start TR0 to control image exposure
    - disable vertical clocks from image
    - start TR2 (10ns) - to control readout time
    - read storage section
    - copy TR2 to TR18
    - clear TR2
    - copy TS to TR12, TR11
    - end image command
    - enable vertical clocks from image
    - loop if TR3 /= 0, else go out of the loop
    

- What times has to be trackedk
    - TR20: time exposed (10ns units) 
    - TR19: time to transfer image to storage (10ns units)
    - TR18: time spent reading the image section (10ns units)
    - TR17: timestamp (seconds)
    - TR16: timestamp (miliseconds)
    - TR15: full duration of the stack running (1ms)
    - TR14: ts_sec of end_expose
    - TR13: ts_ms of end_expose
    - TR12: ts_sec of end_read
    - TR11: ts_ms of end_read
    - TR3: set to 0, externally set to '1' to stop sequence
    - TR2: helper timer used on transfer time and readout time
    - TR1: desired expose time in 10ns units (can be modified externally)
"""


def add_copy_ts(stack, tr_ts_sec, tr_ts_ms, tr_dest_sec, tr_dest_ms):
    stack.add_tr_copy_trb_2_tra(trb_address=tr_ts_sec, tra_address=tr_dest_sec)
    stack.add_tr_copy_trb_2_tra(trb_address=tr_ts_ms, tra_address=tr_dest_ms)


class TimeValues(object):
    def __init__(self):
        self.debug_phase = 0
        self.hor_acq = 0
        self.hor_acq_skip = 0
        self.hor_del = 0
        self.hor_del_skip = 0
        self.hor_overlap = 0
        self.hor_overlap_skip = 0
        self.hor_postrg = 0
        self.hor_postrg_skip = 0
        self.hor_prerg = 0
        self.hor_prerg_skip = 0
        self.hor_rg = 0
        self.hor_rg_skip = 0
        self.vert_tdgr = 0
        self.vert_tdrg = 0
        self.vert_tdrt = 0
        self.vert_tdtr = 0
        self.vert_toi = 0


class GeomValues(object):
    def __init__(self):
        self.amplifier_active_cols = 0
        self.overscan_cols = 0
        self.prescan_cols = 0


class TimeRegsValues(object):
    def __init__(self):
        self.tr_0 = 0
        self.tr_1 = 0
        self.tr_10 = 0
        self.tr_11 = 0
        self.tr_12 = 0
        self.tr_13 = 0
        self.tr_14 = 0
        self.tr_15 = 0
        self.tr_16 = 0
        self.tr_17 = 0
        self.tr_18 = 0
        self.tr_19 = 0
        self.tr_2 = 0
        self.tr_20 = 0
        self.tr_21 = 0
        self.tr_22 = 0
        self.tr_23 = 0
        self.tr_24 = 0
        self.tr_25 = 0
        self.tr_26 = 0
        self.tr_27 = 0
        self.tr_28 = 0
        self.tr_29 = 0
        self.tr_3 = 0
        self.tr_30 = 0
        self.tr_31 = 0
        self.tr_4 = 0
        self.tr_5 = 0
        self.tr_6 = 0
        self.tr_7 = 0
        self.tr_8 = 0
        self.tr_9 = 0

    def __repr__(self):

        return ", ".join(str(getattr(self, 'tr_{}'.format(x))) for x in range(32))


class LocalTimeStamps(object):
    def __init__(self):
        self.start = datetime.datetime.utcnow().timestamp()
        self.end = None

    def set_end(self):
        self.end = datetime.datetime.utcnow().timestamp()


class RowInfo(object):
    def __init__(self, row, pixels_per_amp, amps):
        self.ts = datetime.datetime.utcnow().timestamp()
        self.row = row
        self.pixels_per_amp = pixels_per_amp
        self.amps = amps


class RowTimes(object):
    def __init__(self):
        self.times = {}
        self.first = datetime.datetime.utcnow().timestamp()
        self.last = self.first

    def update(self, row_num, pixels_per_amp, amps):
        a = RowInfo(row=row_num, pixels_per_amp=pixels_per_amp, amps=amps)
        self.times[row_num] = a
        self.last = a.ts


class ImageValues(object):
    def __init__(self, image_id):
        self.id = image_id
        self.timeconf = TimeValues()
        self.geomconf = GeomValues()
        self.amplifier_active_cols = 0
        self.tr_start = TimeRegsValues()
        self.tr_end = TimeRegsValues()
        self.local_ts = LocalTimeStamps()
        self.row_times = RowTimes()
        self.times = TimesToSave()

class TimesToSave(object):
    def __init__(self):
        self.requested_expose_time = 0
        self.exposed_time = 0
        self.transfer_time = 0
        self.readout_time = 0
        self.image_start_ts = 0
        self.row_first = 0
        self.row_last = 0
        self.image_end = 0

    def update(self, req_expose_time, exposed_time, transfer_time, readout_time, image_start_ts,
                 row_first_ts, row_last_ts, image_end_ts):
        self.requested_expose_time = req_expose_time
        self.exposed_time = exposed_time
        self.transfer_time = transfer_time
        self.readout_time = readout_time
        self.image_start_ts = image_start_ts
        # next times are from image_start
        self.row_first = row_first_ts - image_start_ts
        self.row_last = row_last_ts - image_start_ts
        self.image_end = image_end_ts - image_start_ts


class TimeStats(object):
    def __init__(self, gfa_client):
        self.gfa = gfa_client
        self.image_values = {}
        self._created_on = datetime.datetime.utcnow()
        self.path = os.path.join(DATA_PATH, CSV_FILE_NAME)
        self.headers = []
        self.create_csv_header()

    def image_start_cb(self, header, jsondata):
        log.info("Received image start async:")
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)
        # pprint(j)
        image_id = j['image_id']
        iv = ImageValues(image_id)
        iv.geomconf.amplifier_active_cols = j['amplifier_active_cols']
        iv.geomconf.overscan_cols = j['overscan_cols']
        iv.geomconf.prescan_cols = j['prescan_cols']

        iv.timeconf.debug_phase = j['debug_phase']
        iv.timeconf.hor_acq = j['hor_acq']
        iv.timeconf.hor_acq_skip = j['hor_acq_skip']
        iv.timeconf.hor_del = j['hor_del']
        iv.timeconf.hor_del_skip = j['hor_del_skip']
        iv.timeconf.hor_overlap = j['hor_overlap']
        iv.timeconf.hor_overlap_skip = j['hor_overlap_skip']
        iv.timeconf.hor_postrg = j['hor_postrg']
        iv.timeconf.hor_postrg_skip = j['hor_postrg_skip']
        iv.timeconf.hor_prerg = j['hor_prerg']
        iv.timeconf.hor_prerg_skip = j['hor_prerg_skip']
        iv.timeconf.hor_rg = j['hor_rg']
        iv.timeconf.hor_rg_skip = j['hor_rg_skip']
        iv.timeconf.vert_tdgr = j['vert_tdgr']
        iv.timeconf.vert_tdrg = j['vert_tdrg']
        iv.timeconf.vert_tdrt = j['vert_tdrt']
        iv.timeconf.vert_tdtr = j['vert_tdtr']
        iv.timeconf.vert_toi = j['vert_toi']

        iv.tr_start.tr_0 = j['tr_0']
        iv.tr_start.tr_1 = j['tr_1']
        iv.tr_start.tr_10 = j['tr_10']
        iv.tr_start.tr_11 = j['tr_11']
        iv.tr_start.tr_12 = j['tr_12']
        iv.tr_start.tr_13 = j['tr_13']
        iv.tr_start.tr_14 = j['tr_14']
        iv.tr_start.tr_15 = j['tr_15']
        iv.tr_start.tr_16 = j['tr_16']
        iv.tr_start.tr_17 = j['tr_17']
        iv.tr_start.tr_18 = j['tr_18']
        iv.tr_start.tr_19 = j['tr_19']
        iv.tr_start.tr_2 = j['tr_2']
        iv.tr_start.tr_20 = j['tr_20']
        iv.tr_start.tr_21 = j['tr_21']
        iv.tr_start.tr_22 = j['tr_22']
        iv.tr_start.tr_23 = j['tr_23']
        iv.tr_start.tr_24 = j['tr_24']
        iv.tr_start.tr_25 = j['tr_25']
        iv.tr_start.tr_26 = j['tr_26']
        iv.tr_start.tr_27 = j['tr_27']
        iv.tr_start.tr_28 = j['tr_28']
        iv.tr_start.tr_29 = j['tr_29']
        iv.tr_start.tr_3 = j['tr_3']
        iv.tr_start.tr_30 = j['tr_30']
        iv.tr_start.tr_31 = j['tr_31']
        iv.tr_start.tr_4 = j['tr_4']
        iv.tr_start.tr_5 = j['tr_5']
        iv.tr_start.tr_6 = j['tr_6']
        iv.tr_start.tr_7 = j['tr_7']
        iv.tr_start.tr_8 = j['tr_8']
        iv.tr_start.tr_9 = j['tr_9']
        print("tr start image: {}".format(iv.tr_start))

        self.image_values[image_id] = iv

    def image_done_cb(self, header, jsondata):
        log.info("Received end of image:")
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)
        image_id = j['image_id']
        iv = self.image_values[image_id]
        iv.local_ts.set_end()
        iv.tr_end.tr_0 = j['tr_0']
        iv.tr_end.tr_1 = j['tr_1']
        iv.tr_end.tr_10 = j['tr_10']
        iv.tr_end.tr_11 = j['tr_11']
        iv.tr_end.tr_12 = j['tr_12']
        iv.tr_end.tr_13 = j['tr_13']
        iv.tr_end.tr_14 = j['tr_14']
        iv.tr_end.tr_15 = j['tr_15']
        iv.tr_end.tr_16 = j['tr_16']
        iv.tr_end.tr_17 = j['tr_17']
        iv.tr_end.tr_18 = j['tr_18']
        iv.tr_end.tr_19 = j['tr_19']
        iv.tr_end.tr_2 = j['tr_2']
        iv.tr_end.tr_20 = j['tr_20']
        iv.tr_end.tr_21 = j['tr_21']
        iv.tr_end.tr_22 = j['tr_22']
        iv.tr_end.tr_23 = j['tr_23']
        iv.tr_end.tr_24 = j['tr_24']
        iv.tr_end.tr_25 = j['tr_25']
        iv.tr_end.tr_26 = j['tr_26']
        iv.tr_end.tr_27 = j['tr_27']
        iv.tr_end.tr_28 = j['tr_28']
        iv.tr_end.tr_29 = j['tr_29']
        iv.tr_end.tr_3 = j['tr_3']
        iv.tr_end.tr_30 = j['tr_30']
        iv.tr_end.tr_31 = j['tr_31']
        iv.tr_end.tr_4 = j['tr_4']
        iv.tr_end.tr_5 = j['tr_5']
        iv.tr_end.tr_6 = j['tr_6']
        iv.tr_end.tr_7 = j['tr_7']
        iv.tr_end.tr_8 = j['tr_8']
        iv.tr_end.tr_9 = j['tr_9']

        print("tr end image: {}".format(iv.tr_end))
        self.calculate_times(image_id=image_id)
        self.save_csv(image_id=image_id)
        image_removed = False
        try:
            im = self.gfa.raws.rem_image(image_id)
            if im is not None:
                log.info("Removed image {} from raw manager".format(image_id))
                image_removed = True
                if SAVE_FITS:
                    raw = RawImageFile(raw_image=im)
                    raw.save_fits(DATA_PATH, "{}_image_{}.fits".format(NOW_STRING, image_id))
        except Exception:
            log.error("Failed to remove image id: {}".format(image_id))

        try:
            with open(os.path.join(DATA_PATH, PICKLE_FILE_NAME), 'wb') as fp:
                pickle.dump(self.image_values, fp)
        except Exception:
            log.exception("Failed to save pickle")

        if psutil:
            try:
                process = psutil.Process(os.getpid())
                with open(os.path.join(DATA_PATH, CSV_MEMO_NAME), 'a') as fp:
                    fp.write("{}, {}, {}, {}\r\n".format(image_id, image_removed,
                                                     process.memory_info().rss/1E6,
                                                     process.cpu_percent()))
            except Exception:
                log.exception("Failed to log memory use")

    def line_cb(self, header, jsondata, raw_data):
        # log.info("Received line:")
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)
        # pprint(j)
        # log.info("raw_data length {}".format(len(raw_data)))
        image_id = j['image_id']
        iv = self.image_values[image_id]
        iv.row_times.update(row_num=j['ccd_row_num'],
                            pixels_per_amp=j['amplifier_pixels'],
                            amps=j['amplifiers_num'])

    def calculate_times(self, image_id):
        """
            - TR20: time exposed (10ns units)
            - TR19: time to transfer image to storage (10ns units)
            - TR18: time spent reading the image section (10ns units)
            - TR17: timestamp (seconds)
            - TR16: timestamp (miliseconds)
            - TR15: full duration of the stack running (1ms)
            - TR14: ts_sec of end_expose
            - TR13: ts_ms of end_expose
            - TR12: ts_sec of end_read
            - TR11: ts_ms of end_read
            - TR3: set to 0, externally set to '1' to stop sequence
            - TR2: helper timer used on transfer time and readout time
            - TR1: desired expose time in 10ns units (can be modified externally)
        """
        iv = self.image_values[image_id]
        iv.times.update(
            req_expose_time=iv.tr_end.tr_1 * 1E-8,
            exposed_time=iv.tr_end.tr_20 / 100000000,
            transfer_time=iv.tr_end.tr_19 * 1E-8,
            readout_time=iv.tr_end.tr_18 * 1E-8,
            image_start_ts=iv.local_ts.start,
            row_first_ts=iv.row_times.first,
            row_last_ts=iv.row_times.last,
            image_end_ts=iv.local_ts.end)

    def create_csv_header(self):
        with open(self.path, "w+") as fp:
            fp.write("# Continuous mode time analysis\r\n")
            fp.write("# Date start: {}\r\n".format(self._created_on.strftime("%d/%M/%Y")))
            fp.write("# Time start: {}\r\n".format(self._created_on.strftime("%H:%m:%S")))
            fp.write("# Geometry values:")
            ans = self.gfa.clockmanager.remote_get_ccd_geom().answer
            for k in ans.keys():
                fp.write("#\t-{}: {}\r\n".format(k, ans[k]))
            ans = self.gfa.clockmanager.remote_get_clock_timings().answer
            fp.write("# Time values:")
            for k in ans.keys():
                fp.write("#\t-{}: {}\r\n".format(k, ans[k]))
            fp.write("#\t-Pixel time: {}\r\n".format(self.gfa.clockmanager.time_conf.pixel_time))
            self.headers = ['requested_expose_time', 'exposed_time', 'transfer_time',
                       'readout_time', 'image_start_ts', 'row_first', 'row_last', 'image_end']
            fp.write("image_id, {}\r\n".format(', '.join(self.headers)))

    def save_csv(self, image_id):
        iv = self.image_values[image_id]
        with open(self.path, "a") as fp:
            tmp = [str(getattr(iv.times, el)) for el in self.headers]
            fp.write("{}, {}\r\n".format(image_id, ', '.join(tmp)))


def show_im(gfa):
    def f(header, jsondata):
        log.info("Received end of image:")
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)
        image_id = j['image_id']
        im = gfa.raws.get_image(image_id)
        im.show_im()
    return(f)


def start_tr_as_timestamp(gfa, addr_tr_secs, addr_tr_ms):
    now = datetime.datetime.utcnow().timestamp()
    # print(now)
    gfa.clockmanager.remote_set_tr_value(int(now), addr_tr_secs)
    gfa.clockmanager.remote_set_tr_value(int((now-int(now))*1000), addr_tr_ms)
    gfa.clockmanager.remote_start_tr(tr_addr=addr_tr_ms, resolution=2)


def get_tr_as_timestamp(gfa_client, addr_tr_secs, addr_tr_ms):
    value_sec = gfa_client.clockmanager.remote_get_tr_reg(tr_addr=addr_tr_secs)
    value_ms = gfa_client.clockmanager.remote_get_tr_reg(tr_addr=addr_tr_ms)
    value = value_sec.answer['tr_{}'.format(addr_tr_secs)] + value_ms.answer['tr_{}'.format(addr_tr_ms)]/1000
    print("Timestamp: {}".format(value))
    return value


# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()

    values_before = gfa.clockmanager.remote_get_tr_regs().answer
    gfa.clockmanager.remote_clear_all_tr()
    # values_after = gfa.clockmanager.remote_get_tr_regs().answer
    # pprint(values_before)
    # pprint(values_after)
    # gfa.clockmanager.remote_start_time_thread(addr_s=28, addr_ms=27, sleep_s=300)

    # start a timer with resolution ms to hold timestamp
    start_tr_as_timestamp(gfa=gfa,
                          addr_tr_secs=17,
                          addr_tr_ms=16)

    #################################################################################
    # Acquisition definition
    #################################################################################


    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:
    g = gfa.clockmanager.stack
    # Clear stack
    g.clear()

    # Clear and start TR15, the one that holds the whole duration of this stack running
    g.add_tr_clear(15, all=False)
    g.add_tr_start_timer(15, '1ms')
    g.add_tr_load_value(tr_address=3, value=1)

    # Enable all amplifiers and both image and storage vertical clocks
    g.add_set_modes_cmd(True, True, True, True)
    # Clear TR0
    g.add_tr_clear(0, all=False)
    # Clear TR2
    g.add_tr_clear(2, all=False)
    # Load desired expose time in TR1
    g.add_tr_load_value(1, EXPOSE_TIME_IN_10NS)  # 2 seconds in 10ns units
    # Clear CCD : Dump all rows
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    # start timer 0 - the one which is used to control image exposure time
    g.add_tr_start_timer(0, resolution='10ns')

    #####################################################
    g.add_loop_start()

    # wait expose time:
    g.add_wait_until_tra_goet_trb_cmd(address_tra=0, address_trb=1)
    # save time exposed to TR20
    g.add_tr_copy_trb_2_tra(trb_address=0, tra_address=20)
    # Save timestamp of end expose
    # add_copy_ts(stack=g, tr_ts_sec=17, tr_ts_ms=16, tr_dest_sec=14, tr_dest_ms=13)
    # We start the new_exposure here, otherwise, it doesn't counts the dump of rows to
    # the rows processed counter
    g.add_new_image_cmd()
    # start timer 2 to know transfer time
    # Here TR2 has been cleared
    g.add_tr_start_timer(2, resolution='10ns')
    # Transfer image to storage: Dump storage rows
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.storage_rows)
    # Copy tr2 to tr 19
    g.add_tr_copy_trb_2_tra(tra_address=19, trb_address=2)
    # Clear TR2
    g.add_tr_clear(2, all=False)
    # Clear TR0
    g.add_tr_clear(0, all=False)

    # Exposing time for next image starts here. Start timer 0
    g.add_tr_start_timer(0, resolution='10ns')

    # Disable image vertical clocks
    g.add_set_modes_cmd(eh_en=True, fg_en=True, image_en=False, storage_en=True)

    # start timer 2 to know readout time
    g.add_tr_start_timer(2, resolution='10ns')

    # Read out image section
    g.add_read_rows_cmd(gfa.clockmanager.geom_conf.image_rows)

    # Copy readout time to tr 18
    g.add_tr_copy_trb_2_tra(tra_address=18, trb_address=2)
    # Clear TR2
    g.add_tr_clear(2, all=False)
    # Save timestamp of end readout
    # add_copy_ts(stack=g, tr_ts_sec=17, tr_ts_ms=16, tr_dest_sec=12, tr_dest_ms=11)

    # Mark end of the read image
    g.add_end_image_cmd()

    # Enable all amplifiers and both image and storage vertical clocks
    g.add_set_modes_cmd(True, True, True, True)

    # loop if TR3 /= 0, externally set TR3 to another value to stop looping
    g.add_loop_end_loop_if_tra_neq_0(3)

    # Out of the loop, stop timer of full duration ot stack running
    g.add_tr_stop_timer(15)

    # Finish stack running
    g.add_none_cmd()

    # Stack can be printed so we can see its contents and also translates its commands
    # to human
    print('Exposure stack contents: {0}'.format(g))

    # Then we have to set to GFA
    gfa.clockmanager.remote_set_stack_contents()

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)


    time_stats = TimeStats(gfa_client=gfa)

    gfa.async.add_end_image_callback(time_stats.image_done_cb)
    # gfa.async.add_end_image_callback(show_im(gfa))
    gfa.async.add_new_image_callback(time_stats.image_start_cb)
    gfa.async.add_row_callback(time_stats.line_cb)

    gfa.exposecontroller.remote_start_stack_exec()

    time.sleep(MINUTES_RUNNING)
    gfa.clockmanager.remote_set_tr_value(value=0, tr_addr=3)
    log.info("Set TR3 to '1'")

    time.sleep(EXPOSE_TIME_IN_10NS/100000000 + 1)

    images = sorted(gfa.raws.list_images())
    print(images)

    tr_values = gfa.clockmanager.remote_get_tr_regs()
    pprint(tr_values)


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    # gfa.clockmanager.remote_join_time_thread()
    gfa.close()
