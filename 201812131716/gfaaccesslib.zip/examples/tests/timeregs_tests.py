#!/usr/bin/python3
# -*- coding: utf-8 -*-
import time

from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
from pprint import pprint
import json
import logging
import sys
import os
import datetime

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
IP='172.16.17.82'
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))


def get_tr_as_timestamp(gfa, addr_tr_secs, addr_tr_ms):
    value_sec = gfa.clockmanager.remote_get_tr_reg(tr_addr=addr_tr_secs)
    value_ms = gfa.clockmanager.remote_get_tr_reg(tr_addr=addr_tr_ms)
    value = value_sec.answer['tr_{}'.format(addr_tr_secs)] + \
            value_ms.answer['tr_{}'.format(addr_tr_ms)]/1000
    print("Timestamp: {}".format(value))

    return value




# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()

    #################################################################################
    # Acquisition definition
    #################################################################################

    gfa.clockmanager.remote_clear_all_tr()

    values_orig = gfa.clockmanager.remote_get_tr_regs()

    for i in range(32):
        gfa.clockmanager.remote_set_tr_value(value=3*i, tr_addr=i)

    values_after = gfa.clockmanager.remote_get_tr_regs()

    for k in sorted(values_orig.answer.keys()):
        print("{}: {} - {}".format(k, values_orig.answer[k], values_after.answer[k]))



    try:
        gfa.clockmanager.remote_start_time_thread(addr_s=30, addr_ms=29, sleep_s=300)
    except Exception:
        try:
            gfa.clockmanager.remote_join_time_thread()
            print("joined timer Thread")
            # gfa.clockmanager.remote_start_time_thread(addr_s=28, addr_ms=27, sleep_s=300)
        except Exception:
            pass

    now = datetime.datetime.utcnow().timestamp()
    print(now)
    gfa.clockmanager.remote_set_tr_value(int(now), 28)
    gfa.clockmanager.remote_set_tr_value(int((now-int(now))*1000), 27)
    gfa.clockmanager.remote_start_tr(tr_addr=27, resolution=2)

    value_28 = gfa.clockmanager.remote_get_tr_reg(tr_addr=28)
    value_27 = gfa.clockmanager.remote_get_tr_reg(tr_addr=27)
    print("Timestamp: {}".format(value_28.answer['tr_28']+value_27.answer['tr_27']/1000))

    print(get_tr_as_timestamp(gfa, 30, 29))

    time.sleep(3)
    print(get_tr_as_timestamp(gfa, 30, 29))
    print(get_tr_as_timestamp(gfa, 28, 27))


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
