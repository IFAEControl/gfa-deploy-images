#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.141'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.12.251'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
try:
    gfa = GFA(IP, PORT)

    # Another important settings to be able to power up the system is to set the voltage values and the configuration of
    # offsets and internal gains of the dac
    # To set default values:
    gfa.powercontroller.remote_set_dac_conf()

    gfa.powercontroller.voltages.set_default_values()
    gfa.powercontroller.remote_set_voltages()

    # values are stored and can be changed at:
    # print(gfa.powercontroller.voltages)

    # to change a voltage value:
    # gfa.powercontroller.voltages.DD.volts = 29.99
    # gfa.powercontroller.voltages.DG_hi.volts =
    # gfa.powercontroller.voltages.DG_low.volts =
    # gfa.powercontroller.voltages.I01_IM_hi.volts =
    # gfa.powercontroller.voltages.I01_IM_low =
    # gfa.powercontroller.voltages.I01_ST_hi.volts =
    # gfa.powercontroller.voltages.I01_ST_low.volts =
    # gfa.powercontroller.voltages.I02_IM_hi.volts =
    # gfa.powercontroller.voltages.I02_IM_low.volts =
    # gfa.powercontroller.voltages.I02_ST_hi.volts =
    # gfa.powercontroller.voltages.I02_ST_low.volts =
    # gfa.powercontroller.voltages.I03_IM_hi.volts =
    # gfa.powercontroller.voltages.I03_IM_low.volts =
    # gfa.powercontroller.voltages.I03_ST_hi.volts =
    # gfa.powercontroller.voltages.I03_ST_low.volts =
    # gfa.powercontroller.voltages.I04_IM_hi.volts =
    # gfa.powercontroller.voltages.I04_IM_low.volts =
    # gfa.powercontroller.voltages.I04_ST_hi.volts =
    # gfa.powercontroller.voltages.I04_ST_low.volts =
    # gfa.powercontroller.voltages.OD_EH.volts =
    # gfa.powercontroller.voltages.OD_FG.volts =
    # gfa.powercontroller.voltages.OG.volts =
    # gfa.powercontroller.voltages.R01_hi.volts =
    # gfa.powercontroller.voltages.R01_low.volts =
    # gfa.powercontroller.voltages.R02_hi.volts =
    # gfa.powercontroller.voltages.R02_low.volts =
    # gfa.powercontroller.voltages.R03_hi.volts =
    # gfa.powercontroller.voltages.R03_low.volts =
    # gfa.powercontroller.voltages.RD.volts =
    # gfa.powercontroller.voltages.RG_hi.volts =
    # gfa.powercontroller.voltages.RG_low.volts =
    # gfa.powercontroller.voltages.VSS.volts =

    # gfa.powercontroller.voltages.powerup_ms =
    # gfa.powercontroller.voltages.powerdown_ms =

    gfa.powercontroller.remote_set_voltages()

    # to recover current configured values
    gfa.powercontroller.remote_get_configured_voltages()
    print("Current configured values at GFA")
    print(gfa.powercontroller.voltages)

    # If you are interested on knowing more information of a voltage uncomment next:
    # print(gfa.powercontroller.voltages.DD)
    # print(gfa.powercontroller.voltages.DG_hi)
    # print(gfa.powercontroller.voltages.DG_low)
    # print(gfa.powercontroller.voltages.I01_IM_hi)
    # print(gfa.powercontroller.voltages.I01_)
    # print(gfa.powercontroller.voltages.I01_ST_hi)
    # print(gfa.powercontroller.voltages.I01_ST_low)
    # print(gfa.powercontroller.voltages.I02_IM_hi)
    # print(gfa.powercontroller.voltages.I02_IM_low)
    # print(gfa.powercontroller.voltages.I02_ST_hi)
    # print(gfa.powercontroller.voltages.I02_ST_low)
    # print(gfa.powercontroller.voltages.I03_IM_hi)
    # print(gfa.powercontroller.voltages.I03_IM_low)
    # print(gfa.powercontroller.voltages.I03_ST_hi)
    # print(gfa.powercontroller.voltages.I03_ST_low)
    # print(gfa.powercontroller.voltages.I04_IM_hi)
    # print(gfa.powercontroller.voltages.I04_IM_low)
    # print(gfa.powercontroller.voltages.I04_ST_hi)
    # print(gfa.powercontroller.voltages.I04_ST_low)
    # print(gfa.powercontroller.voltages.OD_EH)
    # print(gfa.powercontroller.voltages.OD_FG)
    # print(gfa.powercontroller.voltages.OG)
    # print(gfa.powercontroller.voltages.R01_hi)
    # print(gfa.powercontroller.voltages.R01_low)
    # print(gfa.powercontroller.voltages.R02_hi)
    # print(gfa.powercontroller.voltages.R02_low)
    # print(gfa.powercontroller.voltages.R03_hi)
    # print(gfa.powercontroller.voltages.R03_low)
    # print(gfa.powercontroller.voltages.RD)
    # print(gfa.powercontroller.voltages.RG_hi)
    # print(gfa.powercontroller.voltages.RG_low)
    # print(gfa.powercontroller.voltages.VSS)

except Exception as ex:
    print("Shit, something failed: {}".format(ex))
finally:
    gfa.close()
