#!/usr/bin/python3
# -*- coding: utf-8 -*-

import code
import logging
import traceback
import threading

from PyQt5 import QtCore, QtWidgets
from pyqt_tools import messages, table_operations
from gfafunctionality.raws import RawImageMetadata
from gfaaccesslib.gfa import API_VERSION

import gfa
from helper_functions import new_image, memory_usage
from widgets.adc import ADC
from widgets.dac import DAC
from widgets.offsets import Offset
from widgets.diagnostics import Diagnostics
from widgets.telemetry import Telemetry
from widgets.pid import PID
from widgets.pwm import PWM
from widgets.alarms import Alarms
from widgets.discharge import Discharge
from widgets.logs import Logs
from widgets.settings import Settings
from widgets.ccd import CCD
from widgets.versions import Versions
from widgets.monitor_sensors import MonitorSensors
from widgets.ui.mainwindow_ui import Ui_MainWindow
from widgets.ui.plot_tab import Ui_PlotImageWidget, Ui_TriplePlotImageWidget, Ui_PlotCurveWidget, Ui_DualPlotImageWidget
from tests import Tests
from registry import Registry
import config

log = logging.getLogger(__name__)


class Information:

    def __init__(self, info_widget):
        self._info = info_widget

    def _set_style(self, style):
        self._info.setStyleSheet(style)

    def _set_msg(self, msg):
        self._info.setText(msg)

    def show_error(self, msg):
        self._set_style("color: red;")
        self._set_msg(msg)

    def show_warning(self, msg):
        self._set_style("color: olive;")
        self._set_msg(msg)

    def show_success(self, msg):
        self._set_style("color: green;")
        self._set_msg(msg)

    def show_info(self, msg):
        self._set_style("color: blue;")
        self._set_msg(msg)


class StatusManager:
    """
    Set the status checkboxes to true or false
    """

    def __init__(self, configured_check, offsets_check, calibrated_check, discharge_check):
        self._configured = configured_check
        self._offsets = offsets_check
        self._calibrated = calibrated_check
        self._discharge = discharge_check

        # States checkboxes are used only for information purposes
        # so we inhibit the user actions on them
        self._configured.nextCheckState = lambda: None
        self._offsets.nextCheckState = lambda: None
        self._calibrated.nextCheckState = lambda: None
        self._discharge.nextCheckState = lambda: None

    def configured(self, b):
        self._configured.setChecked(b)

    def offsets(self, b):
        self._offsets.setChecked(b)

    def calibrated(self, b):
        self._calibrated.setChecked(b)

    def discharge(self, b):
        self._discharge.setChecked(b)


class Monitor:

    def __init__(self, monitor):
        self._monitor = monitor
        self._temperature = 0
        self.update()

    def _set_text(self, str):
        self._monitor.setText(str)

    def sensors_callback(self, data):
        self._temperature = round(data["temperature"], 3)

    def update(self):
        fmt = "Temperature: {}. Memory usage: {}".format(
            self._temperature, memory_usage())
        self._set_text(fmt)


class MainWindow(QtWidgets.QMainWindow):
    exposeDone_signal = QtCore.pyqtSignal(dict)
    #telemetryDone_signal = QtCore.pyqtSignal(dict)

    def __init__(self):
        super(MainWindow, self).__init__()
        # Initialization of classes that are not widgets
        # nor related with GFA itself
        self._conf = config.get_valid_config()
        self._reg = Registry()

        # Here we start with the Qt stuff

        # Create main window
        self.main_window = Ui_MainWindow()
        w = self.main_window
        w.setupUi(self)

        # Set-up the monitor which shows the temperature of the sensor
        # on the ¿FPGA?
        self._label_monitor = QtWidgets.QLabel()
        self._label_monitor.setAlignment(QtCore.Qt.AlignLeft)
        self._monitor = Monitor(self._label_monitor)
        w.statusBar.addPermanentWidget(self._label_monitor)

        self._status = StatusManager(w.configured_check, w.offsets_check, w.calibrated_check, w.discharge_check)

        self._is_connected = False
        self._is_configured = False

        # Initialization of GFA wrapper for gfaacesslib
        # TODO: Try to move things from this GFA wrapper to gfafunctionality
        self.gfa = gfa.GFAWrapper(self._expose_done_callback,
                                  self._error_callback,
                                  self._telemetry_callback,
                                  self._monitor.sensors_callback)

        # Instantiate external widgets
        self._adc = ADC(self.gfa)
        self._dac = DAC(self.gfa)
        self._offset = Offset(self.gfa, self._conf)
        self._diagnostics = Diagnostics(self.gfa)
        self._telemetry = Telemetry(self.gfa)
        self._pid = PID(self.gfa)
        self._pwm = PWM(self.gfa)
        self._alarms = Alarms(self.gfa)
        self._discharge = Discharge(self.gfa, self._conf, self._status)
        self._logs = Logs(self.gfa)
        self._settings = Settings(self.gfa, self._conf)
        self._ccd = CCD(self.gfa)
        self._versions = Versions(self.gfa)
        self._monitor_sensors = MonitorSensors(self.gfa)

        # Instantiate Status class which prints some
        # information on the status bar
        self._info = Information(w.label_info)
        w.statusBar.addWidget(w.label_info)

        # Set some placeholders
        w.combo_pattern.setCurrentText("Pattern")
        w.combo_mode.setCurrentText("Data Mode")
        w.text_dir.hide()

        # Also, hide gfa_id and cdd_serial by default until check_save is
        # enabled
        w.label_gfa_id.hide()
        w.gfa_id.hide()
        w.label_ccd_serial.hide()
        w.ccd_serial.hide()

        # Load default values
        self._load_gui_config()

        # Spawns a console for debugging purposes
        self._console_thread = threading.Thread(target=self._start_console)

        # From here until the end of the __init__ function
        # we are connecting different widgets with their functions

        # Helper function
        def triggered_connect(widget, func):
            widget.triggered.connect(lambda: self._force_connect_decorator(func))

        triggered_connect(w.actionClear_buffers, self._on_push_clear_buff)
        triggered_connect(w.actionClearStack, self._on_push_clear_stack)
        triggered_connect(w.actionCalibrate_ADC, self._on_push_adc)
        triggered_connect(w.actionDiagnostics, self._diagnostics.show)
        triggered_connect(w.actionSettings, self._settings.show)
        triggered_connect(w.actionADC, self._adc.show)
        triggered_connect(w.actionDAC, self._dac.show)
        triggered_connect(w.actionOffset, self._offset.show)
        triggered_connect(w.actionLogs, self._logs.show)
        triggered_connect(w.actionDischarge_config, self._discharge.show)
        triggered_connect(w.actionTelemetry, self._telemetry.show)
        triggered_connect(w.actionPID, self._pid.show)
        triggered_connect(w.actionPWM, self._pwm.show)
        triggered_connect(w.actionAlarms, self._alarms.show)
        triggered_connect(w.actionVersions, self._versions.show)
        triggered_connect(w.actionEnable_drivers, self._on_push_enable_drivers)
        triggered_connect(w.actionCCD, self._ccd.show)
        triggered_connect(w.actionSensors_monitor, self._monitor_sensors.show)
        triggered_connect(w.actionPower_up, self._on_push_power_up)
        triggered_connect(w.actionPower_down, self._on_push_power_down)
        triggered_connect(w.actionClear_error_state, self._on_push_clear_error)
        triggered_connect(w.actionDisable_drivers,
                          self._on_push_disable_drivers)
        w.actionStart_console.triggered.connect(self._on_push_start_console)

        self._connect_clicked(w.button_read, self._on_push_read)
        self._connect_clicked(w.button_stop_life_test, self._on_push_stop_life_test)
        self._connect_clicked(w.button_configure, self._on_push_configure)

        w.combo_test.currentIndexChanged.connect(self._on_test_index_changed)
        w.gfa_id.currentIndexChanged.connect(self._on_gfa_id_changed)
        w.button_connect.clicked.connect(self._on_push_connect)
        w.button_do_all.clicked.connect(self._on_push_do_all)
        w.tab.tabCloseRequested.connect(self._on_tab_close)
        w.check_fake.stateChanged.connect(self._fake_changed)
        w.check_save.stateChanged.connect(self._save_changed)
        self.exposeDone_signal.connect(self._on_signal_expose_done)
        #self.telemetryDone_signal.connect(self._on_telemetry_done)

    # Helper function that allows us to pass a function as a parameter to the
    # QT signal
    def _connect_clicked(self, button, funct):
        button.clicked.connect(lambda: self._force_connect_decorator(funct))

    @QtCore.pyqtSlot()
    def closeEvent(self, event):
        if self._console_thread.is_alive():
            log.warning("Console was not closed. Close it")

        log.info("Closing")
        self.gfa.disconnect(self._conf.shut_down_on_close)
        self._reg.close()

        event.accept()

    @QtCore.pyqtSlot()
    def _on_push_start_console(self):
        if not self._console_thread.is_alive():
            self._console_thread = threading.Thread(target=self._start_console)
            self._console_thread.start()
        else:
            log.info("Console already started. Doing nothing")

    def _start_console(self):
        code.interact(local=locals())

    def _load_gui_config(self):
        w = self.main_window
        w.storageRows.setValue(self._conf.geometry.storage_rows)
        w.activeRows.setValue(self._conf.geometry.active_rows)
        w.prescan.setValue(self._conf.geometry.prescan)
        w.overscan.setValue(self._conf.geometry.overscan)
        w.columns.setValue(self._conf.geometry.columns)
        w.combo_mode.setCurrentIndex(self._conf.expose.mode)
        w.spin_exposeTime.setValue(self._conf.expose.time)
        w.text_dir.setText(self._conf.images_dir)

        w.check_fake.setChecked(self._conf.expose.fake_data)
        self._fake_changed()

        ip = self._conf.server_ip
        w.text_ip.setText(ip)

    def _load_server_config(self):
        if not self._is_configured:
            raise Exception("GFA not configured")

        cfg = self._conf.timings

        # Adc
        self.gfa.set_adc_delay(self._conf.adc.delay)

        # Clocks
        clks = self.gfa.get_clk_timings()
        if cfg.hor.acq:
            clks.hor_acq = cfg.hor.acq
        if cfg.hor["del"]:
            clks.hor_del = cfg.hor["del"]
        if cfg.hor.postrg:
            clks.hor_postrg = cfg.hor.postrg
        if cfg.hor.prerg:
            clks.hor_prerg = cfg.hor.prerg
        if cfg.hor.rg:
            clks.hor_rg = cfg.hor.rg
        if cfg.hor.overlap:
            clks.hor_overlap = cfg.hor.overlap

        self.gfa.set_clk_timings()

        cfg = self._conf.pid
        self.gfa._gfa.pid.remote_set_components(cfg.p, cfg.i, cfg.d)

    # Decorator used by QT buttons that need the GFA to be connected
    @QtCore.pyqtSlot()
    def _force_connect_decorator(self, func):
        if not self._is_connected:
            self._connection_switch()

        if not self._is_connected and not self._is_configured:  # Unexpected error
            raise Exception("Unexpected error")

        try:
            func()
        except Exception as e:
            traceback.print_exc()
            self._info.show_error("EXCEPTION OCCURRED: {}".format(e))
            messages.show_fatal("{}".format(e), "Unexpected error")

        self._info.show_info("Executed: {}".format(func.__name__))

    def _on_tab_close(self, index):
        widget = self.main_window.tab.widget(index)
        self.main_window.tab.removeTab(index)

        # Fixme: it will throw a lot of errors like RuntimeError: wrapped C/C++
        # object of type QwtPlotCanvas has been deleted
        widget.setParent(None)
        widget.deleteLater()

        self._monitor.update()

    def save_current_config_table(self, tab_widget, conf):
        table = tab_widget.config_table
        item_number = 0

        def add_item(string, val):
            nonlocal item_number
            table_operations.create_item(table, item_number, string, val)
            item_number += 1

        add_item("Fake Data", conf.is_fake)
        add_item("Expose Time", conf.metadata.exptime)
        add_item("Data Mode", conf.mode)
        add_item("Pattern", conf.pattern)
        add_item("Rows num", conf.metadata.num_rows)
        add_item("Prescan", conf.metadata.prescan)
        add_item("Overscan", conf.metadata.overscan)
        add_item("Columns", conf.metadata.columns)

    def add_tab(self, title, conf):
        if conf.mode == 0:
            tab_widget = Ui_PlotImageWidget()
        elif conf.mode == 1:
            tab_widget = Ui_TriplePlotImageWidget()
        elif conf.mode == 4:
            tab_widget = Ui_PlotCurveWidget()
        else:
            tab_widget = Ui_DualPlotImageWidget()

        self.main_window.tab.addTab(tab_widget, str(title))

        i = self.main_window.tab.indexOf(tab_widget)
        self.main_window.tab.setCurrentIndex(i)

        return tab_widget

    def _set_enable_value_for_connection_info(self, val):
        w = self.main_window
        w.spin_port.setDisabled(val)
        w.spin_aport.setDisabled(val)
        w.text_ip.setDisabled(val)

    def _allow_modify_connection_info(self):
        self._set_enable_value_for_connection_info(True)

    def _disallow_modify_connection_info(self):
        self._set_enable_value_for_connection_info(False)

    def _execute_with_disabled_ui(self, message, func):
        w = self.main_window

        try:
            self._info.show_info(message)
            w.centralwidget.setDisabled(True)
            QtCore.QCoreApplication.instance().processEvents()
            func()
        finally:
            w.centralwidget.setDisabled(False)

    def _connection_switch(self):
        if self._is_connected:
            self._disconnect()
        else:
            self._connect()

    def _disconnect(self):
        w = self.main_window

        self.gfa.disconnect()
        self._info.show_error("DISCONNECTED")
        w.button_connect.setText("CONNECT")
        self._disallow_modify_connection_info()
        w.button_do_all.setDisabled(False)
        self._is_connected = False

    def _connect(self):
        w = self.main_window

        ip = w.text_ip.text()
        port = w.spin_port.value()
        aport = w.spin_aport.value()

        self.gfa.connect(ip, port, aport)
        self._is_connected = True

        exp_status = self.gfa.get_expctrl_info()
        if exp_status.ready_state:
            self._is_configured = True

        if self.gfa._gfa.sys.remote_api().answer["version"] != API_VERSION:
            messages.show_message("API MISMATCH", "API mismatch", QtWidgets.QMessageBox.Warning)

        if self._is_configured:
            # Update status, etc
            self._configure()

        self._info.show_success("CONNECTED")
        w.button_connect.setText("DISCONNECT")
        self._allow_modify_connection_info()
        w.button_do_all.setDisabled(True)

    def _configure_switch(self):
        if self._is_configured:
            self._unconfigure()
        else:
            self._configure()
            self._load_server_config()

        self._status.configured(self._is_configured)

    def _unconfigure(self):
        w = self.main_window

        self._execute_with_disabled_ui("Unconfiguring, please wait", self.gfa.unconfigure)
        self._info.show_info("UNCONFIGURED")
        w.button_configure.setText("CONFIGURE")
        self._is_configured = False

    def _configure(self):
        if not self._is_connected:
            raise Exception("Not connected, can not configure")

        self._execute_with_disabled_ui("Configuring, please wait", self.gfa.configure)
        self._is_configured = True

        self._info.show_success("CONFIGURED")
        self.main_window.button_configure.setText("UNCONFIGURE")
        self._status.configured(True)
        if self._conf.discharge.auto_enable:
            duration = self._conf.discharge.duration
            pixel = self._conf.discharge.pixel
            reset = self._conf.discharge.reset
            self.gfa.enable_discharge(duration, pixel, reset)
            self._status.discharge(True)
            self._discharge.set_checkbox(True)

        if self._conf.offsets.auto_enable:
            self._offset.write_offsets()
            self._status.offsets(True)

        if self._conf.adc.auto_calibrate:
            self.gfa.calibrate_adc()
            self._status.calibrated(True)

    def _do_expose(self, conf, num=0):
        try:
            self.gfa.set_config(conf)
            if num != 0:
                self.gfa.expose_loop(num)
            else:
                self.gfa.expose()
        except Exception as e:
            traceback.print_exc()
            self._info.show_error("EXCEPTION OCCURRED: {}".format(e))

    def _on_signal_expose_done(self, d):
        cfg = d["config"]

        # Avoid plotting exposures of the CCD widget
        if cfg and cfg.test == gfa.Test.NONE and not cfg.show_plot:
            return

        im = d["image"]
        elapsed_time = d["elapsed_time"]

        self._monitor.update()

        if cfg.test == gfa.Test.NONE:
            if cfg.storage == gfa.Storage.read:
                new_tab = self.add_tab(im.image_id, cfg)
                new_image(new_tab, im, cfg)
                self.save_current_config_table(new_tab, cfg)
                self._reg.add_row([elapsed_time])
            self._info.show_info("EXPOSE DONE: {}s".format(elapsed_time))
        else:
            im_name = cfg.image_name.split("_")
            test_name = im_name[0]
            test_number = im_name[-1]
            self._info.show_info(
                "{} TEST {}".format(test_name, int(test_number)))

    def _expose_done_callback(self, im, cfg, elapsed_time):
        d = {"image": im, "config": cfg, "elapsed_time": elapsed_time}

        self.exposeDone_signal.emit(d)

    def _error_callback(self, msg):
        self._info.show_error("EXCEPTION OCCURRED: {}".format(str(msg)))

    # def _on_telemetry_done(self, data):
    #     self._telemetry.telemetry_callback(data)

    # Currently unused
    def _telemetry_callback(self, data):
        pass
        # self.telemetryDone_signal.emit(data)

    @QtCore.pyqtSlot()
    def _fake_changed(self):
        if not self.main_window.check_fake.isChecked():
            self.main_window.combo_pattern.setDisabled(True)
        else:
            self.main_window.combo_pattern.setEnabled(True)

    @QtCore.pyqtSlot()
    def _save_changed(self):
        w = self.main_window
        if not self.main_window.check_save.isChecked():
            self.main_window.text_dir.hide()
            w.label_gfa_id.hide()
            w.gfa_id.hide()
            w.label_ccd_serial.hide()
            w.ccd_serial.hide()
        else:
            self.main_window.text_dir.show()
            w.label_gfa_id.show()
            w.gfa_id.show()
            w.label_ccd_serial.show()
            w.ccd_serial.show()

    @QtCore.pyqtSlot(int)
    def _on_test_index_changed(self, index):
        w = self.main_window
        test_type = gfa.Test(index)

        w.spin_exposeTime.setDisabled(False)
        w.check_save.setDisabled(True)
        w.check_save.setChecked(True)
        w.button_stop_life_test.setDisabled(True)

        try:
            w.check_save.setChecked(self.def_check_save)
            w.combo_storage.setCurrentIndex(self.def_storage)
        except:
            self.def_check_save = w.check_save.isChecked()
            self.def_storage = w.combo_storage.currentIndex()

        if test_type == gfa.Test.NONE:
            w.check_save.setDisabled(False)
            w.check_save.setChecked(self.def_check_save)

            w.combo_storage.setEnabled(True)
        else:
            w.combo_storage.setCurrentIndex(0)
            w.combo_storage.setEnabled(False)
            w.spin_exposeTime.setDisabled(True)

            if test_type == gfa.Test.BIAS:
                w.spin_exposeTime.setValue(0)
            elif test_type == gfa.Test.DC:
                w.spin_exposeTime.setValue(60)
            elif test_type == gfa.Test.FCTE:
                w.spin_exposeTime.setValue(7)
            elif test_type == gfa.Test.LIFE:
                w.spin_exposeTime.setEnabled(True)
                w.button_stop_life_test.setEnabled(True)
            else:
                # The next tests have a dynamic exp time: PTC, FLATS, DARKS, PSF
                w.spin_exposeTime.setValue(0)

    @QtCore.pyqtSlot(int)
    def _on_gfa_id_changed(self, index):
        w = self.main_window

        ccd_serial_map = {
            0: "NO-GFA",
            1: "13072-18-04",
            2: "13072-22-04",
            3: "13072-24-06",
            4: "13072-18-08",
            5: "13072-24-01",
            6: "16153-12-07",
            7: "16153-08-03",
            8: "16163-13-02",
            9: "13072-07-07",
            10: "13072-22-06",
            11: "13072-18-07",
            12: "13072-24-08",
        }

        w.ccd_serial.setText(ccd_serial_map[index])

    @QtCore.pyqtSlot()
    def _on_push_connect(self):
        try:
            self._connection_switch()
        except Exception as e:
            traceback.print_exc()
            messages.show_fatal("{}".format(e), "Error when connecting")
            self._info.show_error("EXCEPTION OCCURRED: {}".format(e))

    def _on_push_do_all(self):
        try:
            if not self._is_connected:
                self._connection_switch()

            self._configure_switch()
            self.gfa.power_up()
        except Exception as e:
            traceback.print_exc()
            messages.show_fatal("{}".format(e), "Error")
            self._info.show_error("EXCEPTION OCCURRED: {}".format(e))

    def _on_push_configure(self):
        try:
            self._configure_switch()
        except Exception as e:
            traceback.print_exc()
            messages.show_fatal("{}".format(e), "Error when configuring")
            self._info.show_error("EXCEPTION OCCURRED: {}".format(e))

    def _on_push_power_up(self):
        self.gfa.power_up()

    def _on_push_power_down(self):
        self.gfa.power_down()

    def _on_push_clear_error(self):
        self.gfa.clear_error()

    def _on_push_stop_life_test(self):
        if self._t:
            self._t.stop_life_test = True

    def _on_push_read(self):
        w = self.main_window

        columns = w.columns.value()
        num_rows = w.activeRows.value() + w.storageRows.value()
        overscan = w.overscan.value()
        prescan = w.prescan.value()
        expose_time = w.spin_exposeTime.value()
        gfa_id = w.gfa_id.currentText()
        ccd_serial = w.ccd_serial.text()
        metadata = RawImageMetadata(
            columns, num_rows, overscan, prescan, expose_time, gfa_id, ccd_serial)

        conf = gfa.Config(is_save=w.check_save.isChecked(),
                          is_clear=w.check_clear.isChecked(),
                          is_fake=1 if w.check_fake.isChecked() else 0,
                          out_dir=w.text_dir.text(),
                          pattern=w.combo_pattern.currentIndex(),
                          mode=w.combo_mode.currentIndex(),
                          storage=gfa.Storage(w.combo_storage.currentIndex()),
                          metadata=metadata,
                          test=gfa.Test(w.combo_test.currentIndex())
                          )

        if conf.test == gfa.Test.NONE:
            self._do_expose(conf)
            self._info.show_info("STARTING_EXPOSE")
        else:
            self._t = Tests(self, conf)
            self._t.run()

    def _on_push_clear_stack(self):
        self.gfa.clear_stack()

    def _on_push_clear_buff(self):
        self.gfa.clear_buff()

    def _on_push_enable_drivers(self):
        self.gfa.enable_drivers()

    def _on_push_disable_drivers(self):
        self.gfa.disable_drivers()

    def _on_push_adc(self):
        self.gfa.calibrate_adc()
        self._status.calibrated(True)
