import csv
from time import strftime


class Registry(object):

    def __init__(self):
        self.file = None

    def _create_file(self):
        timestamp = strftime("%y%m%d%H%M%S")
        file_name = "{}/{}.csv".format("/tmp", timestamp)
        self.file = open(file_name, "w", encoding='utf-8')

        file_info = "# Created on {}\n".format(timestamp)
        self.file.write(file_info)
        self._log_file = csv.writer(self.file)

        first_row = ["TIMESTAMP", "ELAPSED_EXPOSE_TIME"]

        self._log_file.writerow(first_row)

    def add_row(self, row):
        if self.file is None:
            self._create_file()
        timestamp = strftime("%y%m%d%H%M%S")
        self._log_file.writerow([timestamp] + row)
        self.file.flush()

    def close(self):
        if self.file is not None:
            self.file.close()
