#!/bin/bash

# FIXME: Very insecure
#xhost +

xhost local:0

docker build -f Dockerfile -t gfagui . || exit
docker run --rm -it --privileged -e DISPLAY=$DISPLAY -v "$HOME"/.Xauthority:/root/.Xauthority -v /tmp/.X11-unix:/tmp/.X11-unix gfagui
