import gfagui.main as g
g.main()
