import sys, csv
import numpy as np
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
from gfaaccesslib.raws.rawdatamanager import RawDataImage, RawDataManager

manager = RawDataManager()
r = RawDataImage(0, manager)

amp0 = sys.argv[1]
#amp0 = "/tmp/test.csv"

amp0_array = []

for a in r.amplifiers:
    with open(amp0, "r") as f:
        reader = csv.reader(f, delimiter=",")
        for _, line in enumerate(reader):
            # Why CSV module sucks so much
            if line[0].startswith("#"):
                continue

            amp0_array.append(int(line[1]))
            """
            l = []
            for i in range(1, len(line)):
                l.append(int(line[i]))
            """
        a.add_row(amp0_array, {"ccd_row_num": 1111})
    break


a = GUIQWTPlotter(r)
a.show_as_waveform(maxWidth=5000, max_lines=1)
