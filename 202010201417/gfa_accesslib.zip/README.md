# GFA Access Library

## Overview
Implementation of the interface library between a standard PC running linux and a real or simulated GFA.

On first stage there will be a library in python for the client and an embedded c/c++ library to implement a server which will execute commands on the GFA

Check api_proposal.py to see the proposed interface to Kevin Reil.

## Implementation

There are 2 main components, a server and an access library. This repository is the python implementation of the access library. 

Server is being developed in c++ and its repository is located at git@gitlab01.pic.es:desi/gfaserver.git . Server should be compilable for arm and intel. This lets implement a simulated system that can run either on a standard linux pc or an arm zynq system.
 
Transfer protocol is language agnostic as it depends on json only. Inside python folder, the library is being developed in python, but it could be developed in any other language if required.

## JSON Protocol

Transfer protocol between client and sever is JSON based.

Client sends an json object to the server which at its turn returns the same object updated with new information to the client. This type of JSON objects can contain next keys:

 - command (string): Unique descriptor of the command to execute
 - arguments (object): Dictionary which contains all arguments of the command to execute
 - answer (object): Dictionary that contains the answer to the command
 - created_on: UTC timestamp of when this command was created
 - received_on: UTC timestamp of when this packet was received by client
 - elapsed_ms: Server can add how much time it took to execute the command
 - status: Status of the command to be executed can have several values:
    - REQ: JSON object describes the client request
    - ACK: Server acknowledges that has received the petition
    - ANS: Server answers with result of the execution of the command
    - DONE: Command is done
    - ERROR: There was an error executing this command

JSON objects are created by client and then are sent and received by client and server. At each step, the object is modified and then sent to the other end of the communication.

In order to send the objects, JSON is serialized at source and deserialized at destination.


# Python 3 port and dependencies

## To use guiqwt

  sudo apt-get install python3-dev libblas-dev liblapack-dev gfortran 
  
PyQt5 is need. Some default versions for PyQt5 on Ubuntu do not work with PythonQWT. My experience is to install using package manager:
  sudo aptitude install python3-pyqt5 python3-pyqt5.qtsvg
and if an error occurs when executing guidata or guiqwt tests, uninstall python3-sip, python3-pyqt5, download from riverbank and compile 

  sudo -H pip3 install Cython
  sudo -H pip3 install numpy
  sudo -H pip3 install guidata
  sudo -H pip3 install scipy 
  sudo -H pip3 install --upgrade guiqwt
