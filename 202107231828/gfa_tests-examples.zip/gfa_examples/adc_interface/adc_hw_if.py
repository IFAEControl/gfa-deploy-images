#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" An example on how to read the hardware values of the ADC interface

"""
__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2020'
__date__ = '12/11/2020'
__credits__ = ['Otger Ballester', ]
__license__ = 'GPL'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'


from gfaaccesslib.gfa import GFA

IP = '172.16.17.82'
PORT = 32000
APORT = 32001

gfa = GFA(IP, PORT)
# You need to setup everything and have synchronized the ADC
delays = gfa.adccontroller.remote_get_if_delays()
print(f"Delays applied: {delays}")
bitslips = gfa.adccontroller.remote_get_if_bitslips()
print(f"bitslips applied: {bitslips}")
# Previous two calls are also part of the full status
full_status = gfa.adccontroller.update_and_get_status()
print(f"full adc iface status: {full_status}")

# Required if we provide an APORT to gfa instance, otherwise, not needed
gfa.close()

