#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os
import datetime

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

PORT = 32000
APORT = 32001

CSV_FILE = f"{datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S_adc_synch_debug.csv')}"


def save_header(gfa_instance, comment=None):
    status_dict = gfa_instance.adccontroller.update_and_get_status()
    tmp = f"# File_name: {datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S_adc_synch_debug.csv')}\n"
    if comment:
        tmp += f"# comment: {comment}\n"
    tmp += 'timestamp, last_action, '
    for j in sorted(status_dict.keys()):
        for k in sorted(status_dict[j].keys()):
            tmp += f"{j}.{k}, "
    print(tmp)
    with open(CSV_FILE, 'a') as fp:
        fp.write(f"{tmp}\n")


def save_values_csv(action, gfa_instance):
    status_dict = gfa_instance.adccontroller.update_and_get_status()
    tmp = f"{datetime.datetime.utcnow().timestamp()}, {action}, "
    for j in sorted(status_dict.keys()):
        for k in sorted(status_dict[j].keys()):
            tmp += f"{status_dict[j][k]}, "
    print(tmp)
    with open(CSV_FILE, 'a') as fp:
        fp.write(f"{tmp}\n")


def calibrate(gfa_instance):
    save_values_csv('init script', gfa_instance)

    # Wake up ADC if it is powerdown
    gfa_instance.adccontroller.set_adc_powerdown_pin(False)
    # Reset ADC chip
    gfa_instance.adccontroller.set_adc_reset_pin(0)
    gfa_instance.adccontroller.set_adc_reset_pin(1)
    save_values_csv('wake up adc and reset chip', gfa_instance)

    # print("# Resetting ADC controller")
    gfa_instance.adccontroller.reset_adc_controller()
    save_values_csv('reset adc controller', gfa_instance)
    time.sleep(0.001)
    save_values_csv('sleep 1ms', gfa_instance)

    # print("# Init calibration")
    gfa_instance.adccontroller.adc_init_calib()
    gfa_instance.adccontroller.remote_get_status()
    if gfa_instance.adccontroller.status.init_status.state != 's_init':
        raise Exception('System should be at calibration')
    save_values_csv('init calibration', gfa_instance)

    # print("# reset adc chip by spi")
    gfa_instance.adccontroller.spi_write(0x0, 0x1)
    time.sleep(0.1)
    gfa_instance.adccontroller.spi_write(0x0, 0x0)
    # time.sleep(0.1)
    save_values_csv('reset adc chip by spi', gfa_instance)  # no change should be seen

    # print("# configure serialization on adc")
    gfa_instance.adccontroller.spi_write(0x46, 0x8801)
    save_values_csv('configure serialization on adc', gfa_instance)  # no change should be seen

    # print("# set expected data pattern")
    gfa_instance.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)
    save_values_csv('set expected data pattern to 0xf0f0', gfa_instance)

    # print("# set adc to output sync pattern")
    time.sleep(0.1)
    gfa_instance.adccontroller.spi_write(0x45, 0x2)
    save_values_csv('set adc to output sync pattern', gfa_instance)

    # print("# start align frame")
    gfa_instance.adccontroller.adc_calib_align_frame()
    save_values_csv('start align frame', gfa_instance)  # it could be too fast that we already see it finished here

    # check it has finished aligning frame
    for i in range(10):
        gfa_instance.adccontroller.remote_get_status()
        if gfa_instance.adccontroller.status.init_status.frame_aligned:
            break
    else:
        raise Exception('Frame could not be aligned')
    save_values_csv('align frame finished', gfa_instance)

    gfa_instance.adccontroller.adc_calib_align_data()
    save_values_csv('start align data', gfa_instance)

    # # check it has finished aligning frame
    # for _ in range(10):
    #     gfa_instance.adccontroller.remote_get_status()
    #     if gfa_instance.adccontroller.status.init_status.good_pattern_full:
    #         break
    # else:
    #     save_values_csv('align data could not finish!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', gfa_instance)
    #     raise Exception('Data could not be aligned')
    # save_values_csv('align data finished', gfa_instance)

    gfa_instance.adccontroller.adc_calib_bitslip()
    save_values_csv('adc calib bitslip', gfa_instance)

    time.sleep(0.1)
    save_values_csv('sleep 100ms', gfa_instance)

    # remove pattern
    gfa_instance.adccontroller.spi_write(0x45, 0x0)
    save_values_csv('remove adc pattern', gfa_instance)

    gfa_instance.adccontroller.adc_stop_calib()
    save_values_csv('stop calib', gfa_instance)

    time.sleep(0.1)
    save_values_csv('sleep 100ms', gfa_instance)


if __name__ == "__main__":

    print("Connecting to GFA @{0}:{1}".format(IP, PORT))
    log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

    # There is no need to subscribe to async port
    gfa = GFA(IP, PORT)

    gfa.adccontroller.remote_set_bit_time_value(16)
    save_header(gfa, 'Run with different bit_time (=16) and executed from a fresh boot system')

    for _ in range(1):
        calibrate(gfa)
        time.sleep(2)

    gfa.close()
