#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
import logging

import time
import sys
import os
import argparse

__author__ = 'otger'

IP_EMBEDDED = '172.16.17.142'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_EMBEDDED
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
IP = '172.16.17.82'
PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
parser.add_argument("-u", "--update", help="Update values", action='store_true')
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT, APORT))


gfa = GFA(args.ip, PORT)

if args.update:
    ans = gfa.exposecontroller.remote_get_telemetry()
    time.sleep(1.0)
ans = gfa.telemetry.remote_get_voltage_values()
print("remote_get_voltage_values(): {}".format(ans.answer))
ans = gfa.telemetry.remote_get_status()
print("remote_get_status(): {}".format(ans.answer))

print(gfa.telemetry.ccd_voltages)

print(gfa.telemetry.ccd_voltages.csv_fields)
print(gfa.telemetry.ccd_voltages.csv)

gfa.close()
