#!/usr/bin/python3
# -*- coding: utf-8 -*-
from copy import deepcopy
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
import logging
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
from gfafunctionality.raws import RawImageFile, RawRepresentation
import time
import sys
import os

__author__ = 'otger'

IP = "172.16.17.82"

PORT = 32000
APORT = 32001

if len(sys.argv) < 3:
    sys.exit(1)
"""
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT, APORT))
"""

gfa = GFA(IP, PORT)
pwr = gfa.powercontroller

def get_telemetry():
    v = gfa.telemetry.remote_get_voltage_values()
    #print("remote_get_voltage_values(): {}".format(ans.answer))
    ans = gfa.telemetry.remote_get_status()
    #print("remote_get_status(): {}".format(ans.answer))
    ans = gfa.telemetry.remote_get_times()
    #print("remote_get_times(): {}".format(ans.answer))
    
    #print(gfa.telemetry.ccd_voltages)
    return gfa.telemetry.ccd_voltages

before = deepcopy(get_telemetry())

gfa.exposecontroller.remote_get_telemetry()
time.sleep(1.0)

#pwr.remote_get_voltages()
print("Changing {} from {} to {}".format(sys.argv[1], getattr(pwr.voltages, sys.argv[1]).volts, sys.argv[2]))
getattr(pwr.voltages, sys.argv[1]).volts = float(sys.argv[2])
pwr.remote_set_voltages()

gfa.exposecontroller.remote_get_telemetry()
time.sleep(1.0)

after = deepcopy(get_telemetry())

print("{:25}   {:25}\t\t{}".format("SENSOR", "BEFORE", "AFTER"))
for k in sorted(before._values.keys()):
    if before._values[k].counts != after._values[k].counts:
        print("{:15}   {:10}  {:10}".format(k, round(before._values[k].value, 3), before._values[k].counts), end="\t\t")
        print("{:10}   {:10}".format(round(after._values[k].value, 3), after._values[k].counts))
#        print(k, round(after._values[k].value, 3), after._values[k].counts)


gfa.close()
