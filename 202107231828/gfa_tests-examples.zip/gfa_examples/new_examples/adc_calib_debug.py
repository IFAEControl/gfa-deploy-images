#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import time
import os

import argparse


IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(formatter)
log.addHandler(ch)

log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)


def update_and_get_status(adccontroller):
    s = [time.time()]
    adccontroller.remote_get_status()
    s.append(time.time())
    adccontroller.remote_get_init_rx_data()
    s.append(time.time())
    adccontroller.remote_get_init_rx_expected_pattern()
    s.append(time.time())
    adccontroller.remote_get_if_delays()
    s.append(time.time())
    adccontroller.remote_get_if_bitslips()
    s.append(time.time())
    adccontroller.remote_get_bit_time_value()
    s.append(time.time())

    t = []
    for i in range(1, len(s)-1):
        t.append(s[i]-s[i-1])
    return {
        'hw_if': adccontroller.hw_if.as_dict(),
        'sync_status': adccontroller.status.init_status.as_dict(),
        'status': adccontroller.status.as_dict()
    }, t


import pprint
# repetitions = 10
# start = time.time()
# times = []
# for _ in range(repetitions):
#     _, s = update_and_get_status(gfa.adccontroller)
#     times.append(s)
# print(f"Elapsed {time.time()-start:.2} seconds to get {repetitions} status commands")
# for el in times:
#     print(el)
# # pprint.pprint(gfa.adccontroller.update_and_get_status(), indent=2)
# print("status done")

print("remote_get_status")
pprint.pprint(gfa.adccontroller.remote_get_status().answer)

print("remote_get_init_rx_data")
pprint.pprint(gfa.adccontroller.remote_get_init_rx_data().answer)

print("remote_get_init_rx_expected_pattern")
pprint.pprint(gfa.adccontroller.remote_get_init_rx_expected_pattern().answer)

print("remote_get_if_delays")
pprint.pprint(gfa.adccontroller.remote_get_if_delays().answer)

print("remote_get_if_bitslips")
pprint.pprint(gfa.adccontroller.remote_get_if_bitslips().answer)

print("remote_get_bit_time_value")
pprint.pprint(gfa.adccontroller.remote_get_bit_time_value().answer)

try:
    gfa.adccontroller.set_adc_reset_pin(0)
    gfa.adccontroller.set_adc_reset_pin(1)
    gfa.adccontroller.set_adc_powerdown_pin(False)
    gfa.adccontroller.reset_adc_controller()

    gfa.adccontroller.adc_init_calib()
    gfa.adccontroller.remote_get_status()
    if gfa.adccontroller.status.init_status.state != 's_init':
        raise Exception('System should be at calibration')

    # reset adc chip by spi
    gfa.adccontroller.spi_write(0x0, 0x1)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x0, 0x0)
    time.sleep(0.1)

    # configure serialization on adc
    gfa.adccontroller.spi_write(0x46, 0x8801)

    # set expected data pattern
    gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)

    # set adc to output sync pattern
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x45, 0x2)

    # ToDo: read bitslips and delays

    # start align frame
    gfa.adccontroller.adc_calib_align_frame()

    # check it has finished aligning frame
    for i in range(10):
        gfa.adccontroller.remote_get_status()
        if gfa.adccontroller.status.init_status.frame_aligned:
            break
    else:
        raise Exception('Frame could not be aligned')

    # ToDo: read bitslips and delays

    # align data
    gfa.adccontroller.adc_calib_align_data()

    gfa.adccontroller.adc_calib_bitslip()

    gfa.adccontroller.remote_get_status()
    gfa.adccontroller.remote_get_init_rx_expected_pattern()
    gfa.adccontroller.remote_get_init_rx_data()
    # print(gfa.adccontroller.status)

    # remove pattern
    gfa.adccontroller.spi_write(0x45, 0x0)

    gfa.adccontroller.adc_stop_calib()

except Exception:
    log.exception(f"Thing went south")
finally:
    gfa.close()
