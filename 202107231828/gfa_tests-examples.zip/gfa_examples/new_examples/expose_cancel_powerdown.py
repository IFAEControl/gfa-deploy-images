#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
from gfaaccesslib.api_helpers import GFAExposureLock
import logging
import sys
import os
import time

from examples.new_examples.defaults import defaults

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

EXP_TIME_MS = 20000

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:

    defaults.set_default_geom(gfa)

    defaults.set_default_timings(gfa)

    defaults.gfa_powerup_bias(gfa)  # only power up if needed

    defaults.init_adc(gfa)
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:

    print(f"last image id: {sorted(gfa.raws.list_images())[-1] if gfa.raws.list_images() else 'None'}")

    defaults.set_default_ccd_expose_stack(gfa, exposure_time_ms=2000)

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)

    acq_lock = GFAExposureLock()
    gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
    acq_lock.acquire()

    # So we can launch the data taking
    gfa.exposecontroller.remote_start_stack_exec()

    # exposecontroller.remote_cancel_stack_powerdown_ccd returns once image has been canceled and ccd bias has
    # been removed
    # If a direct return is desired, the alternative is to call:
    #  - gfa.clockmanager.remote_cancel_stack_exec()
    #  - check that status has changed to ready
    #  - gfa.exposecontroller.remote_power_down()
    #  - manually check that bias has been removed (an example can be seen on this example)

    # With an exposure time of 2 seconds (2000ms) and canceling after:
    #  - 2 seconds: the image is still exposing and cancels without problems
    #  - 3.5 seconds: the clockmanager has started to read the image. Cancel works like a charm and partial
    #    data is received
    #  - 7.5 seconds: there is no image taking running, bias is removed

    time.sleep(3.5)
    start = time.time()
    gfa.exposecontroller.remote_cancel_stack_powerdown_ccd()
    print('')

    # we wait, that should be done by registering at an async message (TBI)
    acq_lock.acquire()
    acq_lock.release()

    last_im_id = sorted(gfa.raws.list_images())[-1] if gfa.raws.list_images() else None
    print(f"last image id: {last_im_id}")
    # get last image
    if last_im_id:
        im = gfa.raws.get_image(last_im_id)
        print(im.get_ampdata_shape())

    # Check that bias is not applied
    print("Checking if bias still applied ", end='')
    for i in range(10):
        time.sleep(0.5)
        gfa.exposecontroller.remote_get_status()
        if not gfa.exposecontroller.status.is_powered:
            print(' [ok] System correctly shutdown')
            break
        print('.', end='')
    else:
        print(' [Fail] Bias still applied')

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
