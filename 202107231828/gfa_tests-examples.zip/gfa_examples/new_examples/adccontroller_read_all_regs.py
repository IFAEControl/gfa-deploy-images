#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import pprint
import os

import argparse


IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)

try:
    ans = gfa.adccontroller.remote_read_all_regs()
    pprint.pprint(ans.json)

    ans = gfa.adccontroller.remote_write_register(8, 25)
    ans = gfa.adccontroller.remote_read_all_regs()
    pprint.pprint(ans.json)


except Exception:
    log.exception(f"Thing went south")
finally:
    gfa.close()
