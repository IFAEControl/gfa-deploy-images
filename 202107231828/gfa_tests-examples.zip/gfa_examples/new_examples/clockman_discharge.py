#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import time
import os

import argparse


IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT)


def print_discharge(reg_41):
    print(f"length: {reg_41 & 0xff} - pixel_start: {(reg_41 & (1 << 15)) >> 15}"
          f"- reset_start: {(reg_41 & (1 << 14)) >> 14} - vert_rt: {(reg_41 & (1 << 13)) >> 13}"
          f"- vert_oi: {(reg_41 & (1 << 12)) >> 12} - vert_tr: {(reg_41 & (1 << 11)) >> 11}")

try:
    gfa.exposecontroller.remote_get_status()
    print(gfa.exposecontroller.status)

    ans = gfa.clockmanager.remote_read_all_regs()
    print_discharge(ans.json['answer']['reg_41'])

    print("Set length to 50")
    ans = gfa.clockmanager.remote_enable_discharge(length=50, reset_start=True, pixel_start=True,
                                                   vert_oi=True, vert_rt=True, vert_tr=True)
    ans = gfa.clockmanager.remote_read_all_regs()
    print_discharge(ans.json['answer']['reg_41'])

    # print("Set length to 254")
    # ans = gfa.clockmanager.remote_enable_discharge(length=254)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])
    #
    # print("set reset_start")
    # ans = gfa.clockmanager.remote_enable_discharge(length=0, reset_start=True)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])
    #
    # print("Set pixel_start")
    # ans = gfa.clockmanager.remote_enable_discharge(length=0, pixel_start=True)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])
    #
    # print("Set vert_tr")
    # ans = gfa.clockmanager.remote_enable_discharge(length=0, vert_tr=True)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])
    #
    # print("Set vert_oi")
    # ans = gfa.clockmanager.remote_enable_discharge(length=0, vert_oi=True)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])
    #
    # print("Set vert_rt")
    # ans = gfa.clockmanager.remote_enable_discharge(length=0, vert_rt=True)
    # ans = gfa.clockmanager.remote_read_all_regs()
    # print_discharge(ans.json['answer']['reg_41'])


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
