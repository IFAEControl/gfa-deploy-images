#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" A simple python script

"""
__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '19/5/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

import numpy as np

if __name__ == "__main__":
    data = np.loadtxt(open("continuous_exp_memory_data.csv", "rb"), delimiter=",")
    # print(data)
    import matplotlib.pyplot as plt

    # plotting
    plt.title("Line graph")
    plt.plot(data[:, 0], data[:, 2], color="red")
    plt.plot(data[:, 0], data[:, 3], color="blue")
    plt.plot(data[:, 0], data[:, 4], color="green")
    plt.xlabel("Image Id")
    plt.ylabel("Used Memory [MB]")
    plt.show()