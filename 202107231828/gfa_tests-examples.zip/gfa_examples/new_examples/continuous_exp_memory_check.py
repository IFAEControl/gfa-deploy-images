#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

import pprint

from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log
import os
import psutil
import json
import sys
from datetime import datetime, timezone
import gc

import logging
from logging.handlers import RotatingFileHandler
from gfaaccesslib.logger import log, comm_debug_log, formatter

fh = RotatingFileHandler(filename='/home/otger/.gfa/logs/cont_exp_mem_check_gfaacesslib.log',
                         maxBytes=5 * 1024 * 1024, backupCount=25)
fh.setLevel(level=logging.DEBUG)
fh.setFormatter(formatter)
log.addHandler(fh)

fh2 = RotatingFileHandler('/home/otger/.gfa/logs/cont_exp_mem_check_comm_debug.log',
                          maxBytes=5 * 1024 * 1024, backupCount=25)
fh2.setLevel(level=logging.DEBUG)
fh2.setFormatter(formatter)
comm_debug_log.addHandler(fh2)

NUM_OF_IMAGES = 25000

IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO


CORRECT_IM_SIZE = (1032, 1106)

prescan_cols = 0
overscan_cols = 0
amplifier_active_cols = 0


def image_start_cb(header, jsondata):
    global prescan_cols
    global overscan_cols
    global amplifier_active_cols
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)

    prescan_cols = j['prescan_cols']
    overscan_cols = j['overscan_cols']
    amplifier_active_cols = j['amplifier_active_cols']
    pprint.pprint(jsondata)


if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

gfa = GFA(IP, PORT, APORT)

acq_lock = GFAExposureLock()

gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
gfa.async_manager.add_new_image_callback(image_start_cb)


def do_expose(storage, active, read_both=True):
    gfa.adccontroller.spi_write(0xf, 0x0)
    gfa.adccontroller.spi_write(0x2a, 0x0)
    gfa.adccontroller.adc_start_acq()
    g = gfa.clockmanager.stack

    g.clear()
    g.add_new_image_cmd()
    g.add_set_modes_cmd(True, True, True, True)
    g.add_dump_rows_cmd(storage+active)
    g.add_wait_cmd(0)
    if read_both:
        g.add_read_rows_cmd(active+storage)
    else:
        g.add_dump_rows_cmd(storage)
        g.add_read_rows_cmd(active)
    g.add_none_cmd()
    gfa.clockmanager.remote_set_stack_contents()
    gfa.buffers.remote_set_data_provider(0, 0)

    acq_lock.acquire()
    gfa.exposecontroller.remote_start_stack_exec()

    acq_lock.acquire()
    acq_lock.release()


def get_memo():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1048576  # To have it in MB


try:
    i = 0
    file_time = datetime.now(tz=timezone.utc).strftime('%Y%m%d%H%M%S')
    while i < NUM_OF_IMAGES:
        process = psutil.Process(os.getpid())
        memo_start = get_memo()
        do_expose(516, 516)
        im_num = sorted(gfa.raws.list_images())[-1]
        img = gfa.raws.get_image(im_num)
        memo_before_rem = get_memo()
        im = gfa.raws.rem_image(im_num)
        size_ok = True
        for amp in im.amplifiers:
            size_ok = amp.get_im_shape() == (1032, 1106)
        if size_ok is False:
            print(f"\n\n Wrong size on im {im.image_id}: {str([x.get_im_shape() for x in im.amplifiers])}\n\n")
        del im
        collected = gc.collect()
        memo_after_rem = get_memo()
        with open(f"continuous_exp_memory_data_{file_time}.csv", "a") as myfile:
            msg = ', '.join([str(im_num),
                             str(datetime.now(tz=timezone.utc).timestamp()),
                             f"{memo_start:.3f}",
                             f"{memo_before_rem:.3f}",
                             f"{memo_after_rem:.3f}",
                             str(len(gfa.raws.list_images())),
                             str(collected),
                             str(size_ok)
                             ])
            print(msg)
            # print(gc.get_stats())
            myfile.write(msg+"\n")
        i += 1

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
