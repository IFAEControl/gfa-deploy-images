#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '6/4/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

""" 
A script that sets up the GFA ADC to output a ramp, acquires several lines of data and checks:

 - All data from 0 to 2**16 is represented
 - All slices of data are incresing except for 65536 -> 0
"""

import time


def set_gfa_to_output_ramp(gfa):
    gfa.adccontroller.spi_write(0x25, 0x40)


def acquire_ramps(gfa, rows=20, columns=12, lock=None):
    #  A column is more or less 400 samples of raw data in normal time values
    # 20 columns are (in normal times) 7920 samples, which fills half the buffer. This allows to send the data through
    # dma while next line is being buffered. If we increase the number of columns, then it will probably fail
    gfa.adccontroller.spi_write(0xf, 0x0)
    gfa.adccontroller.spi_write(0x2a, 0x0)
    gfa.adccontroller.adc_start_acq()
    g = gfa.clockmanager.stack

    g.clear()
    g.add_new_image_cmd()
    g.add_set_modes_cmd(True, True, True, True)
    g.add_set_roi_conf_cmd(skip_columns=0, roi_width=columns)
    g.add_read_rows_roi_cmd(rows)
    g.add_none_cmd()
    gfa.clockmanager.remote_set_stack_contents()
    gfa.buffers.remote_set_data_provider(0, 4)

    if lock:
        lock.acquire()
    gfa.exposecontroller.remote_start_stack_exec()

    if lock:
        lock.acquire()
        lock.release()


def get_last_im(gfa):
    last_wave_imnum = list(gfa.raws.list_images())[-1]
    return gfa.raws.get_image(last_wave_imnum)


def clean_data(image):
    data = [[[0xffff & x for x in row.data] for row in amp.rows] for amp in image.amplifiers]
    return data


def check_data(data):
    errors = []
    for amp in data:
        amp_errs = 0
        total_data = 0
        for row in amp:
            e, d = check_ramp(row)
            amp_errs += e
            total_data += d
        errors.append((amp_errs, total_data))
    return errors


def check_ramp(numbers: list):
    errors = 0
    # First element is an error always
    prev = numbers[1]
    for el in numbers[2:]:
        if prev == 2**16 - 1:
            if el != 0:
                errors += 1
            prev = el
            continue
        if el != prev + 1:
            errors += 1
        prev = el
    return errors, len(numbers)


def sync_adc(gfa):

    gfa.adccontroller.set_adc_reset_pin(0)
    gfa.adccontroller.set_adc_reset_pin(1)
    gfa.adccontroller.set_adc_powerdown_pin(False)
    gfa.adccontroller.reset_adc_controller()

    gfa.adccontroller.adc_init_calib()

    ans = gfa.adccontroller.remote_read_all_regs().answer
    if gfa.adccontroller.status.init_status.state != 's_init':
        raise Exception('System should be at calibration')

    # reset adc chip by spi
    gfa.adccontroller.spi_write(0x0, 0x1)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x0, 0x1)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x0, 0x0)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x0, 0x0)
    time.sleep(0.1)

    # configure serialization on adc
    gfa.adccontroller.spi_write(0x46, 0x8801)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x46, 0x8801)
    time.sleep(0.1)

    # set expected data pattern
    gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)
    time.sleep(0.1)

    # set adc to output sync pattern
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x45, 0x2)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x45, 0x2)

    # start align frame
    gfa.adccontroller.adc_calib_align_frame()

    # check it has finished aligning frame
    for _ in range(10):
        ans = gfa.adccontroller.remote_read_all_regs().answer
        if gfa.adccontroller.status.init_status.frame_aligned:
            break
    else:
        raise Exception('Frame could not be aligned')


    # align data
    gfa.adccontroller.adc_calib_align_data()

    gfa.adccontroller.adc_calib_bitslip()

    # remove pattern
    gfa.adccontroller.spi_write(0x45, 0x0)
    time.sleep(0.1)
    gfa.adccontroller.spi_write(0x45, 0x0)
    time.sleep(0.1)

    gfa.adccontroller.adc_stop_calib()

    ans = gfa.adccontroller.remote_read_all_regs().answer


if __name__ == '__main__':
    from gfaaccesslib.gfa import GFA
    from gfaaccesslib.api_helpers import GFAExposureLock
    import sys
    import os
    import datetime

    IP_DEFAULT = '172.16.17.82'
    PORT = 32000
    APORT = 32001

    FILENAME = datetime.datetime.now(tz=datetime.timezone.utc).strftime('%Y%m%d_%H%M%S_sync_data.csv')

    with open(FILENAME, 'a') as fp:
        fp.write(f"# BT, amp0_errs, amp1_errs, amp2_errs, amp3_errs, total_data\n")

    if len(sys.argv) > 1:
        IP = sys.argv[1]
    else:
        IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
    acq_lock = GFAExposureLock()

    try:
        gfa = GFA(ip=IP, port=PORT, async_port=APORT)
        gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
        for i in range(50):
            for bt in range(3, 21):
                gfa.adccontroller.remote_set_bit_time_value(bt)
                time.sleep(0.2)

                try:
                    sync_adc(gfa)
                    print(f"{i}/50 - Synced gfa with bt={bt}")
                    time.sleep(0.2)
                except Exception as ex:
                    print(f"Error when synchronizing with bt = {bt}")
                    print(ex)
                for _ in range(1):
                    set_gfa_to_output_ramp(gfa)
                    acquire_ramps(gfa=gfa, lock=acq_lock)
                    im = get_last_im(gfa)
                    data = clean_data(im)
                    result = check_data(data)
                    with open(FILENAME, 'a') as fp:
                        fp.write(f"{bt}, {result[0][0]}, {result[1][0]}, {result[2][0]}, {result[3][0]}, {result[0][1]}\n")
                    time.sleep(0.5)
    finally:
        gfa.close()
