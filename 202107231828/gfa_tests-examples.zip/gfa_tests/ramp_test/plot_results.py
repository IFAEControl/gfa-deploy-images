#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '6/21/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

import matplotlib.pyplot as plt
import numpy as np


# men_means = [20, 34, 30, 35, 27]
# labels = ['G1', 'G2', 'G3', 'G4', 'G5']
# women_means = [25, 32, 34, 20, 25]
#
# x = np.arange(len(labels))  # the label locations
# width = 0.35  # the width of the bars
#
# fig, ax = plt.subplots()
# rects1 = ax.bar(x - width/2, men_means, width, label='Men')
# rects2 = ax.bar(x + width/2, women_means, width, label='Women')
#
# # Add some text for labels, title and custom x-axis tick labels, etc.
# ax.set_ylabel('Scores')
# ax.set_title('Scores by group and gender')
# ax.set_xticks(x)
# ax.set_xticklabels(labels)
# ax.legend()
#
# ax.bar_label(rects1, padding=3)
# ax.bar_label(rects2, padding=3)
#
# fig.tight_layout()
#
# plt.show()

def prepare_data(file_path):
    r = []
    with open(file_path) as fp:
        while True:
            line = fp.readline()
            if not line:
                break
            if line.startswith('#'):
                continue
            line.replace('\n', '')
            r.append([int(el) for el in line.split(',')])

    r = np.array(r)
    bit_times = np.unique(r[:, 0])
    print(bit_times)
    print(np.count_nonzero(r[r[:, 0] == [2]][:, 1:-1], axis=0))
    amps = []
    for bt in bit_times:
        amps.append(list(np.count_nonzero(r[r[:, 0] == bt][:, 1:], axis=0)))
    amps = np.array(amps)
    return bit_times, amps


def chart(labels, bad_syncs):
    x = np.arange(2*len(labels), step=2)  # the label locations
    fig, ax = plt.subplots()
    num_of_amps = len(bad_syncs[0])
    width = 1.5  # width of bar group

    bar_labels = ["Ch 0", "Ch 1", "Ch 2", "Ch 3", "Total Syncs"]

    rects = []
    for i in range(num_of_amps):
        amp = bad_syncs[:, i]
        r = ax.bar(x - width/2 + i*(width/num_of_amps), amp, width/num_of_amps, label=bar_labels[i])
        rects.append(r)

    ax.set_ylabel(f'Bad Syncs')
    ax.set_title('Bad syncs by BitTime')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    for r in rects:
        ax.bar_label(r, padding=3)

    fig.tight_layout()
    plt.show()


if __name__ == "__main__":
    labels, data = prepare_data('../20210723_154222_sync_data.csv')
    chart(labels, data)