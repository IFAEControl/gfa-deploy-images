#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
from pprint import pprint
import json
import logging
import sys
import os
import time
import datetime
import pickle

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

IP = '172.16.17.82'
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))


DATA_PATH = "/home/otger/Desktop/desitimes/"
PICKLE_FILE_NAME = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S.timestats.pickle")
CSV_FILE_NAME = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S.csv")

"""

There are 32 TR available.

- The operation of continuous mode is:
    
    - clear and start TR26 (1ms resolution)
    - clear TR0
    - clear TR2
    - clear TR3 (used to stop the loop externally)
    - Load desired expose time at TR 1 (in 10ns units)
    - Dump CCD
    
    - start TR0 (10ns) to control image exposure
    
    - start loop
    - expose for x seconds (wait until TR0 >= TR1)
    - copy TR0 to TR20
    - copy TS to TR14, TR13
    - new_exposure (to take into account dumping of rows into row numbers)
    - start TR2 (10ns)
    - transfer image to storage, dumping storage
    - copy TR2 to TR19 (save time transfer im-> storage)
    - clear TR2
    - clear TR0
    - start TR0 to control image exposure
    - disable vertical clocks from image
    - start TR2 (10ns) - to control readout time
    - read storage section
    - copy TR2 to TR18
    - clear TR2
    - copy TS to TR12, TR11
    - end image command
    - enable vertical clocks from image
    - loop if TR3 = 0, else go out of the loop
    

- What times has to be trackedk
    - TR20: time exposed (10ns units) 
    - TR19: time to transfer image to storage (10ns units)
    - TR18: time spent reading the image section (10ns units)
    - TR17: timestamp (seconds)
    - TR16: timestamp (miliseconds)
    - TR15: full duration of the stack running (1ms)
    - TR14: ts_sec of end_expose
    - TR13: ts_ms of end_expose
    - TR12: ts_sec of end_read
    - TR11: ts_ms of end_read
    - TR3: set to 0, externally set to '1' to stop sequence
    - TR2: helper timer used on transfer time and readout time
    - TR1: desired expose time in 10ns units (can be modified externally)

"""



# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.clockmanager.remote_set_tr_value(value=0, tr_addr=3)
    log.info("Set TR3 to '0'")

    time.sleep(15)

    images = sorted(gfa.raws.list_images())
    print(images)


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    # gfa.clockmanager.remote_join_time_thread()
    gfa.close()
