#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '6/4/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

import gfaaccesslib.gfa

import datetime


def extract_debug_info(gfa: gfaaccesslib.gfa.GFA):
    debug = {
        'scan_time': datetime.datetime.now(tz=datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S"),
        'adc_iface': {
            'regs': gfa.adccontroller.remote_read_all_regs().answer,
            'hw': gfa.adccontroller.hw_if.as_dict()
        }
    }

    return debug


def save_as_yaml(debug_info, path):
    import yaml
    with open(path, 'w') as fp:
        yaml.dump(debug_info, fp)


if __name__ == '__main__':
    from gfaaccesslib.gfa import GFA
    import json

    gfa = GFA(ip='172.16.17.82', port=32000)
    debug_info = extract_debug_info(gfa)
    print(json.dumps(debug_info, indent=2))
    # save_as_yaml(debug_info, './debug_info.yaml')
