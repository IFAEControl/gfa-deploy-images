#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2021"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

import abc
import os

from gfa_tests.adc_sync_debug.adccontrollerregisters import ADCControlRegisters
from gfa_tests.adc_sync_debug.acq import GFAMatrixAnalysis, GFASplitMatrixAnalysis
from gfa_tests.adc_sync_debug.config import SetupConfig
from gfa_tests.adc_sync_debug.acq import SplitMatrixErrors


class CheckData(abc.ABC):
    field_keys = []
    csv_file_name = None
    csv_title = ''

    def __init__(self, td):
        self._error = False
        self.td = td

    @property
    def failed(self):
        return self._error

    @property
    def header_csv(self):
        return ', '.join(sorted(self.field_keys))

    @property
    def as_csv(self):
        return ', '.join([str(getattr(self, k, '')) for k in self.field_keys])

    def save_csv_data(self, check_id):
        with open(os.path.join(self.td.files_path, self.csv_file_name), 'a') as fd:
            if self.td.create_files:
                fd.write(f"# { self.csv_title} \n")
                fd.writelines(self.td.csv_header)
                fd.write(f"# check_id, bit_time, {self.header_csv}\n")
            fd.write(f"{check_id}, {self.td.curr_rundata.conf_bit_time}, {self.as_csv} \n")


class EnvCheck(CheckData):
    field_keys = ['xadc_temp']
    csv_file_name = 'temperatures.csv'
    csv_title = 'Temperatures'

    def __init__(self, xadc_temp, td):
        super(EnvCheck, self).__init__(td=td)
        self.xadc = xadc_temp
        self._error = False

    @property
    def as_csv(self):
        return str(self.xadc)


class TelemetryCheck(CheckData):
    csv_file_name = 'telemetry.csv'
    csv_title = 'Telemetry'

    def __init__(self, voltage_values, td):
        super(TelemetryCheck, self).__init__(td=td)
        self.values = voltage_values
        self.field_keys = voltage_values.csv_fields
        self._csv_string = voltage_values.csv
        self._error = False

    @property
    def header_csv(self):
        return ', '.join(self.field_keys)

    @property
    def as_csv(self):
        return self._csv_string


class PatternCheck(CheckData):
    csv_file_name = 'pattern_check.csv'
    csv_title = 'Pattern Check and ADC interface changes after sync'

    field_keys = sorted(['matching_window', 'changed_bs', 'changed_delays',
                  'pat_err_ch0', 'pat_err_ch1', 'pat_err_ch2', 'pat_err_ch3'])

    def __init__(self, start_ts, end_ts, all_regs, run, td):
        super(PatternCheck, self).__init__(td=td)
        self._start_ts = start_ts
        self._end_ts = end_ts
        self.matching_window = end_ts - start_ts
        self.adc_iface_regs = ADCControlRegisters()
        self.adc_iface_regs.parse_regs(all_regs)
        self.changed_bs = 'NA'
        self.changed_delays = 'NA'
        if run:
            self.changed_bs = run.adc_regs_values.synced_values.bitslips != self.adc_iface_regs.bitslips
            self.changed_delays = run.adc_regs_values.synced_values.delays != self.adc_iface_regs.delays
        self.pat_err_ch0 = self.adc_iface_regs.pattern_errors['ch0']
        self.pat_err_ch1 = self.adc_iface_regs.pattern_errors['ch1']
        self.pat_err_ch2 = self.adc_iface_regs.pattern_errors['ch2']
        self.pat_err_ch3 = self.adc_iface_regs.pattern_errors['ch3']

        if self.pat_err_ch0 or self.pat_err_ch1 or self.pat_err_ch2 or self.pat_err_ch3:
            self._error = True


class MatrixCheck(CheckData):
    csv_file_name = 'matrix_checks.csv'
    csv_title = 'Matrix Image checks'

    def __init__(self, mat_anal: GFAMatrixAnalysis, td):
        super(MatrixCheck, self).__init__(td=td)
        self.field_keys = GFAMatrixAnalysis.keys
        self._as_csv = mat_anal.as_csv
        self._as_dict = mat_anal.as_dict.copy()

        self._error = mat_anal.noisy
        # I do not store mat_anal because it contains all the raw data (large size in memory)

    @property
    def as_csv(self):
        return self._as_csv


class SplitMatrixCheck(CheckData):
    csv_file_name = 'split_matrix_checks.csv'
    csv_title = 'Split Matrix Image checks'

    def __init__(self, splmat_anal: GFASplitMatrixAnalysis, td):
        super(SplitMatrixCheck, self).__init__(td=td)
        self.field_keys = sorted(splmat_anal.split_keys) + sorted(splmat_anal.keys)
        self._as_csv = f"{splmat_anal.split_csv}, {splmat_anal.as_csv}"
        self._as_dict = splmat_anal.as_dict.copy()

        self._error = splmat_anal.noisy
        # I do not store mat_anal because it contains all the raw data (large size in memory)

    @property
    def header_csv(self):
        return ', '.join(self.field_keys)

    @property
    def as_csv(self):
        return self._as_csv


class Errors:
    def __init__(self):
        self.pattern_ch0 = 0
        self.pattern_ch1 = 0
        self.pattern_ch2 = 0
        self.pattern_ch3 = 0
        self.test_ix = 0
        self.pattern_errors = 0
        self.matrix_noise = 0
        self.wave_fft = 0
        self.splmatrix_negs = 0

    def __str__(self):
        tmp = []
        for k, v in self.__dict__.items():
            if not callable(v) and not k.startswith('_'):
                tmp.appen(k, v)
        return ', '.join([f"{k}: {v}" for k, v in tmp])


class ADCRegsValues:
    def __init__(self):
        self.reset_values = ADCControlRegisters()
        self.synced_values = ADCControlRegisters()


class FullTestData:
    def __init__(self, conf: SetupConfig):
        self._errs = {}
        self._runs = []
        self.conf = conf
        self.csv_header = None
        self.files_path = None
        self.create_files = True

    def new_rundata(self, run_id):
        self._runs.append(RunData(run_id, test=self))
        return self.curr_rundata

    @property
    def curr_rundata(self):
        return self._runs[-1]

    def set_csv_header(self, csv_header):
        self.csv_header = csv_header


class RunData:
    # Holds configuration of the whole setup plus info of the results of tests of current test loop

    header_fields = ['run_id', 'ccd_biased', 'conf_bit_time', 'matching_window',
                     'tailored_conf']

    def __init__(self, run_id, test: FullTestData):
        self.run_id = run_id
        self.test = test
        self.conf_bit_time = None

        self.errors = Errors()
        self.adc_regs_values = ADCRegsValues()
        self.res_env = None
        self.res_telemetry = None
        self.res_pattern = None
        self.res_wave = None
        self.res_matrix = None
        self.res_splmatrix = None
        self.splmatrix_errors = None

        self._telem_file = None

    def new_env_results(self, xadc_temp):
        self.res_env = EnvCheck(xadc_temp, td=self.test)
        return self.res_env

    def new_telem_results(self, voltage_values):
        self.res_telemetry = TelemetryCheck(voltage_values, td=self.test)
        return self.res_telemetry

    def new_pattern_results(self, start_ts, end_ts, adc_regs):
        self.res_pattern = PatternCheck(start_ts, end_ts, adc_regs, run=self, td=self.test)
        return self.res_pattern

    def new_matrix_results(self, matrix_analysis: GFAMatrixAnalysis) -> MatrixCheck:
        self.res_matrix = MatrixCheck(mat_anal=matrix_analysis, td=self.test)
        return self.res_matrix

    def new_splmatrix_results(self, splmatrix_analysis: GFASplitMatrixAnalysis) -> SplitMatrixCheck:
        self.res_splmatrix = SplitMatrixCheck(splmat_anal=splmatrix_analysis, td=self.test)
        return self.res_splmatrix

    def update_splmat_errors(self, splmatrix_analysis: GFASplitMatrixAnalysis):
        if self.splmatrix_errors is None:
            self.splmatrix_errors = SplitMatrixErrors(shapes=splmatrix_analysis.raw.shapes)
        self.splmatrix_errors.add(splmatrix_analysis.raw.error_mask)
