#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2021"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

import os
import json
import numpy as np
import zipfile
import pickle
import logging

from gfaaccesslib.api_helpers import GFAExposureLock, GFAAdcAcquisitionMode

from gfa_tests.adc_sync_noise_test.waveform_analysis import WaveForms
from gfaaccesslib.raws.rawdatamanager import toimage
from gfa_tests.adc_sync_debug.plotting import plot_amps_hist


log = logging.getLogger('gfa_acq')
nh = logging.NullHandler()
log.addHandler(nh)

POWERDOWN_TIME_STEP_MS = 250
POWERUP_TIME_STEP_MS = 250


class ImgType:
    waveform = 'Waveform'
    matrix = 'matrix'
    splitmatrix = 'split_matrix'


class GFAWaveAnalysis:
    keys = ["delays.a0_vs_a1", "delays.a0_vs_a2", "delays.a0_vs_a3", "delays.a1_vs_a2", "delays.a1_vs_a3",
            "delays.a2_vs_a3",
            "peaks_sum.a0", "peaks_sum.a1", "peaks_sum.a2", "peaks_sum.a3", "peaks_over_th.a0", "peaks_over_th.a1",
            "peaks_over_th.a2", "peaks_over_th.a3", "imtype"]

    def __init__(self, check_id, data, data_lim=2000):
        self.check_id = check_id
        self.data = data
        self.data_lim = data_lim
        self.wf = WaveForms(image=self.data, data_limit=self.data_lim, last=False, skip_data=10, step=self.check_id)

        self.noisy = False
        self._as_dict = None
        self.imtype = ImgType.waveform

    @property
    def as_dict(self):
        if self._as_dict is None:
            self._as_dict = {
                "delays.a0_vs_a1": self.wf.delays["a0_vs_a1"],
                "delays.a0_vs_a2": self.wf.delays["a0_vs_a2"],
                "delays.a0_vs_a3": self.wf.delays["a0_vs_a3"],
                "delays.a1_vs_a2": self.wf.delays["a1_vs_a2"],
                "delays.a1_vs_a3": self.wf.delays["a1_vs_a3"],
                "delays.a2_vs_a3": self.wf.delays["a2_vs_a3"],
                "peaks_sum.a0": sum(self.wf.fft_peaks[0]),  # sum peaks from all rows
                "peaks_sum.a1": sum(self.wf.fft_peaks[1]),
                "peaks_sum.a2": sum(self.wf.fft_peaks[2]),
                "peaks_sum.a3": sum(self.wf.fft_peaks[3]),
                "peaks_over_th.a0": sum(self.wf.fft_peaks_over_th[0]),
                "peaks_over_th.a1": sum(self.wf.fft_peaks_over_th[1]),
                "peaks_over_th.a2": sum(self.wf.fft_peaks_over_th[2]),
                "peaks_over_th.a3": sum(self.wf.fft_peaks_over_th[3]),
                "imtype": self.imtype
            }
        return self._as_dict

    @property
    def as_csv(self):
        tmp = []
        for x in sorted(self.keys):
            tmp.append(str(self.as_dict[x]))

        return ', '.join(tmp)

    def save_plots(self, out_path, bit_time):
        self.wf.gen_plot(save_path=out_path, show=False)
        self.wf.fft_save_plot(out_path=out_path, bit_time=bit_time)

    def analyze(self, fft_peaks_over_th=15):
        self.wf.process()
        self.wf.get_lags()
        delays = [self.wf.delays[k] for k in sorted(self.wf.delays.keys())]
        if np.max(delays) > 2:
            self.noisy = True
        self.wf.fft_analysis()
        if sum([sum(self.wf.fft_peaks_over_th[x]) for x in self.wf.fft_peaks_over_th.keys()]) > fft_peaks_over_th:
            self.noisy = True

    def save_pickle(self, out_path, zip=True):
        """
        save a pickle of the image data
        :param img: the image to  dump as a pickle
        :param type_im: one of ['waveform', 'image']
        :return:
        """
        pickle_name = '{:04}_{}.pickle'.format(self.check_id, ImgType.waveform)
        if zip:
            zip_name = '{:04}_{}.pickle.zip'.format(self.check_id, ImgType.waveform)
            zf = zipfile.ZipFile(os.path.join(out_path, zip_name), 'w', zipfile.ZIP_DEFLATED)
            zf.writestr(pickle_name, pickle.dumps(self))
            zf.close()
        else:
            with open(os.path.join(out_path, '{:04}_{}.pickle'.format(self.check_id, ImgType.waveform)),
                      'wb') as pickle_file:
                pickle.dump(self, pickle_file)


class GFAMatrixAnalysis:
    keys = [
        'overscan_std.0', 'overscan_std.1', 'overscan_std.2', 'overscan_std.3',
        'overscan_avg.0', 'overscan_avg.1', 'overscan_avg.2', 'overscan_avg.3',
        'prescan_std.0', 'prescan_std.1', 'prescan_std.2', 'prescan_std.3',
        'prescan_avg.0', 'prescan_avg.1', 'prescan_avg.2', 'prescan_avg.3',
        'active_cols_avg.0', 'active_cols_avg.1', 'active_cols_avg.2', 'active_cols_avg.3',
        'active_cols_std.0', 'active_cols_std.1', 'active_cols_std.2', 'active_cols_std.3',
        'active_rows_avg.0', 'active_rows_avg.1', 'active_rows_avg.2', 'active_rows_avg.3',
        'active_rows_std.0', 'active_rows_std.1', 'active_rows_std.2', 'active_rows_std.3',
        'noisy', 'noisy_prescan', 'noisy_overscan', 'noisy_active_cols', 'noisy_active_rows',
        'imtype'
    ]

    def __init__(self, check_id, img, std_th=50, prescan_cols=50, overscan_cols=50):
        self.check_id = check_id
        self.raw = img
        self.th = std_th
        self.meta = {
            'prescan_cols': prescan_cols,
            'overscan_cols': overscan_cols
        }
        self.overscan_std = None
        self.overscan_avg = None
        self.prescan_std = None
        self.prescan_avg = None
        self.active_cols_avg = None
        self.active_cols_std = None
        self.active_rows_avg = None
        self.active_rows_std = None
        self.noisy = False
        self.noisy_prescan = False
        self.noisy_overscan = False
        self.noisy_active_cols = False  # 100 cols x 10 rows (x0,y0) = (200, 200) (x1, y1) = (210, 300)
        self.noisy_active_rows = False  # 10 cols x 100 rows
        self.imtype = ImgType.matrix
        self._as_dict = None
        self._prescan_cols = prescan_cols
        self._overscan_cols = overscan_cols
        self._ampdata = None

    @property
    def as_dict(self):
        if self._as_dict is None:
            self._as_dict = {}
            for i in range(4):
                self._as_dict[f"overscan_std.{i}"] = self.overscan_std[i]
                self._as_dict[f"overscan_avg.{i}"] = self.overscan_avg[i]
                self._as_dict[f"prescan_std.{i}"] = self.prescan_std[i]
                self._as_dict[f"prescan_avg.{i}"] = self.prescan_avg[i]
                self._as_dict[f"active_cols_avg.{i}"] = self.active_cols_avg[i]
                self._as_dict[f"active_cols_std.{i}"] = self.active_cols_std[i]
                self._as_dict[f"active_rows_avg.{i}"] = self.active_rows_avg[i]
                self._as_dict[f"active_rows_std.{i}"] = self.active_rows_std[i]
            self._as_dict['noisy'] = self.noisy
            self._as_dict['noisy_prescan'] = self.noisy_prescan
            self._as_dict['noisy_overscan'] = self.noisy_overscan
            self._as_dict['noisy_active_cols'] = self.noisy_active_cols
            self._as_dict['noisy_active_rows'] = self.noisy_active_rows
            self._as_dict['imtype'] = self.imtype
        return self._as_dict

    @property
    def as_csv(self):
        tmp = []
        for x in sorted(self.keys):
            tmp.append(str(self.as_dict[x]))

        return ', '.join(tmp)

    def get_ampdata(self):
        """
            Returns 4 numpy arrays one per amplifier with 0,0 being pixel closest to the readout amplifier.
        """
        if self._ampdata is None:
            self._ampdata = []
            for amp in self.raw.amplifiers:
                if not amp.rows:
                    continue
                if amp.check_rows_shape() is False:
                    raise Exception("Not all rows have same size")
                data = np.vstack([el.data for el in amp.rows])
                # data = np.array(amp.rows[0].data)
                # for j in range(1, len(amp.rows)):
                #     data = np.vstack((data, amp.rows[j].data))
                self._ampdata.append(data)
        return self._ampdata

    def get_prescan(self, prescan_cols, margin=0):
        if margin:
            return np.array([x[margin:prescan_cols - margin, margin:-margin] for x in self.get_ampdata()])
        return np.array([x[:prescan_cols, :] for x in self.get_ampdata()])

    def get_ampdata_prescan_avg(self, prescan_cols, remove_border=0):
        if remove_border == 0:
            return [np.average(x[:, :prescan_cols]) for x in self.get_ampdata()]
        return [np.average(x[remove_border:-remove_border, remove_border:prescan_cols - remove_border]) for x in
                self.get_ampdata()]

    def get_ampdata_prescan_std(self, prescan_cols, remove_border=0):
        if remove_border == 0:
            return [np.std(x[:, :prescan_cols]) for x in self.get_ampdata()]
        return [np.std(x[remove_border:-remove_border, remove_border:prescan_cols - remove_border]) for x in
                self.get_ampdata()]

    def get_ampdata_overscan_avg(self, overscan_cols, remove_border=0):
        if remove_border == 0:
            return [np.average(x[:, -overscan_cols:]) for x in self.get_ampdata()]
        return [np.average(x[remove_border:-remove_border, remove_border - overscan_cols:-remove_border]) for x in
                self.get_ampdata()]

    def get_ampdata_overscan_std(self, overscan_cols, remove_border=0):
        if remove_border == 0:
            return [np.std(x[:, -overscan_cols:]) for x in self.get_ampdata()]
        return [np.std(x[remove_border:-remove_border, remove_border - overscan_cols:-remove_border]) for x in
                self.get_ampdata()]

    def get_ampdata_avg(self, col_start, col_end, row_start, row_end):
        return [np.average(x[row_start:row_end, col_start:col_end]) for x in self.get_ampdata()]

    def get_ampdata_std(self, col_start, col_end, row_start, row_end):
        return [np.std(x[row_start:row_end, col_start:col_end]) for x in self.get_ampdata()]

    def get_ampdata_shape(self):
        return [x.shape for x in self.get_ampdata()]

    def analyze(self):
        self.overscan_std = self.get_ampdata_overscan_std(self.meta['overscan_cols'], 10)
        self.overscan_avg = self.get_ampdata_overscan_avg(self.meta['overscan_cols'], 10)
        self.prescan_std = self.get_ampdata_prescan_std(self.meta['prescan_cols'], 10)
        self.prescan_avg = self.get_ampdata_prescan_avg(self.meta['prescan_cols'], 10)

        self.active_cols_avg = self.get_ampdata_avg(200, 300, 200, 210)
        self.active_cols_std = self.get_ampdata_std(200, 300, 200, 210)
        self.active_rows_avg = self.get_ampdata_avg(200, 210, 200, 300)
        self.active_rows_std = self.get_ampdata_std(200, 210, 200, 300)

        if max(self.prescan_std) > self.th:
            self.noisy_prescan = True
            self.noisy = True

        if max(self.overscan_std) > self.th:
            self.noisy_overscan = True
            self.noisy = True

        if max(self.active_cols_std) > self.th:
            self.noisy_active_cols = True
            self.noisy = True

        if max(self.active_rows_std) > self.th:
            self.noisy_active_rows = True
            self.noisy = True

    def save_plots(self, out_path, filename=None, amps=None, title=None, color=True):
        if amps is None:
            amps = [np.array(x) for x in self.get_ampdata()]
        if filename is None:
            filename = f"{self.check_id}_{self.imtype}.png"
        if title is None:
            title = f"{self.check_id} {self.imtype} histograms.png"
        plot_amps_hist(amps=amps, save_path=out_path, title=title,
                       filename=filename, color=color)

    def clear(self):
        """
        Remove constructed data that can be autogenerated again. Used on save pickle to reduce size
        """
        self._ampdata = None

    def save_pickle(self, out_path, zip=True):
        """
        save a pickle of the image data
        """
        pickle_name = '{}_{}.pickle'.format(self.check_id, self.imtype)
        self.clear()
        if zip:
            zip_name = f'{pickle_name}.zip'
            zf = zipfile.ZipFile(os.path.join(out_path, zip_name), 'w', zipfile.ZIP_DEFLATED)
            zf.writestr(pickle_name, pickle.dumps(self))
            zf.close()
        else:
            with open(os.path.join(out_path, pickle_name), 'wb') as pickle_file:
                pickle.dump(self, pickle_file)


class SplitMatrixRawDataImage:
    def __init__(self, im):
        self.im = im
        self._signal = []
        self._reference = []
        self._udata = []
        self._data = []
        self._error_mask = []

    @property
    def signal(self):
        if not self._signal:
            for el in self.im.get_ampdata():
                self._signal.append(np.right_shift(el, 16).astype(np.uint16))
        return self._signal

    @property
    def reference(self):
        if not self._reference:
            for el in self.im.get_ampdata():
                self._reference.append(np.array(el).astype(np.uint16))
        return self._reference

    @property
    def udata(self):
        if not self._udata:
            for r, s in zip(self.reference, self.signal):
                self._udata.append(s - r)
        return self._udata

    @property
    def data(self):
        if not self._data:
            for r, s in zip(self.reference, self.signal):
                self._data.append(s.astype(np.int32) - r.astype(np.int32))
        return self._data

    @property
    def error_mask(self):
        if not self._error_mask:
            self._error_mask = [np.greater(x, y) for x, y in zip(self.reference, self.signal)]
        return self._error_mask

    @property
    def shapes(self):
        return [x.shape for x in self.data]


class GFASplitMatrixAnalysis(GFAMatrixAnalysis):
    split_keys = [
        'neg_actarea.0', 'neg_actarea.1', 'neg_actarea.2', 'neg_actarea.3',
        'neg_overscan.0', 'neg_overscan.1', 'neg_overscan.2', 'neg_overscan.3',
        'neg_prescan.0', 'neg_prescan.1', 'neg_prescan.2', 'neg_prescan.3'
    ]

    def __init__(self, check_id, img, std_th=50, prescan_cols=50, overscan_cols=50):
        super().__init__(check_id, img, std_th, prescan_cols, overscan_cols)
        self.raw = SplitMatrixRawDataImage(img)
        self.data = self.raw.data
        self.imtype = ImgType.splitmatrix

        self.neg_overscan = [None, None, None, None]
        self.neg_prescan = [None, None, None, None]
        self.neg_actarea = [None, None, None, None]

    def get_ampdata(self):
        return self.raw.udata

    # Here I have to add extra analysis and keys
    def analyze(self):
        super().analyze()

        self.neg_overscan = [np.count_nonzero(x[:, -self._overscan_cols:]) for x in self.raw.error_mask]
        self.neg_prescan = [np.count_nonzero(x[:, :self._prescan_cols]) for x in self.raw.error_mask]
        self.neg_actarea = [np.count_nonzero(x[:, self._prescan_cols:-self._overscan_cols]) for x in
                            self.raw.error_mask]
        if np.count_nonzero(self.raw.error_mask) > 0:
            self.noisy = True

    @property
    def split_csv(self):
        aa = ', '.join([str(x) for x in self.neg_actarea])
        ovs = ', '.join([str(x) for x in self.neg_overscan])
        ps = ', '.join([str(x) for x in self.neg_prescan])
        csv = f"{aa}, {ovs}, {ps}"
        # log.debug(f"split_csv: {csv}")
        return csv


class SplitMatrixErrors:
    def __init__(self, shapes):
        self.errors = [np.zeros(shape) for shape in shapes]
        self.samples = 0

    def add(self, amps):
        for i, el in enumerate(amps):
            self.errors[i] += amps[i]
        self.samples += 1

    def _compose(self):
        e = np.flipud(self.errors[0])
        f = np.flipud(np.fliplr(self.errors[1]))
        g = np.fliplr(self.errors[2])
        h = self.errors[3]
        log.debug('E,F,G,H shapes: {0}, {1}, {2}, {3}'.format(e.shape, f.shape, g.shape, h.shape))

        if len(f) == 1 and len(g) == 1:
            top = h
            bottom = e
        elif len(h) == 1 and len(e) == 1:
            top = g
            bottom = f
        else:
            top = np.concatenate((h, g), axis=1)
            bottom = np.concatenate((e, f), axis=1)
        return np.concatenate((top, bottom), axis=0)

    def save_im(self, out_path, run_id=None):
        filename = "split_errors_pixels.jpg"
        if run_id is not None:
            filename = f"{run_id}-{filename}"
        comp = self._compose()
        max_pix_value = int(np.max(comp))
        log.info(f"Saving Split pixel errors. Max pix value: {max_pix_value}. Avg: {np.average(comp)}")
        im = toimage(comp, high=max_pix_value)
        im.save(fp=os.path.join(out_path, filename))

    def save_pickle(self, out_path, zip=True, run_id=None):
        """
        save a pickle of the image data
        :param img: the image to  dump as a pickle
        :param type_im: one of ['waveform', 'image']
        :return:
        """
        pickle_name = 'SplitMatrixErrors.pickle'
        if run_id:
            pickle_name = f"{run_id}-{pickle_name}"
        if zip:
            zip_name = f'{pickle_name}.zip'
            zf = zipfile.ZipFile(os.path.join(out_path, zip_name), 'w', zipfile.ZIP_DEFLATED)
            zf.writestr(pickle_name, pickle.dumps(self))
            zf.close()
        else:
            with open(os.path.join(out_path, pickle_name), 'wb') as pickle_file:
                pickle.dump(self, pickle_file)


class GFARawAcq:
    def __init__(self, check_id, raw_data_im, output_path, im_type=ImgType.matrix):
        self.check_id = check_id
        self._raw_data_im = raw_data_im
        self.out_path = output_path
        self.im_type = im_type

    @property
    def raw(self):
        return self._raw_data_im

    def save_pickle(self, compress=True):

        pickle_name = f'{self.check_id}_{self.im_type}.pickle'
        if compress:
            zip_name = f'{pickle_name}.zip'
            zf = zipfile.ZipFile(os.path.join(self.out_path, zip_name), 'w', zipfile.ZIP_DEFLATED)
            zf.writestr(pickle_name, pickle.dumps(self))
            zf.close()
        else:
            with open(os.path.join(self.out_path, pickle_name),
                      'wb') as pickle_file:
                pickle.dump(self, pickle_file)


class GFAAcqHandler:
    def __init__(self, gfa, images_path='./images'):
        self.images_path = images_path
        self.gfa = gfa
        self.acq_lock = GFAExposureLock()

        self.meta = {
            'prescan_cols': 50,
            'overscan_cols': 50,
            'amplifier_active_cols': 1024
        }
        self.last_matrix_imnum = None
        self.last_splmatrix_imnum = None
        self.last_wave_imnum = None

    def subscribe_asyncs(self):
        self.gfa.async_manager.add_end_image_callback(self.acq_lock.async_callback_release)
        self.gfa.async_manager.add_new_image_callback(self.image_start_cb)

    def image_start_cb(self, header, jsondata):
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)

        self.meta['prescan_cols'] = j['prescan_cols']
        self.meta['overscan_cols'] = j['overscan_cols']
        self.meta['amplifier_active_cols'] = j['amplifier_active_cols']
        log.debug(f"Received async img start: {self.meta}")

    def acq_matrix(self, exp_time=0, storage_rows=512, active_rows=544, mode=GFAAdcAcquisitionMode.matrix):
        """
        Sequence to acquire active area and dump storage
        """
        if mode not in [GFAAdcAcquisitionMode.matrix, GFAAdcAcquisitionMode.split_matrix]:
            raise Exception(
                f"To acquire a matrix, mode must be either matrix or split_matrix. Received mode: {mode}")

        self.gfa.adccontroller.spi_write(0xf, 0x0)
        self.gfa.adccontroller.spi_write(0x2a, 0x0)
        self.gfa.adccontroller.adc_start_acq()
        g = self.gfa.clockmanager.stack

        g.clear()
        g.add_new_image_cmd()
        g.add_set_modes_cmd(True, True, True, True)
        # Clear CCD
        g.add_dump_rows_cmd(storage_rows + active_rows)
        g.add_wait_cmd(exp_time)
        # g.add_dump_rows_cmd(storage_rows)
        g.add_read_rows_cmd(storage_rows + active_rows)
        g.add_none_cmd()
        self.gfa.clockmanager.remote_set_stack_contents()
        self.gfa.buffers.remote_set_data_provider(0, mode)

        self.acq_lock.acquire()
        self.gfa.exposecontroller.remote_start_stack_exec()

        self.acq_lock.acquire()
        self.acq_lock.release()

        if mode == GFAAdcAcquisitionMode.matrix:
            self.last_matrix_imnum = sorted(self.gfa.raws.list_images())[-1]
            return self.last_matrix_imnum
        if mode == GFAAdcAcquisitionMode.split_matrix:
            self.last_splmatrix_imnum = sorted(self.gfa.raws.list_images())[-1]
            return self.last_splmatrix_imnum

    def acq_waveform(self, exp_time=0, dump_rows=600, read_rows=10, skip_columns=150, roi_width=20):
        """
        Sequence to acquire active area and dump storage
        """
        self.gfa.adccontroller.spi_write(0xf, 0x0)
        self.gfa.adccontroller.spi_write(0x2a, 0x0)
        self.gfa.adccontroller.adc_start_acq()
        g = self.gfa.clockmanager.stack

        g.clear()
        g.add_new_image_cmd()
        g.add_set_modes_cmd(True, True, True, True)
        # Clear CCD
        g.add_dump_rows_cmd(512+544)
        g.add_wait_cmd(exp_time)
        g.add_dump_rows_cmd(dump_rows)
        if roi_width:
            g.add_set_roi_conf_cmd(skip_columns=skip_columns, roi_width=roi_width)
        # g.add_read_rows_roi_and_overscan_cmd(read_rows)
        # g.add_read_rows_cmd(read_rows)
        g.add_read_rows_roi_cmd(read_rows)

        g.add_none_cmd()
        self.gfa.clockmanager.remote_set_stack_contents()
        self.gfa.buffers.remote_set_data_provider(0, 4)

        self.acq_lock.acquire()
        self.gfa.exposecontroller.remote_start_stack_exec()

        self.acq_lock.acquire()
        self.acq_lock.release()

        self.last_wave_imnum = sorted(self.gfa.raws.list_images())[-1]

        return self.last_wave_imnum

    def acq_and_analyze_matrix(self, check_id, exp_time) -> GFAMatrixAnalysis:
        im_num = self.acq_matrix(exp_time=exp_time)
        img = self.gfa.raws.get_image(im_num)
        mat_anal = GFAMatrixAnalysis(check_id=check_id, img=img)
        return mat_anal

    def acq_and_analyze_split_matrix(self, check_id, exp_time) -> GFASplitMatrixAnalysis:
        im_num = self.acq_matrix(exp_time=exp_time, mode=GFAAdcAcquisitionMode.split_matrix)
        img = self.gfa.raws.get_image(im_num)
        splmat_anal = GFASplitMatrixAnalysis(check_id=check_id, img=img)
        return splmat_anal

    def acq_and_analyze_wave(self, check_id, exp_time) -> GFAWaveAnalysis:
        im_num = self.acq_waveform(exp_time=exp_time)
        img = self.gfa.raws.get_image(im_num)
        wav_anal = GFAWaveAnalysis(check_id=check_id, data=img)
        return wav_anal

    def remove_last_matrix_im(self):
        self.gfa.raws.rem_image(self.last_matrix_imnum)

    def remove_last_splmatrix_im(self):
        self.gfa.raws.rem_image(self.last_splmatrix_imnum)

    def remove_last_wave_im(self):
        self.gfa.raws.rem_image(self.last_wave_imnum)


