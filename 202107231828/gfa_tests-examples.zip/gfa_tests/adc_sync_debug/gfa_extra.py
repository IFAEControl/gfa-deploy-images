
from gfaaccesslib.gfa import GFA
import logging

import time
import datetime


ADC_NO_RESET = (1 << 11)
PATTERN_CLEAR = (1 << 17)
PATTERN_MATCH_ENABLE = (1 << 16)

log = logging.getLogger('gfa_extra')
nh = logging.NullHandler()
log.addHandler(nh)

class ExtraFuncs:
    def __init__(self, gfa, powerup_time_phase=250, powerdown_time_phase=250):
        self.gfa = gfa
        self._powerup_time_phase = powerup_time_phase
        self._powerdown_time_phase = powerdown_time_phase

    def set_tailored_conf(self):
        log.info('Setting tailored configuration to GFA')
        self.gfa.powercontroller.remote_set_dac_conf()

        self.gfa.powercontroller.voltages.set_default_values()

        # values are stored and can be changed at:
        # print(gfa.powercontroller.voltages)15

        # to change a voltage value:
        self.gfa.powercontroller.voltages.DD.volts = 30.8
        self.gfa.powercontroller.voltages.DG_hi.volts = 11.3
        # gfa.powercontroller.voltages.DG_low.volts =
        self.gfa.powercontroller.voltages.I01_IM_hi.volts = 11.35
        # gfa.powercontroller.voltages.I01_IM_low =self.
        self.gfa.powercontroller.voltages.I03_IM_hi.volts = 11.35
        # gfa.powercontroller.voltages.I03_IM_low.volts =
        self.gfa.powercontroller.voltages.I03_ST_hi.volts = 11.35
        # gfa.powercontroller.voltages.I03_ST_low.volts =
        self.gfa.powercontroller.voltages.I04_IM_hi.volts = 11.35
        # gfa.powercontroller.voltages.I04_IM_low.volts =
        self.gfa.powercontroller.voltages.I04_ST_hi.volts = 11.35
        # gfa.powercontroller.voltages.I04_ST_low.volts =
        self.gfa.powercontroller.voltages.OD_EH.volts = 30.7
        self.gfa.powercontroller.voltages.OD_FG.volts = 30.7
        self.gfa.powercontroller.voltages.OG.volts = 3.3
        self.gfa.powercontroller.voltages.R01_hi.volts = 11
        # gfa.powercontroller.voltages.R01_low.volts =
        self.gfa.powercontroller.voltages.R02_hi.volts = 11
        # gfa.powercontroller.voltages.R02_low.volts =
        self.gfa.powercontroller.voltages.R03_hi.volts = 11
        # gfa.powercontroller.voltages.R03_low.volts =
        self.gfa.powercontroller.voltages.RD.volts = 18.5
        self.gfa.powercontroller.voltages.RG_hi.volts = 11.35
        # self.gfa.powercontroller.voltages.RG_low.volts =
        self.gfa.powercontroller.voltages.VSS.volts = 9.4

        # gfa.powercontroller.voltages.powerup_ms =
        # gfa.powercontroller.voltages.powerdown_ms =
        self.gfa.powercontroller.remote_set_voltages()

        # Discharge configuration
        self.gfa.clockmanager.remote_enable_discharge(20, True, True)

        # Offsets configuration
        self.write_dac_offsets(0, 18, True, False)
        self.write_dac_offsets(1, 18, True, False)
        self.write_dac_offsets(2, 18, True, False)
        self.write_dac_offsets(3, 18, True, False)

        # Timings
        # hor
        # acq: 1000
        # del: 750
        # postrg: 60
        # prerg: 60
        # overlap: 60
        # rg: 160

        self.gfa.clockmanager.remote_get_clock_timings()
        self.gfa.clockmanager.time_conf.hor_acq = 1000
        # self.gfa.clockmanager.time_conf.hor_acq_skip =
        # self.gfa.clockmanager.time_conf.hor_acq =
        self.gfa.clockmanager.time_conf.hor_del = 750
        # self.gfa.clockmanager.time_conf.hor_del_skip =
        self.gfa.clockmanager.time_conf.hor_overlap = 60
        # self.gfa.clockmanager.time_conf.hor_overlap_skip =
        self.gfa.clockmanager.time_conf.hor_postrg = 60
        # self.gfa.clockmanager.time_conf.hor_postrg_skip =
        self.gfa.clockmanager.time_conf.hor_prerg = 60
        # self.gfa.clockmanager.time_conf.hor_prerg_skip =
        self.gfa.clockmanager.time_conf.hor_rg = 160
        # self.gfa.clockmanager.time_conf.hor_rg_skip =
        # self.gfa.clockmanager.time_conf.vert_tdgr =
        # self.gfa.clockmanager.time_conf.vert_tdrg =
        # self.gfa.clockmanager.time_conf.vert_tdrt =
        # self.gfa.clockmanager.time_conf.vert_tdtr =
        # self.gfa.clockmanager.time_conf.vert_toi =

        self.gfa.clockmanager.remote_set_clock_timings()
        self.gfa.clockmanager.remote_get_clock_timings()

    def write_dac_offsets(self, address, value, spd, pwr):
        # 2 LSB don't care
        data = 0b0000000000000000
        data |= address << 14
        data |= int(pwr) << 13
        data |= int(spd) << 12
        data |= value << 2
        self.gfa.powercontroller.remote_spi_write(data)

    def configure_default(self):
        self.gfa.clockmanager.remote_set_ccd_geom()
        self.gfa.clockmanager.remote_set_clock_timings()
        self.gfa.powercontroller.remote_set_dac_conf()
        self.gfa.powercontroller.voltages.set_default_values()
        self.gfa.powercontroller.remote_set_voltages()
        self.gfa.powercontroller.powerup_timing_ms = self._powerup_time_phase
        self.gfa.powercontroller.powerdown_timing_ms = self._powerdown_time_phase
        self.gfa.powercontroller.remote_set_phase_timing()
        log.info("Configured default values to gfa")

    def power_up(self):
        log.info("power up gfa")
        self.gfa.exposecontroller.remote_power_up()
        itr = 0
        while self.gfa.exposecontroller.status.ready_state is False:
            if itr > 10:
                self.gfa.powercontroller.remote_get_configured_channels()
                log.info(self.gfa.powercontroller.dac_channels)
                raise Exception("gfa should be in ready state")
            log.info(self.gfa.exposecontroller.status)
            time.sleep(0.4)
            self.gfa.exposecontroller.remote_get_status()
            itr += 1

    def power_down(self):
        log.info("power down gfa")
        self.gfa.powercontroller.powerdown_timing_ms = self._powerdown_time_phase
        self.gfa.powercontroller.remote_set_phase_timing()

        self.gfa.exposecontroller.remote_power_down()
        time.sleep(4 * self._powerdown_time_phase / 1000)

        self.gfa.exposecontroller.remote_get_status()
        log.info(self.gfa.exposecontroller.status)

        self.gfa.powercontroller.remote_get_enables()
        log.info(self.gfa.powercontroller.enables)

    def sync_adc(self):
        self.gfa.adccontroller.set_adc_reset_pin(0)
        self.gfa.adccontroller.set_adc_reset_pin(1)
        self.gfa.adccontroller.set_adc_powerdown_pin(False)

        self.gfa.adccontroller.adc_init_calib()
        self.gfa.adccontroller.remote_get_status()
        if self.gfa.adccontroller.status.init_status.state != 's_init':
            raise Exception('System should be at calibration')

        # reset adc chip by spi
        self.gfa.adccontroller.spi_write(0x0, 0x1)
        time.sleep(0.1)
        self.gfa.adccontroller.spi_write(0x0, 0x0)
        time.sleep(0.1)

        # configure serialization on adc
        self.gfa.adccontroller.spi_write(0x46, 0x8801)

        # set expected data pattern
        self.gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)

        # set adc to output sync pattern
        time.sleep(0.1)
        self.gfa.adccontroller.spi_write(0x45, 0x2)

        # start align frame
        self.gfa.adccontroller.adc_calib_align_frame()

        # check it has finished aligning frame
        for i in range(10):
            self.gfa.adccontroller.remote_get_status()
            if self.gfa.adccontroller.status.init_status.frame_aligned:
                break
        else:
            raise Exception('Frame could not be aligned')

        # align data
        self.gfa.adccontroller.adc_calib_align_data()

        self.gfa.adccontroller.adc_calib_bitslip()

        self.gfa.adccontroller.remote_get_status()
        self.gfa.adccontroller.remote_get_init_rx_expected_pattern()
        self.gfa.adccontroller.remote_get_init_rx_data()
        # print(self.gfa.adccontroller.status)

        # remove pattern
        self.gfa.adccontroller.spi_write(0x45, 0x0)

        self.gfa.adccontroller.adc_stop_calib()

    def pattern_test(self, pattern_match_time):
        # Configure ADC to put deskew pattern:
        # All channels output a repeating pattern of 1010101010101010 instead of ADC data
        self.gfa.adccontroller.spi_write(0x45, 0x1)
        # Set expected pattern
        self.gfa.adccontroller.remote_set_init_rx_expected_pattern(0x5555)
        # clear pattern matching counters
        # ADC_RESET must be kept at 1 to operate the ADC
        self.gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | PATTERN_CLEAR)
        start_ts = datetime.datetime.utcnow().timestamp()
        self.gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | PATTERN_MATCH_ENABLE)

        time.sleep(pattern_match_time)

        self.gfa.adccontroller.remote_write_register(1, ADC_NO_RESET)

        end_ts = datetime.datetime.utcnow().timestamp()
        all_regs = self.gfa.adccontroller.remote_read_all_regs().answer

        # remove pattern
        self.gfa.adccontroller.spi_write(0x45, 0x0)

        return start_ts, end_ts, all_regs


class GFAExtra(GFA):
    def __init__(self, ip, port=3000, async_port=None, ccd="e2v-ccd230-42", auto_connect_async=True, auto_update=True,
                 powerup_time_phase=250, powerdown_time_phase=250):
        super(GFAExtra, self).__init__(ip, port=port, async_port=async_port, ccd=ccd,
                                       auto_connect_async=auto_connect_async, auto_update=auto_update)

        self.extra = ExtraFuncs(gfa=self, powerup_time_phase=powerup_time_phase,
                                powerdown_time_phase=powerdown_time_phase)

