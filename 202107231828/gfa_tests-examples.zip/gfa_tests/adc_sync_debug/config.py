import yaml


class SetupConfig:
    def __init__(self, gfa_ip):
        self.biased = True
        self.tailored_gfa_conf = True

        self.get_telem = False

        self.pattern_test = True
        self.pattern_match_time = 10

        self.acq_wave = True
        self.acq_wave_exptime = 0
        self.save_wave_pickle = False
        self.save_wave_png = True

        self.acq_matrix = True
        self.acq_matrix_exptime = 0
        self.save_matrix_hist = True
        self.save_matrix_pickle = False
        # Save up to 2 pickles when there is an error If you want to save all set
        # save_matrix_pickle or set an absurdly large number
        self.save_matrix_err_pickle = 2

        self.acq_split = True
        self.acq_split_exptime = 0
        self.save_split_hist = True
        self.save_split_pickle = False
        # Save up to 2 pickles when there is an error If you want to save all set
        # save_matrix_pickle or set an absurdly large number
        self.save_split_err_pickle = 2

        self.files_path = 'default'
        self.bit_times = [9, 17]
        # run is each adc sync
        # tests in run is how many acquisitions or pattern tests are done for each sync
        self.checkloops_in_run = 1
        self.runs = 0  # 0 means do not stop until killed
        self.gfa_ip = gfa_ip

    def save_as_yaml(self, file_path):
        tmp = {}
        for k, v in self.__dict__.items():
            if not callable(v) and not k.startswith('_'):
                tmp[k] = v
        with open(file_path, 'a') as fd:
            yaml.dump(tmp, fd)

