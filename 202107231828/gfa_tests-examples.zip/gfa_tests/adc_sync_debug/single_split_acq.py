from gfa_tests.adc_sync_debug.acq import GFAAcqHandler
from gfa_tests.adc_sync_debug.gfa_extra import GFAExtra
import os
import datetime
import logging

log = logging.getLogger('single_split_acq')
log.addHandler(logging.StreamHandler())
log.setLevel(logging.DEBUG)

IP_DEFAULT = '172.16.17.82'
PORT = 32000
APORT = 32001
EXPTIME_MS = 10000
SAVE_PICKLE = False

if __name__ == "__main__":
    now = datetime.datetime.utcnow()
    images_path = now.strftime('/home/otger/development/desi/analysis/single_tests/%Y%D%m')

    os.makedirs(images_path, exist_ok=True)
    checks_id = now.strftime("%Y%m%d%H%M%S_split")
    gfa = GFAExtra(IP_DEFAULT, PORT, APORT)
    try:
        gfa_acq = GFAAcqHandler(gfa=gfa, images_path=images_path)
        gfa_acq.subscribe_asyncs()
        log.info('Acquiring')
        splmat = gfa_acq.acq_and_analyze_split_matrix(check_id=checks_id,
                                                      exp_time=EXPTIME_MS)
        log.info('Analyzing')
        splmat.analyze()
        log.info('Saving plots')
        splmat.save_plots(images_path)
        splmat.save_plots(out_path=images_path,
                          filename=f"{splmat.check_id}_{splmat.imtype}_reference.png",
                          amps=splmat.raw.reference,
                          color=False)
        splmat.save_plots(out_path=images_path,
                          filename=f"{splmat.check_id}_{splmat.imtype}_light.png",
                          amps=splmat.raw.signal,
                          color=False)
        splmat.save_plots(out_path=images_path,
                          filename=f"{splmat.check_id}_{splmat.imtype}_signed.png",
                          amps=splmat.raw.data,
                          color=False)
        if SAVE_PICKLE:
            log.info('Saving pickle')
            splmat.save_pickle(images_path)



    except:
        log.exception('Fuck it')
    finally:
        gfa.disconnect()