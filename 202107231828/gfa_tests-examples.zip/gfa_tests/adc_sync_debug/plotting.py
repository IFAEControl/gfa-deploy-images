import matplotlib.pyplot as plt
from matplotlib import colors
import numpy as np
import os

import logging
log = logging.getLogger('plotting')
nh = logging.NullHandler()
log.addHandler(nh)


def colorFader(c1, c2, mix=0):  # fade (linear interpolate) from color c1 (at mix=0) to c2 (mix=1)
    c1 = np.array(colors.to_rgb(c1))
    c2 = np.array(colors.to_rgb(c2))
    return colors.to_hex((1 - mix) * c1 + mix * c2)


def paint_hist(axis, data, bins=100, x_range=None, color_threshold=20000):
    d = data.flatten()
    if d.max() - d.min() < 100:
        bins = int(d.max() - d.min())
    if bins < 1:
        log.error(f"Number of bins error: data.max: {d.max()} - data.min: {d.min()}")
        return
    n, bins, patches = axis.hist(d, bins=bins,
                                 # edgecolor='#e0e0e0', linewidth=0.2, alpha=0.7)
                                 )
    bins = bins.astype('int')  # it MUST be integer
    # Good old loop. Choose colormap of your taste
    for ix2, p in enumerate(patches):
        # p.set_facecolor(colorFader(u'#2b2c2e', u'#cc2900', bins[ix2] / 65536))
        if bins[ix2] < color_threshold:
            p.set_facecolor(colorFader(u'#32673f', u'#023800', bins[ix2] / color_threshold))
            # p.set_facecolor(u'#086b04')
        else:
            p.set_facecolor(colorFader(u'#380200', u'#cc2900', (bins[ix2] - color_threshold) / (65536 - color_threshold)))

    if isinstance(x_range, tuple):
        axis.set_xlim(x_range)


def plot_amps_hist(amps, save_path, title='Histogram', filename='hist.png', show=False, color=True):
    fig = plt.figure(figsize=(20, 14))
    axs = fig.subplots(4, 4)
    x_lims = (np.array(amps).min(), np.array(amps).max())
    if color is False:
        color_threshold = 1E9
    else:
        color_threshold = 20000
    for ix, amp in enumerate(amps):
        paint_hist(axs[ix, 0], amps[ix], x_range=x_lims, color_threshold=color_threshold)
        axs[ix, 0].set_title(f'hist full amp {ix}')
        axs[ix, 0].set_yscale('log')

        paint_hist(axs[ix, 1], amps[ix][:, :50], x_range=x_lims, color_threshold=color_threshold)
        axs[ix, 1].set_title(f'hist prescan amp {ix}')
        axs[ix, 1].set_yscale('log')

        paint_hist(axs[ix, 2], amps[ix][:, -50:], x_range=x_lims, color_threshold=color_threshold)
        axs[ix, 2].set_title(f'hist overscan amp {ix}')
        axs[ix, 2].set_yscale('log')

        paint_hist(axs[ix, 3], amps[ix][:, 50:-50], x_range=x_lims, color_threshold=color_threshold)
        axs[ix, 3].set_title(f'hist active area amp {ix}')
        axs[ix, 3].set_yscale('log')

    if save_path:
        fig.suptitle(title, fontsize=14)
        fig.savefig(os.path.join(save_path, filename),
                    bbox_inches='tight')
    if show:
        fig.show()
    plt.close(fig)
