#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2021"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"


class ADCControlRegisters:

    def __init__(self):
        self._header_fields = []
        self.bit_time = None
        self.sync_status = {
            'done': None,
            'ready': None,
            'bs_finished_frame': None,
            'i_init_busy': None,
            'i_init_done': None,
            'align_frame': None,
            'set_init': None,
            'flag1': None,
            'flag2': None,
            'frame_aligned': None,
            'good_pattern': None,
            'good_pattern_full': None,
            'bs_finished_data_full': None
        }
        self.bitslips = {
            'frame': None,
            'd1': None,
            'd2': None,
            'd3': None,
            'd4': None,
            'd5': None,
            'd6': None,
            'd7': None,
            'd8': None
        }
        self.delays = {
            'frame': None,
            'd1m': None,
            'd1s': None,
            'd2m': None,
            'd2s': None,
            'd3m': None,
            'd3s': None,
            'd4m': None,
            'd4s': None,
            'd5m': None,
            'd5s': None,
            'd6m': None,
            'd6s': None,
            'd7m': None,
            'd7s': None,
            'd8m': None,
            'd8s': None
        }
        self.pattern_errors = {
            'ch0': None,
            'ch1': None,
            'ch2': None,
            'ch3': None,
            'samples': None
        }
        self.expected_pattern = None
        self.acq_data = {
            'ch0': None,
            'ch1': None,
            'ch2': None,
            'ch3': None,
        }

    def parse_regs(self, all_regs):
        MASK5BIT = 0b11111
        self.sync_status.update({
            'done': all_regs['reg_3'] & 0x1,
            'ready': (all_regs['reg_3'] & (0x1 << 1) >> 1),
            'bs_finished_frame': (all_regs['reg_3'] & (0x1 << 2) >> 2),
            'i_init_busy': (all_regs['reg_3'] & (0x1 << 3) >> 3),
            'i_init_done': (all_regs['reg_3'] & (0x1 << 4) >> 4),
            'align_frame': (all_regs['reg_3'] & (0x1 << 5) >> 5),
            'set_init': (all_regs['reg_3'] & (0x1 << 6) >> 6),
            'flag1': (all_regs['reg_3'] & (0x1 << 7) >> 7),
            'flag2': (all_regs['reg_3'] & (0x1 << 8) >> 8),
            'frame_aligned': (all_regs['reg_3'] & (0x1 << 9) >> 9),
            'good_pattern': (all_regs['reg_3'] & (0x1 << 10) >> 10),
            'good_pattern_full': (all_regs['reg_3'] & (0xff << 11) >> 11),
            'bs_finished_data_full': (all_regs['reg_3'] & (0xff << 18) >> 18)
        })
        self.acq_data.update({
            'ch0': all_regs['reg_4'] & 0xffff,
            'ch1': all_regs['reg_5'] & 0xffff,
            'ch2': all_regs['reg_6'] & 0xffff,
            'ch3': all_regs['reg_7'] & 0xffff,
        })
        self.expected_pattern = all_regs['reg_8'] & 0xffff
        self.bit_time = all_regs['reg_9'] & MASK5BIT
        self.bitslips.update({
            'frame': all_regs['reg_10'] & 0xff,
            'd1': (all_regs['reg_10'] & (0xff << 8)) >> 8,
            'd2': (all_regs['reg_10'] & (0xff << 16)) >> 16,
            'd3': (all_regs['reg_10'] & (0xff << 24)) >> 24,
            'd4': all_regs['reg_11'] & 0xff,
            'd5': (all_regs['reg_11'] & (0xff << 8)) >> 8,
            'd6': (all_regs['reg_11'] & (0xff << 16)) >> 16,
            'd7': (all_regs['reg_11'] & (0xff << 24)) >> 24,
            'd8': all_regs['reg_12'] & 0xff,
        })
        self.delays.update({
            'frame': all_regs['reg_13'] & MASK5BIT,
            'd1m': (all_regs['reg_13'] & (MASK5BIT << 5)) >> 5,
            'd1s': (all_regs['reg_13'] & (MASK5BIT << 10)) >> 10,
            'd2m': (all_regs['reg_13'] & (MASK5BIT << 15)) >> 15,
            'd2s': (all_regs['reg_13'] & (MASK5BIT << 20)) >> 20,
            'd3m': (all_regs['reg_13'] & (MASK5BIT << 25)) >> 25,
            'd3s': all_regs['reg_14'] & MASK5BIT,
            'd4m': (all_regs['reg_14'] & (MASK5BIT << 5)) >> 5,
            'd4s': (all_regs['reg_14'] & (MASK5BIT << 10)) >> 10,
            'd5m': (all_regs['reg_14'] & (MASK5BIT << 15)) >> 15,
            'd5s': (all_regs['reg_14'] & (MASK5BIT << 20)) >> 20,
            'd6m': (all_regs['reg_14'] & (MASK5BIT << 25)) >> 25,
            'd6s': all_regs['reg_15'] & MASK5BIT,
            'd7m': (all_regs['reg_15'] & (MASK5BIT << 5)) >> 5,
            'd7s': (all_regs['reg_15'] & (MASK5BIT << 10)) >> 10,
            'd8m': (all_regs['reg_15'] & (MASK5BIT << 15)) >> 15,
            'd8s': (all_regs['reg_15'] & (MASK5BIT << 20)) >> 20,
        })
        self.pattern_errors.update({
            'ch0': all_regs['reg_16'],
            'ch1': all_regs['reg_17'],
            'ch2': all_regs['reg_18'],
            'ch3': all_regs['reg_19'],
            'samples': all_regs['reg_20']
        })

    def get_header_fields(self):
        if not self._header_fields:
            fields = []
            for k in sorted(self.__dict__.keys()):
                if k.startswith('_'):
                    continue
                item = getattr(self, k)
                if callable(item):
                    # Should not happen because __dict__ only has attributes, not methods
                    continue
                if isinstance(item, dict):
                    for k2 in sorted(item.keys()):
                        fields.append(f'{k}.{k2}')
                else:
                    fields.append(k)
            self._header_fields = sorted(fields)
        return self._header_fields

    def as_csv(self):
        values = []
        for k in self.get_header_fields():
            if k.count('.'):
                k1, k2 = k.split('.')
                values.append(getattr(self, k1)[k2])
            else:
                values.append(getattr(self, k))
        return ', '.join([str(x) for x in values])

