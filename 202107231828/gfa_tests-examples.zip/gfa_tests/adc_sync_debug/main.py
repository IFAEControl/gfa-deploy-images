#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfa_tests.adc_sync_debug.acq import log as acq_log
from gfa_tests.adc_sync_debug.gfa_extra import log as extra_log
from gfa_tests.adc_sync_debug.plotting import log as plot_log

from gfaaccesslib.logger import log as gfaliblog
from gfa_tests.adc_sync_debug.gfa_extra import GFAExtra
from gfa_tests.adc_sync_debug.acq import GFAAcqHandler
from gfa_tests.adc_sync_debug.config import SetupConfig
from gfa_tests.adc_sync_debug.results import RunData, FullTestData

import sys
import os
import time
import datetime

import logging
import logging.handlers

log = logging.getLogger('adc_sync_debug')
log.setLevel(logging.DEBUG)
nh = logging.NullHandler()
log.addHandler(nh)
acq_log.setLevel(logging.DEBUG)
extra_log.setLevel(logging.DEBUG)
plot_log.setLevel(logging.DEBUG)

IP_DEFAULT = '172.16.17.82'
PORT = 32000
APORT = 32001

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

POWERDOWN_TIME_STEP_MS = 250
POWERUP_TIME_STEP_MS = 250


class AdcSyncDebug(object):
    def __init__(self, conf=SetupConfig(gfa_ip=IP)):
        self.errors = {}
        self.conf = conf
        self.testdata = FullTestData(conf=conf)

        if self.conf.files_path == 'default':
            now = datetime.datetime.utcnow()
            self.files_path = './{}'.format(now.strftime("%Y%m%d%H%M%S"))
        else:
            self.files_path = self.conf.files_path

        self.images_path = os.path.join(self.files_path, 'images')
        self.pickles_path = os.path.join(self.files_path, 'pickles')

        self.splerrors = None

        log.info('Connecting to {}:{}'.format(self.conf.gfa_ip, PORT, APORT))
        self.gfa = GFAExtra(self.conf.gfa_ip, PORT, APORT)
        self.gfa_acq = GFAAcqHandler(gfa=self.gfa, images_path=self.images_path)
        self.gfa_acq.subscribe_asyncs()

    def log_add_file_handler(self, log_pointer, file_name=None, level=logging.DEBUG):
        file_path = os.path.join(self.files_path, file_name)
        fh = logging.FileHandler(filename=file_path)
        fh.setLevel(level=level)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        log_pointer.addHandler(fh)

    def create_logs(self):
        # There are 2 logs, the one of the script and the one of the library
        # library
        self.log_add_file_handler(gfaliblog, 'gfaaccesslib.log')
        # script
        self.log_add_file_handler(log, 'adc_sync_noise_test.log')
        self.log_add_file_handler(acq_log, 'adc_sync_noise_test.log')
        self.log_add_file_handler(extra_log, 'adc_sync_noise_test.log')
        self.log_add_file_handler(plot_log, 'adc_sync_noise_test.log')

    def _get_csv_header(self):
        now = datetime.datetime.utcnow()
        versions = {'api': 'NA',
                    'fw_version': 'NA',
                    'gfa_mac': 'NA'}
        if self.gfa:
            versions['api'] = self.gfa.sys.remote_api().answer
            versions['fw_version'] = self.gfa.sys.remote_version().answer
            versions['gfa_mac'] = self.gfa.sys.remote_mac().answer

        return [
            "## ADC Synchronize Pattern Matching Test\n",
            "## Started on: {}\n".format(now.strftime("%d/%m/%Y %H:%M:%S")),
            '## GFA API: {}\n'.format(versions['api']),
            '## GFA FW versions: {}\n'.format(versions['fw_version']),
            '## GFA MAC address: {}\n'.format(versions['gfa_mac'])
        ]

    def make_paths(self):
        os.makedirs(self.files_path, exist_ok=True)
        os.makedirs(self.images_path, exist_ok=True)
        os.makedirs(self.pickles_path, exist_ok=True)
        log.info("Created paths: {}, {}".format(self.files_path, self.images_path))

    def run_step(self, rundata: RunData):

        # synchronize
        log.info(f"{rundata.run_id} - Syncing adc with bit_time {rundata.conf_bit_time}")
        self.gfa.adccontroller.reset_adc_controller()
        rundata.adc_regs_values.reset_values.parse_regs(self.gfa.adccontroller.remote_read_all_regs().answer)
        self.gfa.adccontroller.remote_set_bit_time_value(rundata.conf_bit_time)

        self.gfa.extra.sync_adc()
        time.sleep(0.5)
        rundata.adc_regs_values.synced_values.parse_regs(self.gfa.adccontroller.remote_read_all_regs().answer)

        saved_pickle_splmat = 0
        saved_pickle_matrix = 0
        saved_pickle_wave = 0

        for test_ix in range(self.conf.checkloops_in_run):
            checks_id = f"{rundata.run_id}.{test_ix:04}"

            # temperature
            sensors = self.gfa.telemetry.remote_get_sensor_values().answer
            temp_res = rundata.new_env_results(sensors['xadc_temp'])
            temp_res.save_csv_data(check_id=checks_id)
            log.debug(f"xadc_temp: {rundata.res_env.xadc}")

            # capture telem
            if self.conf.biased and self.conf.get_telem:
                try:
                    log.debug(f"{rundata.run_id} - Capturing telemetry")
                    self.gfa.exposecontroller.remote_get_telemetry()
                    time.sleep(2.0)
                    self.gfa.telemetry.remote_get_voltage_values()
                    self.gfa.telemetry.remote_get_status()
                    telem_res = rundata.new_telem_results(self.gfa.telemetry.ccd_voltages)
                    telem_res.save_csv_data(checks_id)
                except:
                    log.exception('Failed to execute telemetry check')

            if self.conf.pattern_test:
                try:
                    log.info(f'{rundata.run_id} - Running pattern test')
                    start, end, regs = self.gfa.extra.pattern_test(self.conf.pattern_match_time)
                    pat_res = rundata.new_pattern_results(start, end, regs)
                    if pat_res.failed:
                        rundata.errors.pattern_errors += 1
                    pat_res.save_csv_data(checks_id)
                except:
                    log.exception('Failed to execute pattern check')

            # Acquire and analyze matrix
            if self.conf.biased and self.conf.acq_matrix:
                try:
                    log.info(f'{checks_id} - Acquiring Matrix Image')
                    mat = self.gfa_acq.acq_and_analyze_matrix(check_id=checks_id,
                                                              exp_time=self.conf.acq_matrix_exptime)
                    mat.analyze()
                    mat_res = rundata.new_matrix_results(mat)
                    if self.conf.save_matrix_hist:
                        mat.save_plots(self.images_path)
                    if mat.noisy:
                        rundata.errors.matrix_noise += 1
                        if saved_pickle_matrix < self.conf.save_matrix_err_pickle:
                            mat.save_pickle(self.pickles_path)
                            saved_pickle_matrix += 1

                    mat_res.save_csv_data(checks_id)
                except:
                    log.exception('Failed to execute matrix image check')

            # Acquire and analyze split matrix
            if self.conf.biased and self.conf.acq_split:
                try:
                    log.info(f'{checks_id} - Acquiring Split Matrix Image')
                    splmat = self.gfa_acq.acq_and_analyze_split_matrix(check_id=checks_id,
                                                                       exp_time=self.conf.acq_split_exptime)
                    splmat.analyze()
                    splmat_res = rundata.new_splmatrix_results(splmat)
                    if self.conf.save_split_hist:
                        splmat.save_plots(self.images_path)
                        splmat.save_plots(out_path=self.images_path,
                                          filename=f"{splmat.check_id}_{splmat.imtype}_reference.png",
                                          amps=splmat.raw.reference,
                                          color=False)
                        splmat.save_plots(out_path=self.images_path,
                                          filename=f"{splmat.check_id}_{splmat.imtype}_light.png",
                                          amps=splmat.raw.signal,
                                          color=False)
                        splmat.save_plots(out_path=self.images_path,
                                          filename=f"{splmat.check_id}_{splmat.imtype}_signed.png",
                                          amps=splmat.raw.data,
                                          color=False)
                    if splmat.noisy:
                        rundata.errors.splmatrix_negs += 1
                    splmat_res.save_csv_data(checks_id)
                    rundata.update_splmat_errors(splmat)
                    rundata.splmatrix_errors.save_im(self.files_path, run_id=rundata.run_id)
                    # It overwrittes it at each check but creates a new one for each run
                    rundata.splmatrix_errors.save_pickle(out_path=self.files_path,
                                                         run_id=rundata.run_id)
                    if saved_pickle_splmat < self.conf.save_split_err_pickle:
                        splmat.save_pickle(self.pickles_path)
                        saved_pickle_splmat += 1
                except:
                    log.exception('Failed to execute split matrix check')

                self.gfa_acq.remove_last_matrix_im()
                self.gfa_acq.remove_last_splmatrix_im()

            self.testdata.create_files = False

    def loop(self):
        self.make_paths()
        self.create_logs()
        self.conf.save_as_yaml(os.path.join(self.files_path, 'test_conf.yaml'))

        self.testdata.set_csv_header(self._get_csv_header())
        self.testdata.files_path = self.files_path

        self.gfa.extra.configure_default()
        if self.conf.tailored_gfa_conf:
            self.gfa.extra.set_tailored_conf()

        if self.conf.biased:
            self.gfa.extra.power_up()
        else:
            # make sure ccd is not biased
            self.gfa.extra.power_down()

        run_num = 0
        keep_running = self.conf.runs == 0
        while keep_running or run_num < self.conf.runs * len(self.conf.bit_times):
            for bt in self.conf.bit_times:
                try:
                    run_id = f"{run_num:04}.{bt}"
                    rundata = self.testdata.new_rundata(run_id=run_id)
                    rundata.conf_bit_time = bt
                    # The step is the adc sync + one or more checks
                    self.run_step(rundata=rundata)
                except Exception as ex:
                    log.exception("Error while looping")
            run_num += 1
        if self.conf.biased:
            self.gfa.extra.power_down()
        self.gfa.close()


if __name__ == "__main__":
    from gfaaccesslib.logger import formatter
    import pprint

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    log.addHandler(ch)
    acq_log.addHandler(ch)
    extra_log.addHandler(ch)
    plot_log.addHandler(ch)

    c = SetupConfig(gfa_ip=IP)
    c.bit_times = [9, 17]
    c.checkloops_in_run = 40
    c.runs = 0
    c.pattern_test = True
    c.save_matrix_err_pickle = 2
    c.save_split_err_pickle = 2

    asn = AdcSyncDebug(conf=c)
    asn.loop()
    pprint.pprint(asn.errors)
