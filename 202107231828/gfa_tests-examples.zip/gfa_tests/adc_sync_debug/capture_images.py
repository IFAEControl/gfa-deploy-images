from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
import json
import pickle
import time


"""
This script captures images launched from another program or script and saves the images as a pickle
"""

IP = '172.16.17.82'
PORT = 32000
APORT = 32001

gfa = GFA(IP, PORT, APORT)

acq_lock = GFAExposureLock()


def image_start_cb(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)


gfa.async_manager.add_new_image_callback(image_start_cb)
gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)

try:
    for i in range(4):
        acq_lock.acquire()
        acq_lock.acquire()
        acq_lock.release()
        im_num = sorted(gfa.raws.list_images())[-1]
        img = gfa.raws.get_image(im_num)
        with open(f'img_{i}.pickle', 'wb') as fd:
            pickle.dump(img, fd)
finally:
    gfa.close()