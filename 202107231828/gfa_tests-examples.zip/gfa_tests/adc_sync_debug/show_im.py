import pickle
import zipfile
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
from gfafunctionality.raws import RawRepresentation

zip_pickle_path = '/home/otger/development/desi/analysis/20210315215029/pickles/0000.9.0002_split_matrix.pickle.zip'
pickle_name = '0000.9.0002_split_matrix.pickle'

with open(zip_pickle_path, 'r') as f:
    zf = zipfile.ZipFile(zip_pickle_path)
    f = zf.read(pickle_name)
a = pickle.loads(f)

rra = RawRepresentation(a.raw.im)
guiqwt = GUIQWTPlotter(image=a, e2v_ccd230_42_im=rra)
guiqwt.show_image()
