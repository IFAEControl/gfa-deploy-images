1#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

import sys
print(sys.path)

from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
import pickle


path = sys.argv[1]

with open(path, 'rb') as im_file:
    a = pickle.load(im_file)

print(a.image_id)

g = GUIQWTPlotter(image=a)
g.show_as_waveform(max_lines=1)