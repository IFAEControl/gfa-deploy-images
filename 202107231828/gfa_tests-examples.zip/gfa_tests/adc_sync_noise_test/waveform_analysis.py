#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import signal

colors = [u'#1f77b4', u'#ff7f0e', u'#2ca02c', u'#d62728', u'#9467bd', u'#8c564b', u'#e377c2', u'#7f7f7f', u'#bcbd22', u'#17becf']


class WaveForms(object):
    delay_keys = {
        "a0_vs_a1": ["a_1_y", "a_0_y"],
        "a0_vs_a2": ["a_2_y", "a_0_y"],
        "a0_vs_a3": ["a_3_y", "a_0_y"],
        "a1_vs_a2": ["a_2_y", "a_1_y"],
        "a1_vs_a3": ["a_3_y", "a_1_y"],
        "a2_vs_a3": ["a_3_y", "a_2_y"],
    }

    def __init__(self, image, data_limit=1000, data_points_offset=1000, last=True, row_selected=0, skip_data=0, step=0):
        self.im = image
        self._row = row_selected
        self._limit = data_limit
        self._last = last
        self._offset = data_points_offset
        self._skip_values = skip_data
        self.df = pd.DataFrame()
        self.delays = {}
        self.step = step
        self.fft_peaks = {}
        self.fft_peaks_num = {}
        self.fft_peaks_over_th = {}
        self.fft_plot_data = None

    def process(self):
        for ix, amp in enumerate(self.im.amplifiers):
            row = self.im.amplifiers[ix].rows[self._row]
            if self._limit and self._last:
                amprow = np.array([[ix, el & 0xffff, ((el & 0x10000) >> 16), ((el & 0x20000) >> 17),
                                ((el & 0x40000) >> 18)] for ix, el in enumerate(row.data[-self._limit:])], dtype='int64')
            elif self._limit:
                amprow = np.array([[ix, el & 0xffff, ((el & 0x10000) >> 16), ((el & 0x20000) >> 17),
                                    ((el & 0x40000) >> 18)] for ix, el in enumerate(row.data[self._skip_values:self._limit + self._skip_values])], dtype='int64')
            else:
                amprow = np.array([[ix, el & 0xffff, ((el & 0x10000) >> 16), ((el & 0x20000) >> 17),
                                    ((el & 0x40000) >> 18)] for ix, el in enumerate(row.data[self._skip_values:])], dtype='int64')
            self.df[f'a_{ix}_x'] = amprow[:, 0]
            self.df[f'a_{ix}_y'] = amprow[:, 1]
            self.df[f'a_{ix}_flag_ref'] = amprow[:, 2]
            self.df[f'a_{ix}_flag_sig'] = amprow[:, 3]
            self.df[f'a_{ix}_flag_debug'] = amprow[:, 4]

    def gen_plot(self, save_path=None, show=False):
        axs = plt.figure(dpi=200, figsize=(30, 15)).subplots(5, 1, sharex=True)
        axs[0].plot('a_0_x', 'a_0_y', data=self.df, color=colors[0])
        axs[0].plot('a_1_x', 'a_1_y', data=self.df, color=colors[1])
        axs[0].plot('a_2_x', 'a_2_y', data=self.df, color=colors[2])
        axs[0].plot('a_3_x', 'a_3_y', data=self.df, color=colors[3])
        axs[0].legend(loc="upper right")
        axs[0].set_title(f'All amplifiers - {self._row}')

        axs[1].plot('a_0_x', 'a_0_y', data=self.df, color=colors[0], label='Amplifier 0')
        sig_max = self.df['a_0_y'].max()
        sig_min = self.df['a_0_y'].min()
        flag_ref = sig_max * self.df['a_0_flag_ref']
        flag_sig = sig_max * self.df['a_0_flag_sig']
        flag_debug = sig_max * self.df['a_0_flag_debug']
        axs[1].fill_between(self.df['a_0_x'], sig_min, flag_ref, where=flag_ref > sig_min, color="#11a2", label='reference')
        axs[1].fill_between(self.df['a_0_x'], sig_min, flag_sig, where=flag_sig > sig_min, color="#1a12", label='signal')
        axs[1].fill_between(self.df['a_0_x'], sig_min, flag_debug, where=flag_debug > sig_min, color="#a112", label='debug')
        axs[1].set_title(f'Amplifier 0 - row {self._row}')
        axs[1].legend(loc='upper right')

        axs[2].plot('a_1_x', 'a_1_y', data=self.df, color=colors[1], label='Amplifier 1')
        sig_max = self.df['a_1_y'].max()
        sig_min = self.df['a_1_y'].min()
        flag_ref = sig_max * self.df['a_1_flag_ref']
        flag_sig = sig_max * self.df['a_1_flag_sig']
        flag_debug = sig_max * self.df['a_1_flag_debug']
        axs[2].fill_between(self.df['a_1_x'], sig_min, flag_ref, where=flag_ref > sig_min, color="#11a2", label='reference')
        axs[2].fill_between(self.df['a_1_x'], sig_min, flag_sig, where=flag_sig > sig_min, color="#1a12", label='signal')
        axs[2].fill_between(self.df['a_1_x'], sig_min, flag_debug, where=flag_debug > sig_min, color="#a112", label='debug')
        axs[2].set_title(f'Amplifier 1 - row {self._row}')
        axs[2].legend(loc='upper right')

        axs[3].plot('a_2_x', 'a_2_y', data=self.df, color=colors[2])
        sig_max = self.df['a_2_y'].max()
        sig_min = self.df['a_2_y'].min()
        flag_ref = sig_max * self.df['a_2_flag_ref']
        flag_sig = sig_max * self.df['a_2_flag_sig']
        flag_debug = sig_max * self.df['a_0_flag_debug']
        axs[3].fill_between(self.df['a_2_x'], sig_min, flag_ref, where=flag_ref > sig_min, color="#11a2", label='reference')
        axs[3].fill_between(self.df['a_2_x'], sig_min, flag_sig, where=flag_sig > sig_min, color="#1a12", label='signal')
        axs[3].fill_between(self.df['a_2_x'], sig_min, flag_debug, where=flag_debug > sig_min, color="#a112", label='debug')
        axs[3].set_title(f'Amplifier 2 - row {self._row}')
        axs[3].legend(loc='upper right')

        axs[4].plot('a_3_x', 'a_3_y', data=self.df, color=colors[0])
        sig_max = self.df['a_3_y'].max()
        sig_min = self.df['a_3_y'].min()
        flag_ref = sig_max * self.df['a_3_flag_ref']
        flag_sig = sig_max * self.df['a_3_flag_sig']
        flag_debug = sig_max * self.df['a_3_flag_debug']
        axs[4].fill_between(self.df['a_3_x'], sig_min, flag_ref, where=flag_ref > sig_min, color="#11a2", label='reference')
        axs[4].fill_between(self.df['a_3_x'], sig_min, flag_sig, where=flag_sig > sig_min, color="#1a12", label='signal')
        axs[4].fill_between(self.df['a_3_x'], sig_min, flag_debug, where=flag_debug > sig_min, color="#a112", label='debug')
        axs[4].set_title(f'Amplifier 3 - row {self._row}')
        axs[4].legend(loc='upper right')

        if save_path:
            plt.savefig(os.path.join(save_path, '{:04}_{}.png'.format(self.step, 'waveform_zoom')),
                        bbox_inches='tight')

        if show:
            plt.show()

        plt.close()

    def find_lag(self, name_0, name_1, show_plot=False):
        # Normalize
        m_signal_0 = self.df[name_0] - np.mean(self.df[name_0])
        w_signal_0 = m_signal_0 / np.std(m_signal_0)
        m_signal_1 = self.df[name_1] - np.mean(self.df[name_1])
        w_signal_1 = m_signal_1 / np.std(m_signal_1)

        correlation = np.correlate(w_signal_0, w_signal_1, 'full')
        if show_plot:
            plt.plot(correlation)
            plt.show()
        lag = int(len(correlation)/2) - correlation.argmax()
        # print(f'Phase: {lag}')
        return lag

    def get_lags(self):
        for k, v in WaveForms.delay_keys.items():
            self.delays[k] = self.find_lag(*v)

    def fft_analysis(self, fft_max_freq=2E6, freq_threshold=3E5, bit_time=None):
        self.fft_plot_data = {
            'figs_rows': len(self.im.amplifiers),
            'figs_cols': len(self.im.amplifiers[0].rows),
            'data': {},
            'freq_th': freq_threshold,
        }
        # figs_rows = len(self.im.amplifiers)
        # figs_cols = len(self.im.amplifiers[0].rows)
        # sigfig = plt.figure(figsize=(20, figs_rows * 3))
        # fftfig = plt.figure(figsize=(figs_cols * 7, figs_rows * 3))
        # ax_sig = []
        # for i in range(figs_cols):
        #     ax_sig.append(sigfig.add_subplot(figs_cols, 1, i + 1))
        self.fft_peaks = {}
        self.fft_peaks_num = {}
        self.fft_peaks_over_th = {}
        plot_data = self.fft_plot_data['data']
        for ixamp, amp in enumerate(self.im.amplifiers):
            self.fft_peaks[ixamp] = {}
            self.fft_peaks_num[ixamp] = []
            self.fft_peaks_over_th[ixamp] = []
            plot_data[ixamp] = {}
            for ixrow, row in enumerate(amp.rows):
                plot_data[ixamp][ixrow] = {}
                data = np.array([el & 0xffff for el in row.data], dtype='int64')
                data_len = len(data)
                init = 0
                if data_len > 100:
                    data_len = data_len - 100
                    init = 100
                # sample spacing
                sampling_period = 1.0 / 100000000.0
                x = np.linspace(0.0, data_len * sampling_period, data_len)

                # ax = sigfig.add_subplot(figs_rows, figs_cols, ixamp * figs_cols + ixrow + 1)
                plot_data[ixamp][ixrow]['x'] = x
                plot_data[ixamp][ixrow]['data'] = data[init:]
                # ax_sig[ixrow].plot(x, data[init:])
                # ax_sig[ixrow].title.set_text(f'{self.step:04} - Row {ixrow}')
                xf = np.fft.fftfreq(data_len, 1 / 100000000)
                filtered_elements = len(xf[np.logical_and(xf < fft_max_freq, xf > 0)])
                yf = np.fft.rfft(data, filtered_elements * 2)
                freqs = 2.0 / data_len * np.abs(yf[:filtered_elements])
                peaks, _ = scipy.signal.find_peaks(freqs[:filtered_elements], prominence=(0.5, None))
                self.fft_peaks[ixamp][ixrow] = peaks
                self.fft_peaks_num[ixamp].append(len(peaks))
                xf_peaks = xf[peaks]
                xf_peaks_over_th = xf_peaks[xf_peaks > freq_threshold]
                self.fft_peaks_over_th[ixamp].append(len(xf_peaks_over_th))

                plot_data[ixamp][ixrow]['xf'] = xf[:filtered_elements]
                plot_data[ixamp][ixrow]['freqs'] = freqs[:filtered_elements]
                plot_data[ixamp][ixrow]['peaks'] = peaks
                plot_data[ixamp][ixrow]['peaks_over_th'] = len(xf_peaks_over_th)

                # ax = fftfig.add_subplot(figs_rows, figs_cols, ixamp * figs_cols + ixrow + 1)
                #
                # ax.plot(xf[:filtered_elements], freqs[:filtered_elements])
                # ax.plot(xf[peaks], freqs[peaks], 'x')
                # ax.set_yscale('log')
                # ax.title.set_text(
                #     f'FFT Amp {ixamp} - Row {ixrow} - Peaks over {freq_threshold // 1000}KHz: {len(xf_peaks_over_th)}')

    def fft_save_plot(self, out_path, bit_time):
        if self.fft_plot_data is []:
            # If analysis has not been done, do it with default arguments
            self.fft_analysis()
        figs_rows = len(self.im.amplifiers)
        figs_cols = len(self.im.amplifiers[0].rows)
        sigfig = plt.figure(figsize=(20, figs_rows*3))
        fftfig = plt.figure(figsize=(figs_cols*7, figs_rows*3))
        ax_sig = []
        for i in range(figs_cols):
            ax_sig.append(sigfig.add_subplot(figs_cols, 1, i + 1))
        for ixamp, amp in enumerate(self.im.amplifiers):
            for ixrow, row in enumerate(amp.rows):
                plot_data = self.fft_plot_data['data'][ixamp].get(ixrow, None)
                if plot_data is None:
                    print(f"Asking for amp {ixamp} row {ixrow}. Not found")
                    continue
                ax_sig[ixrow].plot(plot_data['x'], plot_data['data'])
                ax_sig[ixrow].title.set_text(f'{self.step:04} - Row {ixrow}')
                ax = fftfig.add_subplot(figs_rows, figs_cols, ixamp * figs_cols + ixrow + 1)

                ax.plot(plot_data['xf'], plot_data['freqs'])
                ax.plot(plot_data['xf'][plot_data['peaks']], plot_data['freqs'][plot_data['peaks']], 'x')
                ax.set_yscale('log')
                ax.title.set_text(f"FFT Amp {ixamp} - Row {ixrow} - "
                                  f"Peaks over {self.fft_plot_data['freq_th']//1000}KHz:"
                                  f"{plot_data['peaks_over_th']}")

        sigfig.savefig(os.path.join(out_path, f'{self.step:04}_waveforms_full.png'),
                       bbox_inches='tight')
        fftfig.suptitle(f"Run id: {self.step:04} - ADC Sync with bit_time {bit_time}")
        fftfig.savefig(os.path.join(out_path, f'{self.step:04}_waveforms_fft.png'),
                       bbox_inches='tight')

        plt.close(sigfig)
        plt.close(fftfig)

        return self.fft_peaks


if __name__ == "__main__":
    import pickle
    FILENAME = './20201113152353/images/0001_waveform.pickle'
    with open(FILENAME, 'rb') as pic:
        im = pickle.load(pic)
    print(type(im))
    wf = WaveForms(im, data_limit=2000, step=1)
    wf.process()
    # wf.gen_plot(save_path='./', show=False)
    wf.fft_save_plot(out_path='./', bit_time=None)
    # print(wf.fft_peaks_num)
    # wf.get_lags()
    # print(wf.delays)
