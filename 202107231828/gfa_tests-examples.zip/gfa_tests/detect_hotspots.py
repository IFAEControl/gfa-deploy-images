#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

# !/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
from gfaaccesslib.api_helpers import GFAExposureLock
import logging
import sys
import os
import cv2
import numpy as np

from tests.defaults import defaults

EXP_TIME_MS = 5000

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:

    defaults.set_default_geom(gfa)

    defaults.set_default_timings(gfa)

    defaults.gfa_powerup_bias(gfa)  # only power up if needed

    defaults.init_adc(gfa)
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:

    print(f"last image id: {sorted(gfa.raws.list_images())[-1] if gfa.raws.list_images() else 'None'}")

    defaults.set_default_ccd_expose_stack(gfa, exposure_time_ms=5000)

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)

    acq_lock = GFAExposureLock()
    gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
    acq_lock.acquire()

    # So we can launch the data taking
    gfa.exposecontroller.remote_start_stack_exec()

    # we wait, that should be done by registering at an async message (TBI)
    acq_lock.acquire()
    acq_lock.release()

    last_im_id = sorted(gfa.raws.list_images())[-1] if gfa.raws.list_images() else None
    print(f"last image id: {last_im_id}")
    # get last image
    if last_im_id:
        im = gfa.raws.get_image(last_im_id)
        print(im.get_ampdata_shape())

    for el in im.get_ampdata():
        print(f"Data type: {el.dtype}, shape: {el.shape}, max value: {el.max()}, average: {el.mean()}")
        el2 = el.astype(np.uint8)
        print(f"Data type: {el2.dtype}, shape: {el2.shape}, max value: {el2.max()}, average: {el2.mean()}")

        th, threshed = cv2.threshold(el2, 10, 15, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        # find contours
        (cnts, _) = cv2.findContours(threshed, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        print(len(cnts))

        # mask = np.ones(el2.shape[:2], dtype=np.uint8) * 255
        # cv2.drawContours(mask, cnts[0], -1, 0, 1)
        # cv2.imshow("Mask", mask)
        # cv2.imshow("Threshold", el2)
        #
        # cv2.imshow("Original", el)

    input(["What the fuck"])

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
