#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 7/17/18
# @Author  : Otger Ballester (otger@ifae.es)
from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import argparse
import time
import math


IP = "10.1.1.1"
IP = "131.243.51.228"
IP = "172.16.17.82"

PORT = 32000
APORT = 32001

POWERDOWN_TIME_STEP_MS = 300
POWERUP_TIME_STEP_MS = 250

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)


def powerdown_ccd(gfa):
    gfa.powercontroller.powerdown_timing_ms = POWERDOWN_TIME_STEP_MS
    gfa.powercontroller.remote_set_phase_timing()

    gfa.exposecontroller.remote_get_status()
    if gfa.exposecontroller.status.ready_state is False:
        raise Exception("GFA must be in ready state to power off the CCD. Current state: {}".format(
            gfa.exposecontroller.status.current_state))

    gfa.exposecontroller.remote_power_down()
    itr = 0
    while gfa.exposecontroller.status.configured_state is False:
        if itr > 10:
            raise Exception("GFA should be in ready state. Current state: {}".format(
                gfa.exposecontroller.status.current_state))
        print(gfa.exposecontroller.status)
        time.sleep(0.5)
        gfa.exposecontroller.remote_get_status()
        itr += 1

    gfa.exposecontroller.remote_get_status()
    print(gfa.exposecontroller.status)

    gfa.powercontroller.remote_get_enables()
    print(gfa.powercontroller.enables)


def powerup_ccd(gfa):
    gfa.powercontroller.powerup_timing_ms = POWERUP_TIME_STEP_MS
    gfa.powercontroller.remote_set_phase_timing()

    gfa.exposecontroller.remote_get_status()
    if gfa.exposecontroller.status.configured_state is False:
        raise Exception("GFA must be in configured state to power up. Current state: {}".format(
            gfa.exposecontroller.status.current_state))
    # finally we can power up the system:
    gfa.exposecontroller.remote_power_up()
    itr = 0
    while gfa.exposecontroller.status.ready_state is False:
        if itr > 10:
            gfa.powercontroller.remote_get_configured_channels()
            print(gfa.powercontroller.dac_channels)
            raise Exception("GFA should be in ready state. Current state: {}".format(
                gfa.exposecontroller.status.current_state))
        print(gfa.exposecontroller.status)
        time.sleep(0.5)
        gfa.exposecontroller.remote_get_status()
        itr += 1

    gfa.exposecontroller.remote_get_status()
    print(gfa.exposecontroller.status)


def configure(gfa):
    gfa.clockmanager.remote_set_ccd_geom()
    gfa.clockmanager.remote_set_clock_timings()
    gfa.powercontroller.remote_set_dac_conf()
    gfa.powercontroller.voltages.set_default_values()
    gfa.powercontroller.remote_set_voltages()


def pp(ans):
    for k in sorted(ans.answer.keys()):
        print("{}: {}".format(k, ans.answer[k]))


if __name__ == "__main__":
    print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
    log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

    # There is no need to connect to ASYNC to configure the gfa
    gfa = GFA(args.ip, PORT)
    try:

        gfa.exposecontroller.remote_get_status()
        if gfa.exposecontroller.status.idle_state:
            print("Configuring gfa")
            configure(gfa)

        gfa.exposecontroller.remote_get_status()
        if gfa.exposecontroller.status.configured_state:
            print("Powering up gfa")
            powerup_ccd(gfa)


        ans = gfa.exposecontroller.remote_get_telemetry()

        ## get base values
        raws = gfa.telemetry.remote_get_voltage_values()
        voltage = None
        for chan in range(32):
            print("Powering down CCD")
            powerdown_ccd(gfa)
            ## set default values
            gfa.powercontroller.voltages.set_default_values()
            voltage = gfa.powercontroller.voltages.get_by_chan(chan)
            original_value = voltage.volts
            voltage.volts = voltage.volts + 0.7
            new_value = voltage.volts
            gfa.powercontroller.remote_set_voltages()
            gfa.powercontroller.remote_get_configured_voltages()
            conf_value = gfa.powercontroller.voltages.get_by_chan(chan).volts
            if abs(conf_value - new_value) > 0.1:
                raise Exception("New value was not set for {}. From {} to {}, instead: {}".format(voltage.name,
                                                                                                  original_value,
                                                                                                  new_value,
                                                                                                  conf_value))
            powerup_ccd(gfa)
            ans = gfa.exposecontroller.remote_get_telemetry()

            raws2 = gfa.telemetry.remote_get_voltage_values()

            print("Changed values when modifying {}:".format(voltage.name))
            for k, v in raws.answer.items():
                if raws2.answer.get(k, None):
                    name = '_'.join(k.split('_')[0:2])
                    if abs(raws2.answer[k] - v) > 20:
                        print("\t-{}: {} ({}) - {}".format(k, v, v & 0b111111111111, raws2.answer[k]))

    except Exception:
        log.exception("Something broke")
    finally:
        gfa.close()
