#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '6/4/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

import gfaaccesslib.gfa

import datetime


def extract_debug_info(gfa: gfaaccesslib.gfa.GFA):
    debug = {'scan_time': datetime.datetime.now(tz=datetime.timezone.utc).strftime("%d/%m/%Y %H:%M:%S")}

    # interrupts:
    gfa.irq.remote_get_status()
    debug['interrupts'] = {}
    debug['interrupts']['status_bits'] = gfa.irq.status.status_bits
    debug['interrupts']['received_img_start'] = gfa.irq.status.received_img_start
    debug['interrupts']['received_line'] = gfa.irq.status.received_line
    debug['interrupts']['received_ccd_done'] = gfa.irq.status.received_ccd_done
    debug['interrupts']['received_telemetry'] = gfa.irq.status.received_telemetry
    debug['interrupts']['processed_img_start'] = gfa.irq.status.processed_img_start
    debug['interrupts']['processed_line'] = gfa.irq.status.processed_line
    debug['interrupts']['processed_ccd_done'] = gfa.irq.status.processed_ccd_done
    debug['interrupts']['processed_telemetry'] = gfa.irq.status.processed_telemetry
    debug['interrupts']['clear_us_img_start'] = gfa.irq.status.clear_us_img_start
    debug['interrupts']['clear_us_line'] = gfa.irq.status.clear_us_line
    debug['interrupts']['clear_us_ccd_done'] = gfa.irq.status.clear_us_ccd_done
    debug['interrupts']['clear_us_telemetry'] = gfa.irq.status.clear_us_telemetry

    # buffers:
    gfa.buffers.remote_get_buffers_status()
    gfa.buffers.remote_get_data_mode()
    debug['buffers'] = {}
    debug['buffers']['stream_status_word'] = gfa.buffers.status.stream_status_word
    debug['buffers']['pending_lines_buffer'] = {
        'pending_lines': gfa.buffers.status.pending_lines & 0xffff,
        'buffer_overflow': bool(gfa.buffers.status.pending_lines & 1 << 16),
        'buffer_underflow': bool(gfa.buffers.status.pending_lines & 1 << 17),
        'buffer_empty': bool(gfa.buffers.status.pending_lines & 1 << 18),
        'buffer_full': bool(gfa.buffers.status.pending_lines & 1 << 19),
    }
    debug['buffers']['provider'] = gfa.buffers.status.provider
    debug['buffers']['mode'] = gfa.buffers.status.mode
    debug['buffers']['buffers'] = {}
    for el in gfa.buffers.status.buffers:
        debug['buffers']['buffers'][el.buffer_index] = {
            'contents': el.contents,
            'has_overflow': el.has_overflow,
            'has_underflow': el.has_underflow,
            'is_empty': el.is_empty,
            'is_full': el.is_full,
            'enabled': el.is_enabled,
            'status': el.status_word,
            'enabled_word': el.enabled_word
        }
    # expose controller
    debug['expose_ctrlr'] = {}
    gfa.exposecontroller.remote_get_status()
    debug['expose_ctrlr']['state'] = gfa.exposecontroller.status.current_state
    debug['expose_ctrlr']['powered'] = gfa.exposecontroller.status.is_powered

    # sysinfo
    debug['sysinfo'] = {}
    debug['sysinfo']['remote_mac'] = gfa.sys.remote_mac().answer
    debug['sysinfo']['remote_version'] = gfa.sys.remote_version().answer
    debug['sysinfo']['remote_api'] = gfa.sys.remote_api().answer

    # heartbeat
    debug['heartbeat'] = {}
    gfa.heartbeat.remote_update()
    debug['heartbeat']['address'] = gfa.heartbeat.status.address
    debug['heartbeat']['enabled'] = gfa.heartbeat.status.enabled
    debug['heartbeat']['interval'] = gfa.heartbeat.status.interval
    debug['heartbeat']['retries'] = gfa.heartbeat.status.retries
    debug['heartbeat']['errors'] = gfa.heartbeat.status.errors
    debug['heartbeat']['last_ping_ts'] = gfa.heartbeat.status.last_ping_ts
    debug['heartbeat']['last_ping_error_ts'] = gfa.heartbeat.status.last_ping_error_ts

    # clockmanager
    debug['clock_mgr'] = {}
    gfa.clockmanager.remote_get_stack_contents()
    gfa.clockmanager.remote_get_status()
    debug['clock_mgr']['info'] = gfa.clockmanager.info._info
    debug['clock_mgr']['status'] = {}
    debug['clock_mgr']['status']['status'] = gfa.clockmanager.info.status.status
    debug['clock_mgr']['status']['bin status'] = gfa.clockmanager.info.status.str_status
    debug['clock_mgr']['status']['stack full'] = gfa.clockmanager.info.status.stack_full
    debug['clock_mgr']['status']['stack empty'] = gfa.clockmanager.info.status.stack_empty
    debug['clock_mgr']['status']['executing_last_command'] = gfa.clockmanager.info.status.executing_last_cmd
    debug['clock_mgr']['status']['running'] = gfa.clockmanager.info.status.running
    debug['clock_mgr']['status']['force execute'] = gfa.clockmanager.info.status.force_execute
    debug['clock_mgr']['status']['clear stack'] = gfa.clockmanager.info.status.clear_stack
    debug['clock_mgr']['status']['reset execution pointer'] = gfa.clockmanager.info.status.reset_exec_pointer
    debug['clock_mgr']['status']['shift storage lines'] = gfa.clockmanager.info.status.shift_storage
    debug['clock_mgr']['status']['shift image lines'] = gfa.clockmanager.info.status.shift_image
    debug['clock_mgr']['status']['amplifiers fg enabled'] = gfa.clockmanager.info.status.amplifier_fg
    debug['clock_mgr']['status']['amplifiers eh enabled'] = gfa.clockmanager.info.status.amplifier_eh
    debug['clock_mgr']['status']['all settings configured'] = gfa.clockmanager.info.status.is_configured

    # stack
    gfa.clockmanager.remote_get_stack_contents()
    debug['stack'] = {
        'human': gfa.clockmanager.stack.translate_2_human()
    }

    return debug


def save_as_yaml(debug_info, path):
    import yaml
    with open(path, 'w') as fp:
        yaml.dump(debug_info, fp)


if __name__ == '__main__':
    from gfaaccesslib.gfa import GFA
    import json

    gfa = GFA(ip='172.16.17.82', port=32000)
    debug_info = extract_debug_info(gfa)
    print(json.dumps(debug_info, indent=2))
    save_as_yaml(debug_info, './debug_info.yaml')
