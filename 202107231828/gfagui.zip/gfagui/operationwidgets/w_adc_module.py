from PyQt5.QtWidgets import QWidget, QTableWidgetItem
from .ui.adc_controller_module_ui import Ui_adc_module
from . import colors
from gfaaccesslib.gfa import GFA
import time

ADC_START_ACQ = (1 << 0)
ADC_STOP_ACQ = (1 << 1)
ADC_NO_RESET = (1 << 11)
ADC_PWRDOWN = (1 << 12)
PATTERN_MATCH_ENABLE = (1 << 16)
PATTERN_CLEAR = (1 << 17)


class WidgetADCModule(QWidget):
    def __init__(self, gfa):
        super().__init__()
        self._gfa: GFA = gfa.gfa
        self._ui = Ui_adc_module()
        self._setup_ui()

    def _setup_ui(self):
        self._ui.setupUi(self)
        self._ui.pb_get_bittime.clicked.connect(self._ui_update_bt)
        self._ui.pb_set_bittime.clicked.connect(self._set_bt)
        self._ui.pb_update_all_fields.clicked.connect(self._update_all)
        # self._ui.pb_update_status.clicked.connect(self._update_status)
        self._ui.pb_update_channel_values.clicked.connect(self._ui_update_init_rx_data)
        self._ui.pb_adc_sync.clicked.connect(self._sync_adc)
        self._ui.pb_update_pattern_values.clicked.connect(self._ui_update_rx_expected_pattern)
        self._ui.pb_update_if_values.clicked.connect(self._ui_update_if)
        self._ui.pb_pattern_check_dis.clicked.connect(self._stop_check_pattern)
        self._ui.pb_pattern_check_en_5555.clicked.connect(self._en_pattern_5555)
        self._ui.pb_pattern_check_en_aeae.clicked.connect(self._en_pattern_aeae)
        self._ui.pb_pattern_check_en_ae53.clicked.connect(self._en_pattern_ae53)
        self._ui.pb_pattern_check_en_a5a5.clicked.connect(self._en_pattern_a5a5)
        self._ui.pb_update_pattern_values.clicked.connect(self._update_all)
        # self._ui.pb_adc_start_acq.clicked.connect(self._adc_start_acq_data)
        # self._ui.pb_adc_stop_acq.clicked.connect(self._adc_stop_acq_data)
        self._ui.pb_adc_set_ramp_pattern.clicked.connect(self._set_ramp_pattern_adc)
        self._ui.pb_remove_adc_pattern.clicked.connect(self._adc_remove_pattern)
        self._ui.pb_clear_pattern_errors.clicked.connect(self._clear_adc_pattern_errors)
        self._ui.pb_adc_reset.clicked.connect(self._adc_reset)
        self._ui.pb_adc_pwrdn.clicked.connect(self._adc_pwrdn)
        self._ui.pb_adc_pwrup.clicked.connect(self._adc_pwrup)

    def _ui_update_bt(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_bit_time_value()
        self._ui.le_bit_time.setText(str(self._gfa.adccontroller.hw_if.bit_time))

    def _set_bt(self):
        value = int(self._ui.le_bit_time.text())
        self._gfa.adccontroller.remote_set_bit_time_value(value)
        self._ui.le_bit_time.setText('')
        self._ui_update_bt()

    def _ui_update_status(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_status()

        def _color(key):
            return colors.txt_green if status.get(key) else colors.txt_orange

        status = self._gfa.adccontroller.status.as_dict()
        self._ui.lbl_calib_busy.setStyleSheet(f"background-color: {_color('calib_busy')};")
        self._ui.lbl_fast_cosgen.setStyleSheet(f"background-color: {_color('fast_cosinus')};")
        self._ui.lbl_adc_pwdn.setStyleSheet(f"background-color: {_color('power_down')};")
        self._ui.lbl_reading.setStyleSheet(f"background-color: {_color('reading')};")
        self._ui.lbl_reset_adc.setStyleSheet(f"background-color: {_color('reset_adc')};")
        self._ui.lbl_cosgen.setStyleSheet(f"background-color: {_color('select_cos_gen')};")
        self._ui.lbl_spi_ready.setStyleSheet(f"background-color: {_color('spi_ready')};")

        status = self._gfa.adccontroller.status.init_status.as_dict()
        self._ui.lbl_init_state_name.setText(self._gfa.adccontroller.status.init_status.state)
        self._ui.lbl_calib_done.setStyleSheet(f"background-color: {_color('done')};")
        self._ui.lbl_calib_ready.setStyleSheet(f"background-color: {_color('ready')};")
        self._ui.lbl_set_init.setStyleSheet(f"background-color: {_color('set_init')};")
        self._ui.lbl_init_busy.setStyleSheet(f"background-color: {_color('i_init_busy')};")
        self._ui.lbl_init_done.setStyleSheet(f"background-color: {_color('i_init_done')};")
        self._ui.lbl_frame_bs_finished.setStyleSheet(f"background-color: {_color('bs_finished_frame')};")
        self._ui.lbl_align_frame.setStyleSheet(f"background-color: {_color('align_frame')};")
        self._ui.lbl_frame_aligned.setStyleSheet(f"background-color: {_color('frame_aligned')};")
        self._ui.lbl_data_bs_finished.setStyleSheet(f"background-color: {_color('bs_finished_data')};")
        self._ui.lbl_flag1.setStyleSheet(f"background-color: {_color('flag1')};")
        self._ui.lbl_flag2.setStyleSheet(f"background-color: {_color('flag2')};")
        self._ui.lbl_good_pattern.setStyleSheet(f"background-color: {_color('good_pattern')};")
        self._ui.lbl_good_pattern_full.setStyleSheet(f"background-color: {_color('good_pattern_full')};")

    def _ui_update_init_rx_data(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_init_rx_data()
        status = self._gfa.adccontroller.status.init_status.as_dict()
        self._ui.label_rx_ch0.setText(f"0x{status.get('rx_data_chan0'):0x}")
        self._ui.label_rx_ch1.setText(f"0x{status.get('rx_data_chan1'):0x}")
        self._ui.label_rx_ch2.setText(f"0x{status.get('rx_data_chan2'):0x}")
        self._ui.label_rx_ch3.setText(f"0x{status.get('rx_data_chan3'):0x}")

    def _ui_update_rx_expected_pattern(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_init_rx_expected_pattern()
        self._ui.le_expected_pattern.setText(f"0x{self._gfa.adccontroller.status.init_status.rx_expected_pattern:08x}")

    def _ui_update_if(self, get_remote=True):
        self._ui_update_if_bitslips(get_remote)
        self._ui_update_if_delays(get_remote)

    def _ui_update_if_bitslips(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_if_bitslips()
        hw_if = self._gfa.adccontroller.hw_if.as_dict()
        self._ui.tableWidget.setItem(0, 0, QTableWidgetItem(str(hw_if.get('bs.frame'))))
        for i in range(1, 9):
            self._ui.tableWidget.setItem(0, i, QTableWidgetItem(str(hw_if.get(f'bs.out{i}'))))

    def _ui_update_if_delays(self, get_remote=True):
        if get_remote:
            self._gfa.adccontroller.remote_get_if_delays()
        hw_if = self._gfa.adccontroller.hw_if.as_dict()
        self._ui.tableWidget.setItem(1, 0, QTableWidgetItem(str(hw_if.get('delay.frame'))))
        for i in range(1, 9):
            self._ui.tableWidget.setItem(1, i, QTableWidgetItem(str(hw_if.get(f'delay.out{i}m'))))
        for i in range(1, 9):
            self._ui.tableWidget.setItem(2, i, QTableWidgetItem(str(hw_if.get(f'delay.out{i}s'))))

    def _sync_adc(self):

        # update ui
        self._update_all()
        self._ui.lbl_sync_result.setText("")

        self._gfa.adccontroller.set_adc_reset_pin(0)
        self._gfa.adccontroller.set_adc_reset_pin(1)
        self._gfa.adccontroller.set_adc_powerdown_pin(False)
        self._gfa.adccontroller.reset_adc_controller()

        self._gfa.adccontroller.adc_init_calib()
        # self._gfa.adccontroller.remote_get_status()  # get_status executed inside _update_status

        # self._ui_update_status()
        self._update_all()
        if self._gfa.adccontroller.status.init_status.state != 's_init':
            self._ui.lbl_sync_result.setStyleSheet(f"color: {colors.default_red}")
            self._ui.lbl_sync_result.setText(f"Failed to set calibration state")
            raise Exception('System should be at calibration')

        # reset adc chip by spi
        self._gfa.adccontroller.spi_write(0x0, 0x1)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x0, 0x1)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x0, 0x0)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x0, 0x0)
        time.sleep(0.1)

        # configure serialization on adc
        self._gfa.adccontroller.spi_write(0x46, 0x8801)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x46, 0x8801)
        time.sleep(0.1)

        # set expected data pattern
        self._gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)
        time.sleep(0.1)
        self._ui_update_rx_expected_pattern()

        # set adc to output sync pattern
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x45, 0x2)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x45, 0x2)

        # start align frame
        # self._ui_update_status()
        self._update_all()
        self._gfa.adccontroller.adc_calib_align_frame()

        # check it has finished aligning frame
        for i in range(10):
            # self._gfa.adccontroller.remote_get_status()  # get_status executed inside _update_status
            # self._ui_update_status()
            self._update_all()
            if self._gfa.adccontroller.status.init_status.frame_aligned:
                break
        else:
            # ToDo: show a message on screen
            self._ui.lbl_sync_result.setStyleSheet(f"color: {colors.default_red}")
            self._ui.lbl_sync_result.setText(f"Failed to align frame")
            raise Exception('Frame could not be aligned')

        self._update_all()

        # align data
        self._gfa.adccontroller.adc_calib_align_data()
        self._update_all()

        self._gfa.adccontroller.adc_calib_bitslip()

        self._update_all()

        # self._gfa.adccontroller.remote_get_status()
        # self._ui_update_status()
        # self._gfa.adccontroller.remote_get_init_rx_expected_pattern()
        # self._ui_update_status()
        # self._gfa.adccontroller.remote_get_init_rx_data()
        # self._ui_update_status()
        # print(self._gfa.adccontroller.status)

        # remove pattern
        self._gfa.adccontroller.spi_write(0x45, 0x0)
        time.sleep(0.1)
        self._gfa.adccontroller.spi_write(0x45, 0x0)
        time.sleep(0.1)

        self._gfa.adccontroller.adc_stop_calib()
        self._update_all()

    def _set_ramp_pattern_adc(self):
        self._gfa.adccontroller.spi_write(0x25, 0x40)

    def _check_pattern(self, pattern):

        #  Configure ADC to output pattern
        x25_reg_val = 0x10 | ((pattern & 0xc000) >> 14)
        x26_reg_val = (pattern & 0x3fff) << 2
        print(f"0x25: {x25_reg_val:04x} - 0x26: {x26_reg_val:04x}")

        self._gfa.adccontroller.spi_write(0x26, x26_reg_val)
        time.sleep(0.001)
        self._gfa.adccontroller.spi_write(0x25, x25_reg_val)
        time.sleep(0.001)

        # Set expected pattern
        self._gfa.adccontroller.remote_set_init_rx_expected_pattern(pattern)
        # clear pattern matching counters
        # ADC_RESET must be kept at 1 to operate the ADC
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | PATTERN_CLEAR)
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | PATTERN_MATCH_ENABLE)

    def _clear_adc_pattern_errors(self):
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | PATTERN_CLEAR)

    def _stop_check_pattern(self):

        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET)
        self._adc_remove_pattern()

    def _adc_remove_pattern(self):
        # remove pattern
        self._gfa.adccontroller.spi_write(0x25, 0x0)
        self._gfa.adccontroller.spi_write(0x26, 0x0)

    def _en_pattern_5555(self):
        self._check_pattern(0x5555)

    def _en_pattern_aeae(self):
        self._check_pattern(0xaeae)

    def _en_pattern_ae53(self):
        self._check_pattern(0xae53)

    def _en_pattern_a5a5(self):
        self._check_pattern(0xa5a5)

    def _update_all(self):
        ans = self._gfa.adccontroller.remote_read_all_regs().answer

        self._ui.lbl_pat_err_ch0.setText(f"{self._gfa.adccontroller.status.pattern_check.errors_ch0}/"
                                         f"{self._gfa.adccontroller.status.pattern_check.samples}")
        self._ui.lbl_pat_err_ch1.setText(f"{self._gfa.adccontroller.status.pattern_check.errors_ch1}/"
                                         f"{self._gfa.adccontroller.status.pattern_check.samples}")
        self._ui.lbl_pat_err_ch2.setText(f"{self._gfa.adccontroller.status.pattern_check.errors_ch2}/"
                                         f"{self._gfa.adccontroller.status.pattern_check.samples}")
        self._ui.lbl_pat_err_ch3.setText(f"{self._gfa.adccontroller.status.pattern_check.errors_ch3}/"
                                         f"{self._gfa.adccontroller.status.pattern_check.samples}")

        self._ui.le_expected_pattern.setText(f"0x{self._gfa.adccontroller.status.init_status.rx_expected_pattern:04x}")

        self._ui_update_bt(get_remote=False)
        self._ui_update_status(get_remote=False)
        self._ui_update_init_rx_data(get_remote=False)
        self._ui_update_rx_expected_pattern(get_remote=False)
        self._ui_update_if(get_remote=False)

    def _adc_start_acq_data(self):
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | ADC_START_ACQ)
        self._gfa.adccontroller.spi_write(0xf, 0x0)
        # Set Gain of ADC to 0db
        self._gfa.adccontroller.spi_write(0x2a, 0x0)
        self._update_all()

    def _adc_stop_acq_data(self):
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | ADC_STOP_ACQ)
        self._update_all()

    def _adc_reset(self):
        self._gfa.adccontroller.remote_write_register(1, 0)
        time.sleep(0.01)
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET)

    def _adc_pwrdn(self):
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET | ADC_PWRDOWN)

    def _adc_pwrup(self):
        self._gfa.adccontroller.remote_write_register(1, ADC_NO_RESET)


