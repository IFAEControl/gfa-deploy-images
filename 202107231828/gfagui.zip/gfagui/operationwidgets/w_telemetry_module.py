from PyQt5.QtWidgets import QWidget
from . ui.widget_telemetry_module_ui import Ui_widget_ambient_sensors
from . import colors
from gfaaccesslib.gfa import GFA
import pprint
from datetime import datetime, timezone
import traceback


class WidgetTelemetryModule(QWidget):
    def __init__(self, gfa):
        super().__init__()
        self._gfa: GFA = gfa.gfa
        self._ui = Ui_widget_ambient_sensors()
        self._setup_ui()

    def _setup_ui(self):
        self._ui.setupUi(self)
        self._ui.pb_xadc_meta.clicked.connect(self._xadc_meta)
        self._ui.pb_xadc_values.clicked.connect(self._xadc_voltages)
        self._ui.pb_xadc_temp.clicked.connect(self._xadc_temp)
        self._ui.pb_telemetry_status.clicked.connect(self._telem_status)
        self._ui.pb_voltage_values.clicked.connect(self._get_voltage_values)
        self._ui.pb_sensors_read.clicked.connect(self._force_sensors_read)
        # CustomCloseEventSignal().signal.connect(self.close)

    def _echo_err(self, text):
        self._echo(text, colors.log_error)

    def _echo_answer(self, text):
        self._echo(text, colors.log_info)

    def _echo(self, text, color):
        c = self._ui.te_output.textColor()
        print(c)
        self._ui.te_output.setTextColor(colors.log_date)
        self._ui.te_output.append(datetime.now(tz=timezone.utc).strftime("%d/%m/%Y %H:%M:%S"))
        self._ui.te_output.setTextColor(color)
        self._ui.te_output.append(text)
        self._ui.te_output.setTextColor(c)

    def _exec_cmd_and_print_ans(self, cmd_function):
        try:
            ans = cmd_function()
        except Exception as ex:
            self._echo_err(traceback.format_exc())
        else:
            self._echo_answer(pprint.pformat(ans.answer))

    def _xadc_voltages(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_get_xadc_voltages)

    def _xadc_meta(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_get_xadc_meta)

    def _xadc_temp(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_get_xadc_temp)

    def _telem_status(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_get_status)

    def _get_voltage_values(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_get_voltage_values)

    def _force_sensors_read(self):
        self._exec_cmd_and_print_ans(self._gfa.telemetry.remote_force_sensors_read)

