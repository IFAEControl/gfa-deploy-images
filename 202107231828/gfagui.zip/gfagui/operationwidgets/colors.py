#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" A simple python script

"""
__author__ = 'Otger Ballester'
__copyright__ = 'Copyright 2021'
__date__ = '19/5/21'
__credits__ = ['Otger Ballester', ]
__license__ = 'CC0 1.0 Universal'
__version__ = '0.1'
__maintainer__ = 'Otger Ballester'
__email__ = 'otger@ifae.es'

from PyQt5.QtGui import QColor

txt_black = "#242020"
txt_orange = "#e08802"
txt_green = "#0bb005"
txt_red = "#d12815"

default_black = QColor(txt_black)
default_red = QColor(txt_red)
default_light_gray = QColor("#b0b0b0")
default_blue = QColor("#343fa3")
default_orange = QColor(txt_orange)
default_green = QColor(txt_green)

log_debug = default_black
log_error = default_red
log_date = default_light_gray
log_info = default_blue

default_async = default_black
async_row = default_black
async_error = default_red