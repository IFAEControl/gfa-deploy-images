from PyQt5.QtWidgets import QWidget, QTableWidgetItem
from PyQt5.QtGui import QValidator, QIntValidator
from .ui.widget_acq_modes_ui import Ui_AcqModesWidget
from gfaaccesslib.gfa import GFA
import time


class WidgetACQModes(QWidget):
    def __init__(self, gfa):
        super().__init__()
        self._gfa: GFA = gfa.gfa
        self._ui = Ui_AcqModesWidget()
        self._setup_ui()

    def _setup_ui(self):
        self._ui.setupUi(self)
        self._ui.le_exp_time.setValidator(QIntValidator(0, 9999999))
        self._ui.le_wf_dump_rows.setValidator(QIntValidator(0, 999))
        self._ui.le_wf_skip_cols.setValidator(QIntValidator(0, 999))
        self._ui.le_wf_read_rows.setValidator(QIntValidator(0, 999))
        self._ui.le_wf_read_cols.setValidator(QIntValidator(0, 999))
        self._ui.pb_acq_waveform.clicked.connect(self._launch_waveform_acq)

    def _acq_waveform(self, exp_time=0, dump_rows=600, read_rows=10, skip_columns=150, roi_width=20):
        """
        Sequence to acquire active area and dump storage
        """
        self._gfa.adccontroller.spi_write(0xf, 0x0)
        self._gfa.adccontroller.spi_write(0x2a, 0x0)
        self._gfa.adccontroller.adc_start_acq()
        g = self._gfa.clockmanager.stack

        g.clear()
        g.add_new_image_cmd()
        g.add_set_modes_cmd(True, True, True, True)
        # Clear CCD
        g.add_dump_rows_cmd(512 + 544)
        g.add_wait_cmd(exp_time)
        g.add_dump_rows_cmd(dump_rows)
        if roi_width:
            g.add_set_roi_conf_cmd(skip_columns=skip_columns, roi_width=roi_width)
        # g.add_read_rows_roi_and_overscan_cmd(read_rows)
        # g.add_read_rows_cmd(read_rows)
        g.add_read_rows_roi_cmd(read_rows)

        g.add_none_cmd()
        self._gfa.clockmanager.remote_set_stack_contents()
        self._gfa.buffers.remote_set_data_provider(0, 4)

        # self.acq_lock.acquire()
        self._gfa.exposecontroller.remote_start_stack_exec()

        # self.acq_lock.acquire()
        # self.acq_lock.release()

        # self.last_wave_imnum = sorted(self.gfa.raws.list_images())[-1]

        # return self.last_wave_imnum

    def _launch_waveform_acq(self):
        exp_time = int(self._ui.le_exp_time.text())
        dump_rows = int(self._ui.le_wf_dump_rows.text())
        read_rows = int(self._ui.le_wf_read_rows.text())
        skip_cols = int(self._ui.le_wf_skip_cols.text())
        read_cols = int(self._ui.le_wf_read_cols.text())

        self._acq_waveform(exp_time, dump_rows, read_rows, skip_cols, read_cols)
