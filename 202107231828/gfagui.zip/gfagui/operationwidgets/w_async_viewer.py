from PyQt5.QtWidgets import QWidget
from . ui.asyncs_viewer_ui import Ui_asyncs_viewer
from . import colors
from gfaaccesslib.gfa import GFA
import pprint
from datetime import datetime, timezone
import traceback
from gfaaccesslib.comm import header


class AsyncClasses:
    row = header.RawRowHeader
    resources = header.ResourcesHeader
    start_im = header.AsyncImageStartHeader
    done_im = header.AsyncImageDoneHeader
    telem_v = header.AsyncTelemetryVoltages
    telem_s = header.AsyncTelemetrySensors
    telem_a = header.AsyncTelemetryAlarms
    pid = header.AsyncPID
    error = header.ErrorPacket


class WidgetAsyncViewer(QWidget):
    def __init__(self, gfa):
        super().__init__()
        self._gfa: GFA = gfa.gfa
        self._ui = Ui_asyncs_viewer()
        self._info = {
            'row': ['Row', 0],
            'resources': ['Resources', 0],
            'start_im': ['Image Start', 0],
            'done_im': ['Image Done', 0],
            'telem_v': ['Telemetry', 0],
            'telem_s': ['Sensors Reading', 0],
            'telem_a': ['Telemetry Alarms', 0],
            'pid': ['PID', 0],
            'error': ['Error', 0]
        }
        # self._lines = []
        self._setup_ui()

    def _shit(self, *args, **kwargs):
        print(f"Signal received. args: {args} - kwargs: {kwargs}")
        self.close()
        print(f"closed")

    def _setup_ui(self):
        self._ui.setupUi(self)
        self._gfa.async_manager.add_pid_callback(self._callback)
        self._gfa.async_manager.add_error_callback(self._callback)
        self._gfa.async_manager.add_telemetry_callback(self._callback)
        self._gfa.async_manager.add_end_image_callback(self._callback)
        self._gfa.async_manager.add_new_image_callback(self._callback)
        self._gfa.async_manager.add_sensors_reading_callback(self._callback)
        self._gfa.async_manager.add_alarms_callback(self._callback)
        self._gfa.async_manager.add_resources_callback(self._callback)
        self._gfa.async_manager.add_row_callback(self._callback)

    def _callback(self, header, jsondata, raw=None):
        if isinstance(header, AsyncClasses.row):
            self._info['row'][1] += 1
            # self._ui.cb_row.setText(f"{self._info['row'][0]} ({self._info['row'][1]})")
            if self._ui.cb_row.isChecked():
                self._echo(f"Row data: {header.metadata_bytes}bytes metadata - {header.raw_bytes}bytes payload - "
                           f"im id: {header.image_id} - row num: {header.row_number} - "
                           f"row width: {header.row_width} - {header.pixel_bytes}bytes pixel",
                           colors.async_row)
        if isinstance(header, AsyncClasses.resources):
            self._default('resources', self._ui.cb_resources, jsondata, colors.default_black)
        if isinstance(header, AsyncClasses.start_im):
            self._default('start_im', self._ui.cb_im_start, jsondata, colors.default_blue)
        if isinstance(header, AsyncClasses.done_im):
            self._default('done_im', self._ui.cb_im_done, jsondata, colors.default_blue)
            self._ui.cb_row.setText(f"{self._info['row'][0]} ({self._info['row'][1]})")
        if isinstance(header, AsyncClasses.telem_v):
            self._default('telem_v', self._ui.cb_telemetry, jsondata, colors.default_black)
        if isinstance(header, AsyncClasses.telem_s):
            self._default('telem_s', self._ui.cb_sensors_reading, jsondata, colors.default_black)
        if isinstance(header, AsyncClasses.telem_a):
            self._default('telem_a', self._ui.cb_alarms, jsondata, colors.default_black)
        if isinstance(header, AsyncClasses.pid):
            self._default('pid', self._ui.cb_pid, jsondata, colors.default_black)
        if isinstance(header, AsyncClasses.error):
            self._default('error', self._ui.cb_error, jsondata, colors.default_red)

    def _default(self, info, cb, jsondata, color):
        self._info[info][1] += 1
        cb.setText(f"{self._info[info][0]} ({self._info[info][1]})")
        if cb.isChecked() and self._ui.cb_show_payload.isChecked():
            self._echo(f"{info}: {pprint.pformat(jsondata)}",
                       color)
        elif cb.isChecked():
            self._echo(f"{info}",
                       color)

    def _echo(self, text, color):
        # c = self._ui.pte_viewer.textColor()
        date = datetime.now(tz=timezone.utc).strftime("%d/%m/%Y %H:%M:%S")
        # self._lines.append((date, text, color))
        # self._lines = self._lines[-self._ui.sb_limit_lines.value():]
        # self._ui.pte_viewer.setTextColor(colors.log_date)
        # self._ui.pte_viewer.insertPlainText(date)
        # self._ui.pte_viewer.setTextColor(color)
        self._ui.pte_viewer.insertPlainText(f"{date}: {text}\n")
        # self._ui.pte_viewer.setTextColor(c)
