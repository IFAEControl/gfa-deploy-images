#!/usr/bin/python3
# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import QMainWindow
from PyQt5 import QtGui
from PyQt5.QtCore import QObject, pyqtSignal

from .widgets.ui.mainwindow_ui import Ui_MainWindow


class CustomCloseEventSignal(QObject):
    signal = pyqtSignal()


class GUI(QMainWindow):

    def __init__(self):
        super(GUI, self).__init__()
        self.main_window = Ui_MainWindow()
        self.main_window.setupUi(self)
        self.closing_signal = CustomCloseEventSignal()

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        self.closing_signal.signal.emit()
        super(GUI, self).closeEvent(a0)
