#!/usr/bin/python3
# -*- coding: utf-8 -*-

import argparse
import sys
import traceback

# Workarond for debian based systems
import os

os.environ.setdefault("QT_API", "pyqt5")

import coloredlogs
from PyQt5.QtCore import QCoreApplication, Qt
from PyQt5.QtWidgets import QApplication

from pyqt_tools import messages

from .config.config import get_valid_config
from .god import GOD


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--log-level', '-l', dest='loglevel', metavar='INFO', default='INFO', help='log level')
    parser.add_argument('--gfa-log-path', '-g', dest='gfalogpath', default=None,
                        help="Path to save log file of gfaaccesslib. Default is not to save log files")
    parser.add_argument('--gfa-log-level', '-s', dest='gfaloglevel', default='DEBUG',
                        help="Level of logs of gfaaccesslib to be saved to file. Default is DEBUG")
    args = parser.parse_args()

    coloredlogs.install(level=args.loglevel,
                        fmt='%(asctime)s,%(msecs)03d %(name)s[%(process)d] %(levelname)s %(message)s')

    if args.gfalogpath:
        import logging
        from logging.handlers import RotatingFileHandler

        _nameToLevel = {
            'CRITICAL': logging.CRITICAL,
            'FATAL': logging.FATAL,
            'ERROR': logging.ERROR,
            'WARN': logging.WARNING,
            'WARNING': logging.WARNING,
            'INFO': logging.INFO,
            'DEBUG': logging.DEBUG,
            'NOTSET': logging.NOTSET,
        }
        from gfaaccesslib.logger import log, comm_debug_log, formatter

        fh = RotatingFileHandler(filename=os.path.join(args.gfalogpath, 'gfaacesslib.log'),
                                 maxBytes=5 * 1024 * 1024, backupCount=5)
        fh.setLevel(level=_nameToLevel[args.gfaloglevel])
        fh.setFormatter(formatter)
        log.addHandler(fh)

        fh2 = RotatingFileHandler(filename=os.path.join(args.gfalogpath, 'gfa_comm_debug.log'),
                                  maxBytes=5 * 1024 * 1024, backupCount=5)
        fh2.setLevel(level=_nameToLevel[args.gfaloglevel])
        fh2.setFormatter(formatter)
        comm_debug_log.addHandler(fh2)
        comm_debug_log.info('Added filehandler to comm_debug_log')

    try:
        QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
        app = QApplication(sys.argv)

        cfg = get_valid_config()
        god = GOD(cfg)
        god.show_main_window()
        ret = app.exec_()
        god.close()
        sys.exit(ret)
    except Exception as ex:
        traceback.print_tb(ex)
        msg = "Can not run client: {}".format(ex)
        messages.show_fatal(msg, "Error during startup")


if __name__ == "__main__":
    main()
