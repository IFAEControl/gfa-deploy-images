import datetime
from gfaaccesslib.comm.gfasocket import GFASocket
from gfaaccesslib.comm.header import build_header, RawRowHeader, ResourcesHeader, AsyncImageStartHeader, \
    AsyncImageDoneHeader, AsyncTelemetryVoltages, AsyncTelemetryAlarms, AsyncTelemetrySensors, AsyncPID, ErrorPacket, \
    get_header_type_name
from gfaaccesslib.comm.errorpackage import ErrorPackage
from gfaaccesslib.comm.command import CommandPacket
from gfaaccesslib.logger import comm_debug_log
from .logger import log as comm_log
import json
import threading
import queue
import socket

__author__ = 'otger'

log = comm_log.getChild('communication')

# next loggers are for debugging problems with missing rows at KPNO
clog = comm_debug_log.getChild('comm_mgr')
alog = comm_debug_log.getChild('async_mgr')


# ToDo: Make a module inside communication manager called statistics
# ToDo: at statistics: how many commands have been executed and of which type
# ToDo: at statistics: how many bytes sent
# ToDo: at statistics: how many bytes received (separated by header types)


class CommStats(object):
    def __init__(self):
        self._sent_bytes = {'total': 0}
        self._rcvd_bytes = {'total': 0}

    def sent_bytes(self, num_bytes, xfer_type=''):
        if xfer_type:
            if xfer_type not in self._sent_bytes:
                self._sent_bytes[xfer_type] = 0
            self._sent_bytes[xfer_type] += num_bytes
        self._sent_bytes['total'] += num_bytes

    def _get_sent_bytes_stats(self):
        return self._sent_bytes.copy()
    sent_bytes_stats = property(_get_sent_bytes_stats)

    def rcvd_bytes(self, num_bytes, xfer_type=''):
        if xfer_type:
            if xfer_type not in self._rcvd_bytes:
                self._rcvd_bytes[xfer_type] = 0
            self._rcvd_bytes[xfer_type] += num_bytes
        self._rcvd_bytes['total'] += num_bytes

    def _get_rcvd_bytes_stats(self):
        return self._rcvd_bytes.copy()
    rcvd_bytes_stats = property(_get_rcvd_bytes_stats)


class CommunicationManager(object):

    def __init__(self, ip, port):
        self._ip = ip
        self._port = port
        self.stats = CommStats()

    def set_parameters(self, ip, port):
        self._ip = ip
        self._port = port

    def get_socket(self, ip=None, port=None):
        return GFASocket(ip or self._ip, port or self._port, build_header)

    def exec_std_command(self, command_packet):
        """
        Sends a command and receives an answer. No asynchronous answers

        :param command_packet:
        :return: CommandPacket
        """
        try:
            gfasocket = self.get_socket()
            start = datetime.datetime.utcnow()
            sent = gfasocket.send(command_packet.header, command_packet.payload)
            self.stats.sent_bytes(num_bytes=sent, xfer_type='{0}.{1}'.format(command_packet.module,
                                                                             command_packet.command))
            msg = f'Sent {sent} bytes to gfa. Module: {command_packet.module} - Command: {command_packet.command} - ' \
                  f'arguments: {command_packet.cmd_args}'
            log.debug(msg)
            # clog.debug(msg)
            # receive answer
            rcvd_header, rcvd_dataload, bytes_rcvdd = gfasocket.receive_packet()
            self.stats.rcvd_bytes(num_bytes=bytes_rcvdd, xfer_type='{0}.{1}'.format(command_packet.module,
                                                                                    command_packet.command))
            clog.debug(f"{msg} - Received {bytes_rcvdd} bytes as answer")
        except:
            msg = f'Failed to exec command {command_packet.module}.{command_packet.command}'
            log.exception(msg)
            clog.exception(msg)
            raise
        else:
            if rcvd_header.is_error():
                err = ErrorPackage.from_string(rcvd_dataload)
                log.error("Error received! type: {0} - message: {1}".format(err.error_type, err.message))
                raise Exception(err.message)
            c = CommandPacket.from_payload(header=rcvd_header, payload=rcvd_dataload)
            c.set_received_on()
            end = datetime.datetime.utcnow()
            c.set_elapsed(start, end)
            return c


class AsyncManager(object):
    def __init__(self, ip, async_port, auto_connect=False):
        self._ip = ip
        self._aport = async_port
        self.stats = CommStats()
        self._exit = False
        self._row_callbacks = []
        self._res_callbacks = []
        self._async_callbacks = {'new_img': [async_img_start_callback_log, ],
                                 'img_done': [async_img_done_callback_log, ],
                                 'telemetry': [async_telemetry_callback_log],
                                 'error': [async_error_callback_log],
                                 'sensors_reading': [async_sensors_reading_callback_log],
                                 'alarms': [async_alarms_callback_log],
                                 'pid': [async_pid_callback_log],
                                 }

        self._socket = None
        self._asyncs_q = None
        self._receive_asyncs_th = None
        self._process_async_th = None

        if auto_connect:
            self.connect()

    def set_parameters(self, ip, async_port):
        self._ip = ip
        self._aport = async_port

    def connect(self):
        if self._socket:
            log.warning("Already connected")
            return

        self._exit = False
        self._socket = GFASocket(self._ip, self._aport, build_header)
        self._socket.connect()
        self._socket.settimeout(1.0)

        self._asyncs_q = queue.Queue()

        self._receive_asyncs_th = threading.Thread(target=self.receive_asyncs)
        self._receive_asyncs_th.start()

        self._process_async_th = threading.Thread(target=self.process_asyncs)
        self._process_async_th.start()

    def _reconstruct_async_socket(self):
        self._socket = GFASocket(self._ip, self._aport, build_header)
        self._socket.connect()
        self._socket.settimeout(1.0)

    def receive_asyncs(self):
        while not self._exit:
            try:
                raw_payload = None
                raw_length = None
                header, data, bytes_recvd = self._socket.receive_packet()
                if isinstance(header, RawRowHeader):
                    raw_payload, raw_length = self._socket.receive(header.raw_bytes)
                    if header.raw_bytes != raw_length:
                        msg = f'Asked raw payload of {header.raw_bytes} bytes, received {raw_length}'
                        log.error(msg)
                        alog.error(msg)
            except socket.timeout:
                pass
            except Exception:
                log.exception("Exception waiting for asyncs, reconstructing async socket")
                alog.exception("Exception waiting for asyncs, reconstructing async socket")
                try:
                    self._reconstruct_async_socket()
                except:
                    log.exception("Exception when trying to reconstruct async socket. Stopping receive asyncs loop")
                    alog.exception("Exception when trying to reconstruct async socket. Stopping receive asyncs loop")
                    return
            else:
                if isinstance(header, RawRowHeader):
                    alog.debug(f'Async Row received: raw_bytes: {header.raw_bytes} - im_id: {header.image_id} - row_num: '
                               f'{header.row_number} - row_width: {header.row_width} - pixel_bytes: {header.pixel_bytes}')
                else:
                    alog.debug(f'Async {get_header_type_name(header)} received')
                self._asyncs_q.put((header, data, bytes_recvd, (raw_payload, raw_length)))

    def process_asyncs(self):
        while True:
            try:
                # raw = (raw_payload, raw_length)
                (header, data, bytes_recvd, raw) = self._asyncs_q.get(block=True, timeout=1.0)
            except queue.Empty:
                if self._exit:
                    return
            except Exception:
                log.exception("Unknown exception waiting for asyncs closing thread")
                # return
            else:
                self.process_async(header, data, bytes_recvd, raw)

    @staticmethod
    def _exec_registered_callbacks(callbacks, header, jsondata, raw=None):
        for cb in callbacks:
            try:
                if raw:
                    cb(header, jsondata, raw)
                else:
                    cb(header, jsondata)
            except Exception:
                log.exception("Exception when executing callback")

    def process_async(self, header, jsondata, bytes_recvd, raw):
        # raw = (raw_payload, raw_length)
        # log.info("Received async of type: {0}".format(type(header)))
        if isinstance(header, RawRowHeader):
            # payload, data_recv = self._socket.receive(header.raw_bytes)
            # log.info("Received rawrow payload: {0}/{1} bytes".format(data_recv, header.raw_bytes))
            # for cb in self._row_callbacks:
            #     cb(header, jsondata, raw[0])
            self._exec_registered_callbacks(self._row_callbacks, header, jsondata, raw[0])
            alog.debug(f"Executed {len(self._row_callbacks)} row callbacks for im.row: {header.image_id}."
                       f"{header.row_number}")

        elif isinstance(header, ResourcesHeader):
            log.debug('Received resources: {0}'.format(jsondata))
            # for cb in self._res_callbacks:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._res_callbacks, header, jsondata)
            alog.debug(f"Executed {len(self._res_callbacks)} resources callbacks.")

        elif isinstance(header, AsyncImageStartHeader):
            # for cb in self._async_callbacks['new_img']:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['new_img'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['new_img'])} imgstart callbacks")
        elif isinstance(header, AsyncImageDoneHeader):
            # for cb in self._async_callbacks['img_done']:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['img_done'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['img_done'])} imgdone callbacks")

        elif isinstance(header, AsyncTelemetryVoltages):
            # for cb in self._async_callbacks["telemetry"]:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['telemetry'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['telemetry'])} telemetry callbacks")

        elif isinstance(header, AsyncTelemetrySensors):
            # for cb in self._async_callbacks['sensors_reading']:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['sensors_reading'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['sensors_reading'])} sensors reading callbacks")

        elif isinstance(header, AsyncTelemetryAlarms):
            self._exec_registered_callbacks(self._async_callbacks['alarms'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['alarms'])} alarms callbacks")

        elif isinstance(header, AsyncPID):
            # for cb in self._async_callbacks['pid']:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['pid'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['pid'])} pid callbacks")

        elif isinstance(header, ErrorPacket):
            # for cb in self._async_callbacks['error']:
            #     cb(header, jsondata)
            self._exec_registered_callbacks(self._async_callbacks['error'], header, jsondata)
            alog.debug(f"Executed {len(self._async_callbacks['error'])} error callbacks")

    def add_row_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata, raw_data
        """
        self._row_callbacks.append(callback)

    def add_resources_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """
        self._res_callbacks.append(callback)

    def add_new_image_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks['new_img'].append(callback)

    def add_end_image_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks['img_done'].append(callback)

    def add_sensors_reading_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks['sensors_reading'].append(callback)

    def add_alarms_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks["alarms"].append(callback)

    def add_telemetry_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks["telemetry"].append(callback)

    def add_pid_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks['pid'].append(callback)

    def add_error_callback(self, callback):
        """
        Callback calling arguments will be header, jsondata
        """

        self._async_callbacks['error'].append(callback)

    def close(self):
        if not self._socket:
            log.warning("Not connected")
            return

        self._exit = True

        if self._receive_asyncs_th:
            log.info('Joining receive async thread')
            self._receive_asyncs_th.join()
            log.info('Received async thread joined')

        self._socket.close()
        self._socket = None

        if self._process_async_th:
            log.info('Joining process async thread')
            self._process_async_th.join()
            log.info('Process async thread joined')


def resources_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA Resources - vm: {0}KB - rss: {1}KB'.format(j['vm'], j['rss']))


def async_img_start_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - acquisition started for image_id: {0}'.format(j['image_id']))


def async_img_done_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - acquisition done for image_id: {0}'.format(j['image_id']))


def async_sensors_reading_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - sensors reading received')


def async_alarms_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - alarms received')


def async_telemetry_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - telemetry received')


def async_pid_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - pid received')


def async_error_callback_log(header, jsondata):
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)
    log.info('GFA - error with msg: {0}'.format(j['msg']))
