#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

import cmd
import os
import pickle

import numpy as np
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter

from threading import Thread
import subprocess


class TestExplorerShell(cmd.Cmd):
    intro = 'Welcome to the turtle shell.   Type help or ? to list commands.\n'
    file = None

    def __init__(self, completekey='tab', stdin=None, stdout=None):
        super().__init__(completekey, stdin, stdout)
        self.prompt = 'explorer > '
        self._base_path = os.path.dirname(os.path.abspath(__file__))
        self._work_dir = None
        self._data_file = None

    def emptyline(self):
        pass

    def do_select_folder(self, arg):
        full_path = os.path.join(self._base_path, arg.strip())
        if os.path.exists(full_path):
            dfp = os.path.join(full_path, 'noise_levels.csv')
            if os.path.exists(dfp):
                self._work_dir = full_path
                print("Working folder: {}".format(full_path))
                self._data_file = dfp
                print("\tCurrent data file: {}".format(self._data_file))
                self.prompt = 'explorer - {} > '.format(full_path.split(os.path.sep)[-1])
            else:
                print('Data file not found at {}'.format(full_path))
                print('tCurrent working directory: {}'.format(self._work_dir))
                print('\tCurrent data file: {}'.format(self._data_file))
        else:
            print("Folder not found.\n\tCurrent working directory: {}".format(self._work_dir))
            print("\tCurrent data file: {}".format(self._data_file))

    def complete_select_folder(self, text, line, begidx, endidx):
        folders = [f.name for f in os.scandir(self._base_path) if f.is_dir()]
        if not text:
            completions = folders
        else:
            completions = [f
                           for f in folders
                           if f.startswith(text)
                           ]
        return completions

    def _filter_by_threshold(self, array, threshold, check_first_column=False):
        if threshold:
            tmp = []
            try:
                if check_first_column:
                    for line in array:
                        if max([float(x) for x in line]) > threshold:
                            tmp.append(line)
                else:
                    for line in array:
                        if max([float(x) for x in line[1:]]) > threshold:
                            tmp.append(line)

            except ValueError:
                print("Failed to parse file, non value found")
            return tmp
        return array

    def _filter_prescan(self, threshold=0, amplifier=0):
        if amplifier == 0:
            with open(self._data_file, 'r') as df:
                filtered_rows = [line.split(',')[:5] for line in df.readlines() if not line.startswith('#')]
            total_images = len(filtered_rows)
            return self._filter_by_threshold(filtered_rows, threshold, check_first_column=False), total_images
        if amplifier in (1, 2, 3, 4):
            print('amplifier: ', amplifier, type(amplifier))
            with open(self._data_file, 'r') as df:
                filtered_rows = [line.split(',')[amplifier:amplifier + 1] for line in df.readlines() if
                                 not line.startswith('#')]
            total_images = len(filtered_rows)
            return self._filter_by_threshold(filtered_rows, threshold, check_first_column=True), total_images

    def do_list_by_prescan_threshold(self, arg):
        """Lists all adc sync that have a prescan standard deviation above a value.
        list_by_prescan_threshold
        list_by_prescan_threshold <threshold>
        list_by_prescan_threshold <threshold> <num_events>
        """
        argsplit = arg.split()
        threshold = False
        limit_ev = None
        if len(argsplit) > 2:
            print("this command only accepts 2 arguments")
            return
        if len(argsplit) == 2:
            try:
                threshold = float(argsplit[0])
                limit_ev = int(argsplit[1])
            except ValueError:
                print("arguments must be number for threshold and integer for limit")
        elif len(argsplit) == 1:
            try:
                threshold = float(arg)
            except ValueError:
                print("Argument must be empty to show all results or a number to filter by prescan values")
                return
        filtered_rows, _ = self._filter_prescan(threshold)
        if limit_ev:
            filtered_rows = filtered_rows[:limit_ev]
        for line in filtered_rows:
            print(', '.join(line))

    def do_count_by_prescan_threshold(self, arg):
        """arg should be a threshold to show values by prescan noise in amplifiers. It can also set to use only one amplifier:
        count_by_prescan_threshold <threshold>
        count_by_prescan_threshold <threshold> <amplifier_num>
        Where <amplifier_num> is 0 for all amplifiers and 1,2,3,4 for each one of the amps of the ccd"""
        err_msg = "count_by_prescan_threshold <threshold> <amplifier_num>"
        threshold = 0
        amplifier = 0
        arg = arg.split()
        if len(arg) > 2:
            print(err_msg)
            return
        if len(arg) in [1, 2]:
            try:
                threshold = float(arg[0])
            except ValueError:
                print(err_msg)
        if len(arg) == 2:
            try:
                amplifier = int(arg[1])
            except ValueError:
                print(err_msg)

        filtered_rows, total = self._filter_prescan(threshold, amplifier)
        if amplifier == 0:
            print("There are {}/{} images with prescan std over {} at least in an amp".format(len(filtered_rows), total,
                                                                                              threshold))
            return
        print("There are {}/{} images with prescan std over {} at amplifier {}".format(len(filtered_rows), total,
                                                                                       threshold, amplifier))

    def do_stats_threshold(self, arg):
        """Returns how many events have noise above the threshold
        stats <overscan|prescan|both> <threshold>
        """

        def calc_and_print(events):

            if events.shape[1] == 5:
                mask_amp1_below = events[:, 1] < threshold
                mask_amp1_above = events[:, 1] > threshold
                mask_amp2_below = events[:, 2] < threshold
                mask_amp2_above = events[:, 2] > threshold
                mask_amp3_below = events[:, 3] < threshold
                mask_amp3_above = events[:, 3] > threshold
                mask_amp4_below = events[:, 4] < threshold
                mask_amp4_above = events[:, 4] > threshold

            elif events.shape[1] == 9:
                mask_amp1_below = (events[:, 1] < threshold) & (events[:, 5] < threshold)
                mask_amp1_above = (events[:, 1] > threshold) & (events[:, 5] > threshold)
                mask_amp2_below = (events[:, 2] < threshold) & (events[:, 6] < threshold)
                mask_amp2_above = (events[:, 2] > threshold) & (events[:, 6] > threshold)
                mask_amp3_below = (events[:, 3] < threshold) & (events[:, 7] < threshold)
                mask_amp3_above = (events[:, 3] > threshold) & (events[:, 7] > threshold)
                mask_amp4_below = (events[:, 4] < threshold) & (events[:, 8] < threshold)
                mask_amp4_above = (events[:, 4] > threshold) & (events[:, 8] > threshold)
            else:
                print("wrong shape: {}".format(events.shape))
                return
            all_below_cond = mask_amp1_below & mask_amp2_below & mask_amp3_below & mask_amp4_below

            all_above_cond = mask_amp1_above & mask_amp2_above & mask_amp3_above & mask_amp4_above
            one_amp_below = (mask_amp1_below & mask_amp2_above & mask_amp3_above & mask_amp4_above) | \
                            (mask_amp1_above & mask_amp2_below & mask_amp3_above & mask_amp4_above) | \
                            (mask_amp1_above & mask_amp2_above & mask_amp3_below & mask_amp4_above) | \
                            (mask_amp1_above & mask_amp2_above & mask_amp3_above & mask_amp4_below)

            all_below = events[all_below_cond]
            allAmpAbove = events[all_above_cond]
            oneAmpBelow = events[one_amp_below]

            twoAmpBelow = events[(mask_amp1_below & mask_amp2_below & mask_amp3_above & mask_amp4_above) |
                                 (mask_amp1_below & mask_amp2_above & mask_amp3_below & mask_amp4_above) |
                                 (mask_amp1_below & mask_amp2_above & mask_amp3_above & mask_amp4_below) |
                                 # 2
                                 (mask_amp1_above & mask_amp2_below & mask_amp3_below & mask_amp4_above) |
                                 (mask_amp1_above & mask_amp2_below & mask_amp3_above & mask_amp4_below) |
                                 # 3
                                 (mask_amp1_above & mask_amp2_above & mask_amp3_below & mask_amp4_below)
                                 ]
            threeAmpBelow = events[(mask_amp1_above & mask_amp2_below & mask_amp3_below & mask_amp4_below) |
                                   (mask_amp1_below & mask_amp2_above & mask_amp3_below & mask_amp4_below) |
                                   (mask_amp1_below & mask_amp2_below & mask_amp3_above & mask_amp4_below) |
                                   (mask_amp1_below & mask_amp2_below & mask_amp3_below & mask_amp4_above)
                                   ]

            print("Num of events where all amps below th: {}".format(len(all_below)))
            print("Num of events where only one amp below th: {}".format(len(oneAmpBelow)))
            print("Num of events where two amps below th: {}".format(len(twoAmpBelow)))
            print("Num of events where three amps below th: {}".format(len(threeAmpBelow)))
            print("Num of events where no amp below th: {}".format(len(allAmpAbove)))
            return twoAmpBelow

        args = arg.split()
        if len(args) != 2:
            print('Command need two arguments: \'stats <overscan|prescan|both> <threshold>\'')
        try:
            threshold = float(args[1])
        except ValueError:
            print("Argument for threshold must be a number. args provided: {}".format(args))
            return
        area_type = args[0].strip()
        if area_type not in ['prescan', 'overscan', 'both']:
            print("Argument for area type must be one of 'prescan', 'overscan' or 'both'")
            return
        if area_type == 'prescan':
            ev, total = self._filter_prescan()
            print("Results for Prescan values:")
        elif area_type == 'overscan':
            ev, total = self._filter_overscan()
            print("Results for Overscan values:")
        elif area_type == 'both':
            ev, total = self._filter_pre_over()
        ev = np.array(ev).astype(float)
        calc_and_print(ev)

    def _filter_overscan(self, threshold=0, amplifier=0):
        if amplifier == 0:
            with open(self._data_file, 'r') as df:
                filtered_rows = [line for line in df.readlines() if not line.startswith('#')]
                filtered_rows = [[y for i, y in enumerate(x.split(',')) if i in (0, 5, 6, 7, 8)] for x in filtered_rows]
            total_images = len(filtered_rows)
            return self._filter_by_threshold(filtered_rows, threshold, check_first_column=False), total_images
        if amplifier in (1, 2, 3, 4):
            print('amplifier: ', amplifier, type(amplifier))
            with open(self._data_file, 'r') as df:
                filtered_rows = [line.split(',')[amplifier + 4:amplifier + 5] for line in df.readlines() if
                                 not line.startswith('#')]
            total_images = len(filtered_rows)
            return self._filter_by_threshold(filtered_rows, threshold, check_first_column=True), total_images

    def _filter_pre_over(self):
        with open(self._data_file, 'r') as df:
            filtered_rows = [line.split(',')[:9] for line in df.readlines() if not line.startswith('#')]
        total_images = len(filtered_rows)
        return filtered_rows, total_images

    def do_list_by_overscan_threshold(self, arg):
        """Lists all adc sync that have an overscan standard deviation above a value.
        list_by_overscan_threshold
        list_by_overscan_threshold <threshold>
        list_by_overscan_threshold <threshold> <limit_events>
        """
        argsplit = arg.split()
        threshold = False
        limit_ev = None
        if len(argsplit) > 2:
            print("this command only accepts 2 arguments")
            return
        if len(argsplit) == 2:
            try:
                threshold = float(argsplit[0])
                limit_ev = int(argsplit[1])
            except ValueError:
                print("arguments must be number for threshold and integer for limit")
        elif len(argsplit) == 1:
            try:
                threshold = float(arg)
            except ValueError:
                print("Argument must be empty to show all results or a number to filter by prescan values")
                return
        filtered_rows, _ = self._filter_overscan(threshold)
        if limit_ev:
            filtered_rows = filtered_rows[:limit_ev]
        for line in filtered_rows:
            print(line)

    def do_count_by_overscan_threshold(self, arg):
        """arg should be a threshold to show values by prescan noise in amplifiers"""
        threshold = 0
        if arg:
            try:
                threshold = float(arg)
            except ValueError:
                print("Argument must be empty to show all results or a number to filter by prescan values")
                return

        filtered_rows, total = self._filter_overscan(threshold)
        print("There are {}/{} images with overscan std over {} at least in an amp".format(len(filtered_rows), total,
                                                                                           threshold))

    def do_show_waveform(self, arg):
        ## get_image

        if arg.strip().endswith('_waveform.pickle'):
            pickle_path = os.path.join(self._work_dir, 'images', arg.strip())
            if os.path.exists(pickle_path):
                print("Loading pickle: {}".format(pickle_path))
                with open(pickle_path, 'rb') as pickle_file:
                    image = pickle.load(pickle_file)
                gq = GUIQWTPlotter(image)
                Thread(target=gq.show_as_waveform, kwargs={'max_lines': 30}, daemon=True).start()

            else:
                print("File not found: {}".format(pickle_path))
        else:
            print("Not  valid file. Valid files are ended in _waveform.pickle")

    def complete_show_waveform(self, text, line, begidx, endidx):
        images_path = os.path.join(self._work_dir, 'images')
        # print(images_path)
        files = [f.name for f in os.scandir(images_path) if f.name.endswith('_waveform.pickle')]
        # print(files)
        if not text:
            completions = files
        else:
            completions = [f
                           for f in files
                           if f.startswith(text)
                           ]
        return completions

    def do_show_image(self, arg):
        ## get_image

        if arg.strip().endswith('_image.pickle'):
            pickle_path = os.path.join(self._work_dir, 'images', arg.strip())
            if os.path.exists(pickle_path):
                print("Loading pickle: {}".format(pickle_path))
                with open(pickle_path, 'rb') as pickle_file:
                    image = pickle.load(pickle_file)
                gq = GUIQWTPlotter(image)
                Thread(target=gq.show_amplifiers, daemon=True).start()
                # tmp = subprocess.run(['python', 'show_im.py', pickle_path], shell=True)
            else:
                print("File not found: {}".format(pickle_path))
        else:
            print("Not  valid file. Valid files are ended in _waveform.pickle")

    def complete_show_image(self, text, line, begidx, endidx):
        images_path = os.path.join(self._work_dir, 'images')
        # print(images_path)
        files = [f.name for f in os.scandir(images_path) if f.name.endswith('_image.pickle')]
        # print(files)
        if not text:
            completions = files
        else:
            completions = [f
                           for f in files
                           if f.startswith(text)
                           ]
        return completions

    def do_bye(self, arg):
        return self.do_exit(None)

    def do_exit(self, arg):
        print('Thank you for using noise explorer shell')
        self.close()
        return True

    def close(self):
        if self.file:
            self.file.close()
            self.file = None


if __name__ == "__main__":
    import sys

    t = TestExplorerShell()
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        t.do_select_folder(arg)
    t.cmdloop()
