#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log as gfaliblog
from gfafunctionality.raws import RawImageFile
import json
import numpy as np
import sys
import os
import time, datetime
import pickle


import logging
import logging.handlers

log = logging.getLogger('adc_sync_noise')
log.setLevel(logging.DEBUG)

nh = logging.NullHandler()
log.addHandler(nh)

IP_DEFAULT = '172.16.17.82'
PORT = 32000
APORT = 32001


if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


POWERDOWN_TIME_STEP_MS = 250
POWERUP_TIME_STEP_MS = 250


class AdcSyncNoise(object):
    def __init__(self, ip=IP, file_path='default'):
        self.ip = IP
        self.gfa = None
        self.acq_lock = GFAExposureLock()

        if file_path == 'default':
            now = datetime.datetime.utcnow()
            self.file_path = './{}'.format(now.strftime("%Y%m%d%H%M%S"))
        else:
            self.file_path = file_path

        self.images_path = os.path.join(self.file_path, 'images')
        self.data_file_path = os.path.join(self.file_path, 'noise_levels.csv')
        self.meta = {
            'prescan_cols': 50,
            'overscan_cols': 50,
            'amplifier_active_cols': 1024
        }
        self._steps = 0
        self._noisy = {'prescan':0, 'overscan': 0, 'active_rows': 0, 'active_cols': 0}

    def log_add_file_handler(self, log_pointer, file_name=None, level=logging.DEBUG):
        # global log
        # global formatter
        file_path = os.path.join(self.file_path, file_name)
        fh = logging.FileHandler(filename=file_path)
        fh.setLevel(level=level)
        # create formatter and add it to the handlers
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        log_pointer.addHandler(fh)

    def create_logs(self):
        # There are 2 logs, the one of the script and the one of the library
        # library
        self.log_add_file_handler(gfaliblog, 'gfaaccesslib.log')
        # script
        self.log_add_file_handler(log, 'adc_sync_noise_test.log')

    def create_data_file_header(self):
        with open(self.data_file_path, 'a') as f:
            now = datetime.datetime.utcnow()
            versions = {'api': 'NA',
                        'fw_version': 'NA',
                        'gfa_mac': 'NA'}
            if self.gfa:
                versions['api'] = self.gfa.sys.remote_api().answer
                versions['fw_version'] = self.gfa.sys.remote_version().answer
                versions['gfa_mac'] = self.gfa.sys.remote_mac().answer

            tmp = [
                "## ADC Synchronize Noise Test\n",
                "## Started on: {}\n".format(now.strftime("%d/%m/%Y %H:%M:%S")),
                '## GFA API: {}\n'.format(versions['api']),
                '## GFA FW versions: {}\n'.format(versions['fw_version']),
                '## GFA MAC address: {}\n'.format(versions['gfa_mac']),
                "# img_id, {}, {}, {}, {}, {}, {}, {}, {}\n".format(
                    ','.join(["prescan_{}_std".format(x) for x in range(4)]),
                    ','.join(['overscan_{}_std'.format(x) for x in range(4)]),
                    ','.join(['active_10x100_{}_std'.format(x) for x in range(4)]),
                    ','.join(['active_100x10_{}_std'.format(x) for x in range(4)]),
                    ','.join(["prescan_{}_avg".format(x) for x in range(4)]),
                    ','.join(['overscan_{}_avg'.format(x) for x in range(4)]),
                    ','.join(['active_10x100_{}_avg'.format(x) for x in range(4)]),
                    ','.join(['active_100x10_{}_avg'.format(x) for x in range(4)])
            )]
            f.writelines(tmp)

    def make_paths(self):
        os.makedirs(self.file_path, exist_ok=True)
        os.makedirs(self.images_path, exist_ok=True)
        log.info("Created paths: {}, {}".format(self.file_path, self.images_path))

    def connect(self):
        log.info('Connecting to {}:{}:{}'.format(self.ip, PORT, APORT))
        self.gfa = GFA(self.ip, PORT, APORT)
        self.gfa.async_manager.add_end_image_callback(self.acq_lock.async_callback_release)
        self.gfa.async_manager.add_new_image_callback(self.image_start_cb)

    def configure_default(self):
        self.gfa.clockmanager.remote_set_ccd_geom()
        self.gfa.clockmanager.remote_set_clock_timings()
        self.gfa.powercontroller.remote_set_dac_conf()
        self.gfa.powercontroller.voltages.set_default_values()
        self.gfa.powercontroller.remote_set_voltages()
        self.gfa.powercontroller.powerup_timing_ms = POWERUP_TIME_STEP_MS
        self.gfa.powercontroller.powerdown_timing_ms = POWERDOWN_TIME_STEP_MS
        self.gfa.powercontroller.remote_set_phase_timing()
        log.info("Configured default values to gfa")

    def power_up(self):
        log.info("power up gfa")
        self.gfa.exposecontroller.remote_power_up()
        itr = 0
        while self.gfa.exposecontroller.status.ready_state is False:
            if itr > 10:
                self.gfa.powercontroller.remote_get_configured_channels()
                print(self.gfa.powercontroller.dac_channels)
                raise Exception("gfa should be in ready state")
            log.info(self.gfa.exposecontroller.status)
            time.sleep(0.4)
            self.gfa.exposecontroller.remote_get_status()
            itr += 1

    def power_down(self):
        log.info("power down gfa")
        self.gfa.powercontroller.powerdown_timing_ms = POWERDOWN_TIME_STEP_MS
        self.gfa.powercontroller.remote_set_phase_timing()

        self.gfa.exposecontroller.remote_power_down()
        time.sleep(4 * POWERDOWN_TIME_STEP_MS / 1000)

        self.gfa.exposecontroller.remote_get_status()
        log.info(self.gfa.exposecontroller.status)

        self.gfa.powercontroller.remote_get_enables()
        log.info(self.gfa.powercontroller.enables)

    def sync_adc(self):
        self.gfa.adccontroller.set_adc_reset_pin(0)
        self.gfa.adccontroller.set_adc_reset_pin(1)
        self.gfa.adccontroller.set_adc_powerdown_pin(False)
        self.gfa.adccontroller.reset_adc_controller()

        self.gfa.adccontroller.adc_init_calib()
        self.gfa.adccontroller.remote_get_status()
        if self.gfa.adccontroller.status.init_status.state != 's_init':
            raise Exception('System should be at calibration')

        # reset adc chip by spi
        self.gfa.adccontroller.spi_write(0x0, 0x1)
        time.sleep(0.1)
        self.gfa.adccontroller.spi_write(0x0, 0x0)
        time.sleep(0.1)

        # configure serialization on adc
        self.gfa.adccontroller.spi_write(0x46, 0x8801)

        # set expected data pattern
        self.gfa.adccontroller.remote_set_init_rx_expected_pattern(0xf0f0)

        # set adc to output sync pattern
        time.sleep(0.1)
        self.gfa.adccontroller.spi_write(0x45, 0x2)

        # start align frame
        self.gfa.adccontroller.adc_calib_align_frame()

        # check it has finished aligning frame
        for i in range(10):
            self.gfa.adccontroller.remote_get_status()
            if self.gfa.adccontroller.status.init_status.frame_aligned:
                break
        else:
            raise Exception('Frame could not be aligned')

        # align data
        self.gfa.adccontroller.adc_calib_align_data()

        # check it has finished aligning frame
        # for i in range(10):
        #     gfa.adccontroller.remote_get_status()
        #     if gfa.adccontroller.status.init_status.frame_aligned:
        #         break
        # else:
        #     raise Exception('Frame could not be aligned')

        # gfa.adccontroller.remote_get_status()
        # gfa.adccontroller.remote_get_init_rx_expected_pattern()
        # gfa.adccontroller.remote_get_init_rx_data()
        # print gfa.adccontroller.status

        self.gfa.adccontroller.adc_calib_bitslip()

        self.gfa.adccontroller.remote_get_status()
        self.gfa.adccontroller.remote_get_init_rx_expected_pattern()
        self.gfa.adccontroller.remote_get_init_rx_data()
        # print(self.gfa.adccontroller.status)

        # remove pattern
        self.gfa.adccontroller.spi_write(0x45, 0x0)

        self.gfa.adccontroller.adc_stop_calib()

    def image_start_cb(self, header, jsondata):
        if isinstance(jsondata, bytes):
            jsondata = jsondata.decode('UTF-8')
        j = json.loads(jsondata)

        self.meta['prescan_cols'] = j['prescan_cols']
        self.meta['overscan_cols'] = j['overscan_cols']
        self.meta['amplifier_active_cols'] = j['amplifier_active_cols']

    def acq_active_area(self, exp_time=0, storage_rows=512, active_rows=512):
        """
        Sequence to acquire active area and dump storage
        """
        self.gfa.adccontroller.spi_write(0xf, 0x0)
        self.gfa.adccontroller.spi_write(0x2a, 0x0)
        self.gfa.adccontroller.adc_start_acq()
        g = self.gfa.clockmanager.stack

        g.clear()
        g.add_new_image_cmd()
        g.add_set_modes_cmd(True, True, True, True)
        # Clear CCD
        g.add_dump_rows_cmd(1024)
        g.add_wait_cmd(exp_time)
        g.add_dump_rows_cmd(storage_rows)
        g.add_read_rows_cmd(active_rows)
        g.add_none_cmd()
        self.gfa.clockmanager.remote_set_stack_contents()
        self.gfa.buffers.remote_set_data_provider(0, 0)

        self.acq_lock.acquire()
        self.gfa.exposecontroller.remote_start_stack_exec()

        self.acq_lock.acquire()
        self.acq_lock.release()

    def acq_waveform(self, exp_time=0, dump_rows=512, read_rows=5):
        """
        Sequence to acquire active area and dump storage
        """
        self.gfa.adccontroller.spi_write(0xf, 0x0)
        self.gfa.adccontroller.spi_write(0x2a, 0x0)
        self.gfa.adccontroller.adc_start_acq()
        g = self.gfa.clockmanager.stack

        g.clear()
        g.add_new_image_cmd()
        g.add_set_modes_cmd(True, True, True, True)
        # Clear CCD
        g.add_dump_rows_cmd(1024)
        g.add_wait_cmd(exp_time)
        g.add_dump_rows_cmd(dump_rows)
        g.add_set_roi_conf_cmd(skip_columns=150, roi_width=30)
        g.add_read_rows_roi_and_overscan_cmd(read_rows)
        g.add_none_cmd()
        self.gfa.clockmanager.remote_set_stack_contents()
        self.gfa.buffers.remote_set_data_provider(0, 4)

        self.acq_lock.acquire()
        self.gfa.exposecontroller.remote_start_stack_exec()

        self.acq_lock.acquire()
        self.acq_lock.release()

    def save_im(self, step_id, img, type_im='waveform'):
        """
        save a pickle of the image data
        :param img: the image to  dump as a pickle
        :param type_im: one of ['waveform', 'image']
        :return:
        """

        with open(os.path.join(self.images_path, '{:04}_{}.pickle'.format(step_id, type_im)), 'wb') as pickle_file:
            pickle.dump(img, pickle_file)

    def save_analysis_data(self, step_id, img, noise_level=50):
        # overscan_noises = img.get_ampdata_overscan_std()
        # overscan_avg = img.get_ampdata_overscan_avg()
        # prescan_noises = img.get_ampdata_prescan_std()
        # prescan_avg = img.get_ampdata_prescan_avg()
        #
        # active_10x100_avg = img.get_ampdata_avg(10, 100, 100, 110)
        # active_10x100_noise = img.get_ampdata_std(10, 100, 100, 110)
        # active_100x10_avg = img.get_ampdata_avg(100, 110, 10, 100)
        # active_100x10_noise = img.get_ampdata_std(100, 110, 10, 100)
        noisy = False
        self._steps += 1
        tmp = [step_id]

        a = img.get_ampdata_prescan_std(self.meta['prescan_cols'], 10)
        if max(a) > noise_level:
            self._noisy['prescan'] += 1
            noisy = True
        tmp.extend(a)

        a = img.get_ampdata_overscan_std(self.meta['overscan_cols'], 10)
        if max(a) > noise_level:
            self._noisy['overscan'] += 1
            noisy = True
        tmp.extend(a)

        a = img.get_ampdata_std(200, 300, 200, 210)
        if max(a) > noise_level:
            self._noisy['active_cols'] += 1
        tmp.extend(a)

        a = img.get_ampdata_std(200, 210, 200, 300)
        if max(a) > noise_level:
            self._noisy['active_rows'] += 1
        tmp.extend(a)

        tmp.extend(img.get_ampdata_prescan_avg(self.meta['prescan_cols'], 10))
        tmp.extend(img.get_ampdata_overscan_avg(self.meta['overscan_cols'], 10))
        tmp.extend(img.get_ampdata_avg(200, 300, 200, 210))
        tmp.extend(img.get_ampdata_avg(200, 210, 200, 300))

        try:
            with open(self.data_file_path, 'a') as data_file:
                data_file.write("{}\n".format(','.join([str(x) for x in tmp])))
                log.info("{}\n".format(', '.join([str(x) for x in tmp])))
        except:
            log.exception("Failed to save data to file")

        return noisy

    def step(self, step_id, noise_level_threshold=50, save_all=False):
        log.info("{:04} - Syncing adc".format(step_id))
        self.sync_adc()
        time.sleep(0.5)
        log.info("Acq active area")
        self.acq_active_area()
        im_num = sorted(self.gfa.raws.list_images())[-1]
        img = self.gfa.raws.get_image(im_num)
        noisy = self.save_analysis_data(step_id=step_id, img=img, noise_level=noise_level_threshold)
        time.sleep(1)
        if noisy or save_all:
            log.info("Acquiring waveform and saving files")
            self.save_im(step_id, img, type_im='image')
            self.acq_waveform()
            wave_num = sorted(self.gfa.raws.list_images())[-1]
            wave = self.gfa.raws.get_image(wave_num)
            self.save_im(step_id, wave, type_im='waveform')
            self.gfa.raws.rem_image(wave_num)
        self.gfa.raws.rem_image(im_num)

    def loop(self, num=1000, noise_level_threshold=10, save_all=False):
        self.make_paths()
        self.create_logs()
        self.connect()
        self.create_data_file_header()
        self.configure_default()
        self.power_up()
        for i in range(num):
            try:
                self.step(step_id=i, noise_level_threshold=noise_level_threshold, save_all=save_all)
            except Exception as ex:
                log.exception("Error while looping")
        self.power_down()
        log.info("Done {} adc synchronizations.\nprescan: {} - overscan: {} \
        - active_cols: {} - active_rows: {}".format(self._steps, self._noisy['prescan'],
                                                    self._noisy['overscan'],
                                                    self._noisy['active_cols'],
                                                    self._noisy['active_rows']))
        self.gfa.close()


if __name__ == "__main__":

    from gfaaccesslib.logger import formatter
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    log.addHandler(ch)

    asn = AdcSyncNoise()
    asn.loop(1000, save_all=False)