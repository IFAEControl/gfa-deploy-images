from plotly.subplots import make_subplots
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

import os
# img_id, prescan_0_std,prescan_1_std,prescan_2_std,prescan_3_std, overscan_0_std,overscan_1_std,overscan_2_std,overscan_3_std, active_10x100_0_std,active_10x100_1_std,active_10x100_2_std,active_10x100_3_std, active_100x10_0_std,active_100x10_1_std,active_100x10_2_std,active_100x10_3_std, prescan_0_avg,prescan_1_avg,prescan_2_avg,prescan_3_avg, overscan_0_avg,overscan_1_avg,overscan_2_avg,overscan_3_avg, active_10x100_0_avg,active_10x100_1_avg,active_10x100_2_avg,active_10x100_3_avg, active_100x10_0_avg,active_100x10_1_avg,active_100x10_2_avg,active_100x10_3_avg

set_name = '20200311141738'
THRESHOLD = 10
MID_THRESHOLD = 2500

data = []
with open(os.path.abspath('./{}/noise_levels.csv'.format(set_name))) as df:
    for line in df:
        if not line.startswith('#'):
            data.append([float(x) for x in line.split(',')])
data = np.array(data)
#print(data[:, 1:2].shape)
prescan1 = data[:, 1:2].ravel()
prescan2 = data[:, 2:3].ravel()
prescan3 = data[:, 3:4].ravel()
prescan4 = data[:, 4:5].ravel()

overscan1 = data[:, 5:6].ravel()
overscan2 = data[:, 6:7].ravel()
overscan3 = data[:, 7:8].ravel()
overscan4 = data[:, 8:9].ravel()

def show_histograms(amp1, amp2, amp3, amp4, title_text):
    fig_titles = (amp1[1], amp2[1], amp3[1], amp4[1])
    fig = make_subplots(1, 4, subplot_titles=fig_titles)
    fig.add_trace(go.Histogram(x=amp1[0]), 1, 1)
    fig.add_trace(go.Histogram(x=amp2[0]), 1, 2)
    fig.add_trace(go.Histogram(x=amp3[0]), 1, 3)
    fig.add_trace(go.Histogram(x=amp4[0]), 1, 4)
    fig.update_layout(title_text=title_text,
                      showlegend=False)
    fig.show()


show_histograms((prescan1, 'Prescan Amp 1'),
                (prescan2, 'Prescan Amp 2'),
                (prescan3, 'Prescan Amp 3'),
                (prescan4, 'Prescan Amp 4'),
                title_text='Set {} - Prescan std'.format(set_name))


show_histograms((prescan1[prescan1 < THRESHOLD], 'Prescan Amp 1 < {}'.format(THRESHOLD)),
                (prescan2[prescan2 < THRESHOLD], 'Prescan Amp 2 < {}'.format(THRESHOLD)),
                (prescan3[prescan3 < THRESHOLD], 'Prescan Amp 3 < {}'.format(THRESHOLD)),
                (prescan4[prescan4 < THRESHOLD], 'Prescan Amp 4 < {}'.format(THRESHOLD)),
                title_text='Set {} - Prescan std (Values < {})'.format(set_name, THRESHOLD))

show_histograms((prescan1[(prescan1 > THRESHOLD) & (prescan1 < MID_THRESHOLD)], '{} < Prescan Amp 1 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (prescan2[(prescan2 > THRESHOLD) & (prescan2 < MID_THRESHOLD)], '{} < Prescan Amp 2 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (prescan3[(prescan3 > THRESHOLD) & (prescan3 < MID_THRESHOLD)], '{} < Prescan Amp 3 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (prescan4[(prescan4 > THRESHOLD) & (prescan4 < MID_THRESHOLD)], '{} < Prescan Amp 4 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                title_text='Set {} - Prescan std ({} < Values < {})'.format(set_name, THRESHOLD, MID_THRESHOLD))

show_histograms((prescan1[prescan1 > MID_THRESHOLD], 'Prescan Amp 1 > {}'.format(MID_THRESHOLD)),
                (prescan2[prescan2 > MID_THRESHOLD], 'Prescan Amp 2 > {}'.format(MID_THRESHOLD)),
                (prescan3[prescan3 > MID_THRESHOLD], 'Prescan Amp 3 > {}'.format(MID_THRESHOLD)),
                (prescan4[prescan4 > MID_THRESHOLD], 'Prescan Amp 4 > {}'.format(MID_THRESHOLD)),
                title_text='Set {} - Prescan std (Values > {})'.format(set_name, MID_THRESHOLD))


## Overscan
show_histograms((overscan1, 'Overscan Amp 1'),
                (overscan2, 'Overscan Amp 2'),
                (overscan3, 'Overscan Amp 3'),
                (overscan4, 'Overscan Amp 4'),
                title_text='Set {} - Overscan std'.format(set_name))


show_histograms((overscan1[overscan1 < THRESHOLD], 'Overscan Amp 1 < {}'.format(THRESHOLD)),
                (overscan2[overscan2 < THRESHOLD], 'Overscan Amp 2 < {}'.format(THRESHOLD)),
                (overscan3[overscan3 < THRESHOLD], 'Overscan Amp 3 < {}'.format(THRESHOLD)),
                (overscan4[overscan4 < THRESHOLD], 'Overscan Amp 4 < {}'.format(THRESHOLD)),
                title_text='Set {} - Overscan std (Values < {})'.format(set_name, THRESHOLD))

show_histograms((overscan1[(overscan1 > THRESHOLD) & (overscan1 < MID_THRESHOLD)], '{} < Overscan Amp 1 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (overscan2[(overscan2 > THRESHOLD) & (overscan2 < MID_THRESHOLD)], '{} < Overscan Amp 2 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (overscan3[(overscan3 > THRESHOLD) & (overscan3 < MID_THRESHOLD)], '{} < Overscan Amp 3 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                (overscan4[(overscan4 > THRESHOLD) & (overscan4 < MID_THRESHOLD)], '{} < Overscan Amp 4 < {}'.format(THRESHOLD, MID_THRESHOLD)),
                title_text='Set {} - Overscan std ({} < Values < {})'.format(set_name, THRESHOLD, MID_THRESHOLD))

show_histograms((overscan1[overscan1 > MID_THRESHOLD], 'Overscan Amp 1 > {}'.format(MID_THRESHOLD)),
                (overscan2[overscan2 > MID_THRESHOLD], 'Overscan Amp 2 > {}'.format(MID_THRESHOLD)),
                (overscan3[overscan3 > MID_THRESHOLD], 'Overscan Amp 3 > {}'.format(MID_THRESHOLD)),
                (overscan4[overscan4 > MID_THRESHOLD], 'Overscan Amp 4 > {}'.format(MID_THRESHOLD)),
                title_text='Set {} - Overscan std (Values > {})'.format(set_name, MID_THRESHOLD))
