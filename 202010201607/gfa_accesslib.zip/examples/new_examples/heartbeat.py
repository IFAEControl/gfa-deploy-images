#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
import logging
import time
import os

import argparse


IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT, APORT)

try:
    gfa.exposecontroller.remote_get_status()
    print(gfa.exposecontroller.status)

    # Check status
    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    # Set config to an IP that can't be reached from IFAE (normal networks allow PING outside of their networks)
    ans = gfa.heartbeat.remote_set_config(address='8.8.8.8', interval=1, retries=20)
    gfa.heartbeat.remote_update()
    assert gfa.heartbeat.status.address == '8.8.8.8', "configuration not correctly set"
    assert gfa.heartbeat.status.interval == 1, "configuration not correctly set"
    assert gfa.heartbeat.status.retries == 20, "configuration not correctly set"

    # enable heartbeat
    print("Enabling heartbeat to 8.8.8.8")
    ans = gfa.heartbeat.remote_enable_heartbeat()
    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    print('Checking errors on heartbeat: ', end='')
    for i in range(14):
        gfa.heartbeat.remote_update()
        print(f" {gfa.heartbeat.status.errors},", end='')
        time.sleep(0.5)
    print()

    # There should be 7 errors

    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    if gfa.heartbeat.status.errors < 7:
        print(f"There should be at least 7 errors, but there are {gfa.heartbeat.status.errors}")
        log.error('Wrong number of errors')

    # disable heartbeat
    ans = gfa.heartbeat.remote_disable_heartbeat()

    print("Changing heartbeat configuration to '127.0.0.1'")
    # Change config to a valid IP (localhost should never fail)
    ans = gfa.heartbeat.remote_set_config(address='127.0.0.1', interval=1, retries=20)

    # enable heartbeat
    ans = gfa.heartbeat.remote_enable_heartbeat()
    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    print('Checking errors on heartbeat: ', end='')
    for i in range(10):
        gfa.heartbeat.remote_update()
        print(f" {gfa.heartbeat.status.errors},", end='')
        time.sleep(1.01)

    # There should be 0 errors

    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    if gfa.heartbeat.status.errors > 0:
        log.error('Wrong number of errors')

    print('Disabling heartbeat')
    gfa.heartbeat.remote_disable_heartbeat()

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
