#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Otger Ballester"
__copyright__ = "Copyright 2020"
__credits__ = ["Otger Ballester"]
__license__ = "GPL"
__version__ = "1.0"
__maintainer__ = "Otger Ballester"
__email__ = "otger@ifae.es"
__status__ = "Production"

from gfaaccesslib.gfa import GFA
from gfaaccesslib.logger import log, formatter
from gfaaccesslib.api_helpers import GFAExposureLock
import logging
import time
import os

import argparse
from examples.new_examples.defaults import defaults


IP_GFA_PROTO = '172.16.17.82'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT


PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# There is no need to connect to ASYNC to configure the gfa
gfa = GFA(args.ip, PORT, APORT)

try:
    gfa.exposecontroller.remote_get_status()
    print(gfa.exposecontroller.status)

    # Check status
    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    # Set config to an IP that can't be reached from IFAE (normal networks allow PING outside of their networks)
    ans = gfa.heartbeat.remote_set_config(address='8.8.8.8', interval=1, retries=5)
    gfa.heartbeat.remote_update()
    assert gfa.heartbeat.status.address == '8.8.8.8', "configuration not correctly set"
    assert gfa.heartbeat.status.interval == 1, "configuration not correctly set"
    assert gfa.heartbeat.status.retries == 5, "configuration not correctly set"

    # Configure data tacking and launch image acquisition
    defaults.set_default_geom(gfa)

    defaults.set_default_timings(gfa)

    defaults.gfa_powerup_bias(gfa)  # only power up if needed
    print(f"GFA bias powered: {gfa.exposecontroller.status.is_powered}")

    defaults.init_adc(gfa)
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:

    print(f"last image id: {sorted(gfa.raws.list_images())[-1] if gfa.raws.list_images() else 'None'}")

    defaults.set_default_ccd_expose_stack(gfa, exposure_time_ms=50000)

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)

    acq_lock = GFAExposureLock()
    gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
    acq_lock.acquire()

    start_acq = time.time()
    # So we can launch the data taking
    print('Launching image acquisition')
    gfa.exposecontroller.remote_start_stack_exec()

    # enable heartbeat
    print("Enabling heartbeat to 8.8.8.8")
    ans = gfa.heartbeat.remote_enable_heartbeat()
    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    print('Waiting for image to end')

    # we wait, that should be done by registering at an async message (TBI)
    acq_lock.acquire()
    acq_lock.release()

    print(f'Image finished. Took {time.time()-start_acq:.3} seconds. It should be around 9 seconds if heartbeat \
            canceled and powered down bias')

    gfa.heartbeat.remote_update()
    print(gfa.heartbeat.status)

    if gfa.heartbeat.status.errors < 5:
        print(f"There should be at least 5 errors, but there are {gfa.heartbeat.status.errors}")
        log.error('Wrong number of errors')

    # disable heartbeat
    print('disabling heartbeat')
    ans = gfa.heartbeat.remote_disable_heartbeat()

    gfa.exposecontroller.remote_get_status()
    print(f"GFA bias powered: {gfa.exposecontroller.status.is_powered}")

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
