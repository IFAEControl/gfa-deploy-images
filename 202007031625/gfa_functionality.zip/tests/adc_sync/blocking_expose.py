#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log
from gfafunctionality.raws import RawImageFile
import json
import numpy as np
import sys
import os

__author__ = 'otger'

IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

prescan_cols = 0
overscan_cols = 0
amplifier_active_cols = 0

def image_start_cb(header, jsondata):
    global prescan_cols
    global overscan_cols
    global amplifier_active_cols
    if isinstance(jsondata, bytes):
        jsondata = jsondata.decode('UTF-8')
    j = json.loads(jsondata)

    prescan_cols = j['prescan_cols']
    overscan_cols = j['overscan_cols']
    amplifier_active_cols = j['amplifier_active_cols']


if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

gfa = GFA(IP, PORT, APORT)

acq_lock = GFAExposureLock()

gfa.async_manager.add_end_image_callback(acq_lock.async_callback_release)
gfa.async_manager.add_new_image_callback(image_start_cb)


def do_expose(storage, active):
    gfa.adccontroller.spi_write(0xf, 0x0)
    gfa.adccontroller.spi_write(0x2a, 0x0)
    gfa.adccontroller.adc_start_acq()
    g = gfa.clockmanager.stack

    g.clear()
    g.add_new_image_cmd()
    g.add_set_modes_cmd(True, True, True, True)
    g.add_wait_cmd(0)
    g.add_dump_rows_cmd(storage)
    g.add_read_rows_cmd(active)
    g.add_none_cmd()
    gfa.clockmanager.remote_set_stack_contents()
    gfa.buffers.remote_set_data_provider(0, 0)

    acq_lock.acquire()
    gfa.exposecontroller.remote_start_stack_exec()

    acq_lock.acquire()
    acq_lock.release()


try:
    do_expose(1024, 1024)
    im_num = sorted(gfa.raws.list_images())[-1]
    img = gfa.raws.get_image(im_num)
    amps = img.get_ampdata(-1)
    already_executed = False
    with open("noises.csv", "a") as myfile:
        for i in amps:
            overscan = []
            prescan = []
            img_10_per_100 = []
            img_100_per_10 = []
            counter = 0
            for j in i:
                overscan = overscan + j[-overscan_cols:].tolist()
                prescan = prescan + j[:prescan_cols].tolist()
                if 90 < counter < 100:
                    img_10_per_100 = img_10_per_100 + j[prescan_cols+10:prescan_cols + 10 + 100].tolist()
                if counter < 100:
                    img_100_per_10 = img_100_per_10 + j[prescan_cols+10:prescan_cols + 10 + 10].tolist()
                counter += 1
            prescan_std = np.std(prescan)
            overscan_std = np.std(overscan)
            img_10_per_100_std = np.std(img_10_per_100)
            myfile.write("{}, {}, {}, {}, {}, {}, {}".format(overscan_std, prescan_std, img_10_per_100_std,
                                                           np.average(img_10_per_100), np.std(img_100_per_10),
                                                           np.average(img_100_per_10), im_num))
            if already_executed is False and (prescan_std > 50 or overscan_std > 50 or img_10_per_100_std > 50):
                do_expose(560, 1)
                im_num = sorted(gfa.raws.list_images())[-1]
                img = gfa.raws.get_image(im_num)
                RawImageFile(img).save_to_files(path='waveforms', base_name=im_num-1, use_date=False)
                break

        myfile.write("\n")
    gfa.raws.rem_image(im_num)

    gfa.buffers.remote_clear_buffers()
except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
