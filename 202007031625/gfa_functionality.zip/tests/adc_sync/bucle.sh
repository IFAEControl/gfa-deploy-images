#!/bin/zsh
fail_ratio=0
succ_ratio=0

function register_fail() {
	fail_ratio=$((fail_ratio+1))
}

function register_succ() {
	succ_ratio=$((succ_ratio+1))
}

#for i in {1..2}; do
while true; do
	if python3.6 calib_test.py; then
		sleep 0.5
		if python3.6 blocking_expose.py 172.16.17.82 ; then
			register_succ
		else
			register_fail
		fi
	else
		register_fail
	fi
done

echo "Success: $succ_ratio"
echo "Failures: $fail_ratio"
