As of 2018.04.03 this are files that contains some scripts to analyze some data. They should evolve to selfcontained tests
