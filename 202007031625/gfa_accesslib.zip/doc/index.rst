.. gfaaccesslib documentation master file, created by
   sphinx-quickstart on Fri Jan 25 10:13:14 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to gfaaccesslib's documentation!
========================================

Notes
-----

.. toctree::
   :maxdepth: 2
   
   tutorial
   compatibility

.. toctree::
   :maxdepth: 6 
   :caption: Contents:

   modules

.. automodule:: gfaaccesslib



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
