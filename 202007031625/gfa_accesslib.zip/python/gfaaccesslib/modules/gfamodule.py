#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'otger'


class GFAModule(object):
    def __init__(self, communication_manager):
        self._comm = communication_manager

