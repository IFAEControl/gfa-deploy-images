#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import sys
import logging
import time
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1}".format(IP, PORT))
log.info('Configured GFA to ip {0} - port {1}'.format(IP, PORT))

# There is no need to subscribe to async port
gfa = GFA(IP, PORT)

# if len(sys.argv) == 3:
#     address = sys.argv[1]
#     value = sys.argv[2]
# else:
# address = 0x25
# value = 0x0010
# gfa.adccontroller.spi_write(address, value)
#
# address = 0x26
# for i in range(16):
#     value = 0xf << i
#     gfa.adccontroller.spi_write(address, value)
#     print "Written {0:4}".format(hex(value))
#     time.sleep(3)

pairs = [(0x0, 0x1),
         (0x0, 0x0),
         (0x46, 0x8801),
         (0x25, 0x2A),
         (0x26, 0xAAA8),
         (0x27, 0xAAA8)]
for (address, value) in pairs:
    gfa.adccontroller.spi_write(address, value)
    print("Written {0:4} to {1}".format(hex(value), hex(address)))
    time.sleep(0.5)
gfa.close()
