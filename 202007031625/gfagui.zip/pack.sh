#!/usr/bin/bash
tar -zcvf $(date +%Y%m%d_%H%M%S)-gfagui.tar.gz --exclude=.git --exclude=.idea --exclude=*.pyc -C .. gfagui
