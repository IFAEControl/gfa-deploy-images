from enum import IntEnum, auto

import gfa


class Action(IntEnum):
    CONNECT = auto()
    DISCONNECT = auto()
    CONFIGURE = auto()
    UNCONFIGURE = auto()


class ActionError(Exception):
    pass


class Disconnected:

    def get_new_state(self, action):
        if action == Action.CONNECT:
            return Connected()
        if action == Action.DISCONNECT: # Special case for when the GUI closes
            return self

        raise ActionError("Invalid action in this state: {}".format(action.name))


class Connected:

    def get_new_state(self, action):
        if action == Action.DISCONNECT:
            return Disconnected()
        elif action == Action.CONFIGURE:
            return Configured()

        raise ActionError("Invalid action in this state: {}".format(action.name))


class Configured:

    def get_new_state(self, action):
        if action == Action.UNCONFIGURE:
            return Connected()
        elif action == Action.DISCONNECT:
            return Disconnected()


class GFAStateMachine:

    def __init__(self):
        self._current_state = Disconnected()

    def action(self, action):
        self._current_state = self._current_state.get_new_state(action)
