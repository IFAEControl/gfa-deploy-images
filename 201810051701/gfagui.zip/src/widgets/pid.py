import json
from datetime import datetime

from PyQt5 import QtCore
from PyQt5.QtWidgets import QFrame

from pyqt_tools.plot_utils import build_plot

from .base import Widget
from .ui import pid_ui


class PID(Widget):
    update_plot_signal = QtCore.pyqtSignal(float, dict)

    def __init__(self, gfa):
        super(PID, self).__init__()
        self._gfa = gfa._gfa

        self._pid_frame = QFrame()
        self._pid = pid_ui.Ui_Frame()
        self._pid.setupUi(self._pid_frame)

        self.update_plot_signal.connect(self._on_signal_update)

        self._pid.enable_pid.clicked.connect(self._enable_pid)
        self._pid.disable_pid.clicked.connect(self._disable_pid)
        self._pid.enable_fixed_duty.clicked.connect(self._enable_fixed_duty)
        self._pid.disable_fixed_duty.clicked.connect(self._disable_fixed_duty)
        self._pid.get.clicked.connect(self._on_push_get)
        self._pid.set.clicked.connect(self._on_push_set)

        curve_names = ["Temperature", "Setpoint"]
        self._plot, self._curves = build_plot(self._pid.plot, "PID", "Temperature", "Time", "ºC", "s", curve_names)

        self._start = datetime.now()

        self._gfa.async.add_pid_callback(self._pid_callback)
        self._gfa.async.add_sensors_reading_callback(self._sensors_callback)

    def show(self):
        self._refresh_status()
        self._pid_frame.show()

    @QtCore.pyqtSlot(float, dict)
    def _on_signal_update(self, offset, data):
        s = ["sensor1t_value", "setpoint"]

        for c, t in zip(self._curves, s):
            val = data[t]
            c.append(offset, val)

        self._plot._plot.get_plot().set_scales("lin", "lin")

    def _pid_callback(self, header, data):
        if isinstance(data, bytes):
            data = data.decode('UTF-8')

        j = json.loads(data)

        self._pid.percentage.setText(str(j["percentage"]))
        self._pid.d_time.setText(str(j["d_time"]))
        self._pid.error.setText(str(j["error"]))
        self._pid.p_val.setText(str(j["p"]))
        self._pid.i_val.setText(str(j["i"]))
        self._pid.d_val.setText(str(j["d"]))

    def _sensors_callback(self, header, data):
        if isinstance(data, bytes):
            data = data.decode('UTF-8')

        j = json.loads(data)

        j["setpoint"] = self._gfa.pid.remote_get_setpoint().answer["setpoint"]

        offset = (datetime.now() - self._start).total_seconds()
        self.update_plot_signal.emit(offset, j)

    def _enable_pid(self):
        self._gfa.pid.remote_enable()
        self._refresh_status()

    def _disable_pid(self):
        self._gfa.pid.remote_disable()
        self._refresh_status()

    def _disable_fixed_duty(self):
        self._gfa.pid.remote_disable_fixed_duty_cycle()
        self._refresh_status()

    def _enable_fixed_duty(self):
        self._gfa.pid.remote_enable_fixed_duty_cycle()
        self._refresh_status()

    def _on_push_get(self):
        self._refresh_status()

    def _on_push_set(self):
        self._gfa.telemetry.remote_configure_sensors_autoupdate(int(10*self._pid.auto_update_period.value()))
        self._gfa.pid.remote_set_setpoint(self._pid.setpoint.value())

        kp = self._pid.kp.value()
        ki = self._pid.ki.value()
        kd = self._pid.kd.value()
        self._gfa.pid.remote_set_components(kp, ki, kd)

        self._gfa.pid.remote_fix_duty_cycle(self._pid.fixed_duty_value.value())

        self._gfa.pid.remote_set_max_duty_cycle(self._pid.max_duty.value())

        max = self._pid.max_integral_error.value()
        min = self._pid.min_integral_error.value()
        self._gfa.pid.remote_set_integral_error_limits(max, min)

        self._refresh_status()

    def _refresh_status(self):
        pid_k = self._gfa.pid.remote_get_components().answer
        self._pid.kp.setValue(pid_k["kp"])
        self._pid.ki.setValue(pid_k["ki"])
        self._pid.kd.setValue(pid_k["kd"])

        self._pid.fixed_duty_value.setValue(self._gfa.pid.remote_get_fixed_duty_cycle().answer["duty"])

        self._pid.max_duty.setValue(self._gfa.pid.remote_get_max_duty_cycle().answer["max_duty"])

        max, min = self._gfa.pid.remote_get_integral_error_limits().answer.values()
        self._pid.max_integral_error.setValue(max)
        self._pid.min_integral_error.setValue(min)

        self._pid.setpoint.setValue(self._gfa.pid.remote_get_setpoint().answer["setpoint"])
        self._pid.auto_update_period.setValue(self._gfa.telemetry.remote_get_configured_autoupdate().answer["period"]/10)

        if self._gfa.pid.remote_is_enabled().answer["enabled"]:
            t = "TRUE"
        else:
            t = "FALSE"
        self._pid.enabled_label.setText(t)

        if self._gfa.pid.remote_is_duty_cycle_fixed().answer["fixed"]:
            t = "TRUE"
        else:
            t = "FALSE"
        self._pid.is_fixed_duty.setText(t)

        high, low = self._gfa.telemetry.remote_get_pwm_registers().answer.values()
        self._pid.high_clocks.setText(str(high))
        self._pid.low_clocks.setText(str(low))

        pwm_vals = self._gfa.telemetry.remote_get_pwm().answer
        self._pid.frequency.setText(str(pwm_vals["freq"]))
        self._pid.duty_cycle.setText(str(pwm_vals["percentage"]))

