import os

from option_parse import AppOptions


class Config:
    def __init__(self):
        conf_desc = {
            "server_ip": {"default": ""},
            "images_dir": {"default": "/tmp"},
            "shut_down_on_close": {"default": True, "type": "bool"},
            "geometry": {
                "storage_rows": {"default": 512},
                "active_rows": {"default": 544},
                "prescan": {"default": 5},
                "overscan": {"default": 32},
                "columns": {"default": 1000},
            },
            "expose": {
                "mode": {"default": 0},
                "time": {"default": 0},
                "fake_data": {"default": True, "type": "bool"},
            },
            "adc": {
                "auto_calibrate": {"default": False, "type": "bool"},
                "delay": {"default": 60},
            },
            "timings": {
                "hor": {
                    "acq": {},
                    "del": {},
                    "overlap": {},
                    "postrg": {},
                    "prerg": {},
                    "rg": {},
                },
            },
            "discharge": {
                "duration": {"default": 0},
                "reset": {"default": False, "type": "bool"},
                "pixel": {"default": False, "type": "bool"},
                "auto_enable": {"default": False, "type": "bool"},
            },
            "offsets": {
                # Will be the same on amplifiers
                "value": {"default": "0", "type": "str"},
                "spd": {"default": False, "type": "bool"},
                "pwr": {"default": False, "type": "bool"},
                "auto_enable": {"default": False, "type": "bool"},
            },
        }

        self._opt = AppOptions("gfagui", "config", conf_desc, [])

    @property
    def images_dir(self):
        return self._opt["images_dir"]

    @images_dir.setter
    def images_dir(self, value):
        self._opt.set(value, "images_dir")

    @property
    def shut_down_on_close(self):
        return self._opt["shut_down_on_close"]

    @property
    def offsets_spd(self):
        return self._opt["offsets"]["spd"]

    @property
    def offsets_pwr(self):
        return self._opt["offsets"]["pwr"]

    @property
    def offsets_value(self):
        return self._opt["offsets"]["value"]

    @offsets_value.setter
    def offsets_value(self, value):
        self._opt.set(value, "offsets", "value")

    @property
    def auto_enable_offsets(self):
        return self._opt["offsets"]["auto_enable"]

    @auto_enable_offsets.setter
    def auto_enable_offsets(self, value):
        self._opt.set(value, "offsets", "auto_enable")

    @property
    def auto_enable_discharge(self):
        return self._opt["discharge"]["auto_enable"]

    @auto_enable_discharge.setter
    def auto_enable_discharge(self, value):
        self._opt.set(value, "discharge", "auto_enable")

    @property
    def discharge_duration(self):
        return self._opt["duration"]

    @discharge_duration.setter
    def discharge_duration(self, value):
        self._opt.set(value, "discarge", "duration")

    @property
    def discharge_pixel(self):
        return self._opt["pixel"]

    @discharge_pixel.setter
    def discharge_pixel(self, value):
        self._opt.set(value, "discarge", "pixel")

    @property
    def discharge_reset(self):
        return self._opt["reset"]

    @discharge_reset.setter
    def discharge_reset(self, value):
        self._opt.set(value, "discarge", "reset")

    @property
    def hor_overlap(self):
        return self._opt["overlap"]

    @hor_overlap.setter
    def hor_overlap(self, value):
        self._opt.set(value, "timings", "hor", "overlap" )

    @property
    def hor_postrg(self):
        return self._opt["postrg"]

    @hor_postrg.setter
    def hor_postrg(self, value):
        self._opt.set(value, "timings", "hor", "postrg")

    @property
    def hor_prerg(self):
        return self._opt["prerg"]

    @hor_prerg.setter
    def hor_prerg(self, value):
        self._opt.set(value, "timings", "hor", "prerg")

    @property
    def hor_rg(self):
        return self._opt["rg"]

    @hor_rg.setter
    def hor_rg(self, value):
        self._opt.set(value, "timings", "hor", "rg")

    @property
    def hor_del(self):
        return self._opt["del"]

    @hor_del.setter
    def hor_del(self, value):
        self._opt.set(value, "timings", "hor", "del")

    @property
    def hor_acq(self):
        return self._opt["acq"]

    @hor_acq.setter
    def hor_acq(self, value):
        self._opt.set(value, "timings", "hor", "acq")

    @property
    def auto_calibrate_adc(self):
        return self._opt["auto_calibrate"]

    @auto_calibrate_adc.setter
    def auto_calibrate_adc(self, value):
        self._opt.set(value, "adc", "auto_calibrate")

    @property
    def adc_delay(self):
        return self._opt["delay"]

    @adc_delay.setter
    def adc_delay(self, value):
        self._opt.set(value, "adc", "delay")

    @property
    def storage_rows(self):
        return self._opt["storage_rows"]

    @storage_rows.setter
    def storage_rows(self, value):
        self._opt.set(value, "geometry", "storage_rows")

    @property
    def active_rows(self):
        return self._opt["active_rows"]

    @active_rows.setter
    def active_rows(self, value):
        self._opt.set(value, "geometry", "active_rows")

    @property
    def prescan(self):
        return self._opt["prescan"]

    @prescan.setter
    def prescan(self, value):
        self._opt.set(value, "geometry", "prescan")

    @property
    def overscan(self):
        return self._opt["overscan"]

    @overscan.setter
    def overscan(self, value):
        self._opt.set(value, "geometry", "overscan")

    @property
    def columns(self):
        return self._opt["columns"]

    @columns.setter
    def columns(self, value):
        self._opt.set(value, "geometry", "columns")

    @property
    def server_ip(self):
        return self._opt["server_ip"]

    @server_ip.setter
    def server_ip(self, value):
        self._opt.set(value, "server_ip")

    @property
    def mode(self):
        return self._opt["mode"]

    @mode.setter
    def mode(self, value):
        self._opt.set(value, "expose", "mode")

    @property
    def expose_time(self):
        return self._opt["time"]

    @expose_time.setter
    def expose_time(self, value):
        self._opt.set(value, "expose", "time")

    @property
    def fake_data(self):
        return self._opt["fake_data"]

    @fake_data.setter
    def fake_data(self, value):
        self._opt.set(value, "expose", "fake_data")

