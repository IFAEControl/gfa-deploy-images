#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
import logging
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
from gfafunctionality.raws import RawImageFile, RawRepresentation
import time
import sys
import os
import argparse

__author__ = 'otger'

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("skip_rows", help="how many rows must be dumped", type=int)
parser.add_argument("skip_cols", help="how many columns must be skipped", type=int)
parser.add_argument("roi_width", help="width of the region of interest in columns", type=int)
parser.add_argument("roi_height", help="height of the region of interest in rows", type=int)
parser.add_argument("-o", "--read_overscan", help="read defined roi and overscan", action="store_true")
parser.add_argument("-t", "--exposure_time", type=int, help="exposure time in seconds", default=0)
parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
parser.add_argument("-r", "--raw_mode", help="Receive data in raw mode", action="store_true")
parser.add_argument("-s", "--split_mode", help="Receive data in split mode", action="store_true")
parser.add_argument("-f", "--save_to_file", help="save received data to file")
parser.add_argument("-d", "--display", action="store_true", help="display data received graphically")
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(args.ip, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:
    g = gfa.clockmanager.stack

    g.clear()
    # If we don't set an image_id, it will update its internal counter
    g.add_set_modes_cmd(True, True, True, True)
    # Clear CCD
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    # Expose CCD
    g.add_new_exposure_cmd(0)
    g.add_wait_cmd(args.exposure_time * 1000)
    # Dump rows
    g.add_dump_rows_cmd(args.skip_rows)
    g.add_set_roi_conf_cmd(skip_columns=args.skip_cols, roi_width=args.roi_width)
    if args.read_overscan:
        g.add_read_rows_roi_and_overscan_cmd(args.roi_height)
    else:
        g.add_read_rows_roi_cmd(args.roi_height)
    # dump other columns
    if gfa.clockmanager.geom_conf.total_rows > args.roi_height + args.skip_rows:
        g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows - args.roi_height - args.skip_rows)
    g.add_none_cmd()

    # Stack can be printed so we can see its contents and also translates its commands
    # to human
    print('Exposure stack contents: {0}'.format(g))

    # Then we have to set to GFA
    gfa.clockmanager.remote_set_stack_contents()

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    if args.raw_mode:
        gfa.buffers.remote_set_data_provider(0, 4)
    elif args.split_mode:
        gfa.buffers.remote_set_data_provider(0, 1)
    else:
        gfa.buffers.remote_set_data_provider(0, 0)

    # Locking mode
    acq_lock = GFAExposureLock()
    gfa.async.add_end_exposure_callback(acq_lock.async_callback_release)
    acq_lock.acquire()
    print('acquired')

    # So we can expose
    gfa.exposecontroller.remote_expose()

    acq_lock.acquire()
    print('acquired')
    acq_lock.release()
    print('released')

    # get last image
    im_num = sorted(gfa.raws.list_images())[-1]
    im = gfa.raws.get_image(im_num)
    for amp in im.amplifiers:
        print([row.data.size for row in amp.rows])
    # im.show_im()

    if args.save_to_file:
        if args.raw_mode:
            RawImageFile(im).save_waveform_table(path='.', base_name=args.save_to_file)
        else:
            RawImageFile(im).save_to_files(path='.', base_name=args.save_to_file)

    if args.display:
        if args.raw_mode:
            GUIQWTPlotter(im).show_as_waveform(maxWidth=2000, max_lines=1)
        else:
            GUIQWTPlotter(im, RawRepresentation(im)).show_image()
    # # If we were taking several images, probably it would be a good
    # # idea to remove images we don't need anymore
    # gfa.raws.rem_image(im_num)


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()

    print("If you plan to use RAW and capture several lines, remember to set generous times on _skip")
