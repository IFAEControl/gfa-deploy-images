#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.api import GFAApi
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import time
import logging
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
# log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

print("Connecting to GFAApi @{0}".format(IP))
log.info('Configured GFAApi to ip {0}'.format(IP))

IMAGE_ID = 3155413

# We want to receive data (which is sent through async path), so we must enable sync
api = GFAApi(IP, True)

# retrieve geom:
geom = api.get_ccd_geometry()
print(geom)

# We have to configure what kind of exposure do we want to take. We have several ways to configure an exposure

# We define each one of the steps:

# if we want to modify the one currently on the gfa:
stack = api.get_exposure_stack()
# if we want to start from scratch
stack = GFAExposureStack()

# A numerical image id can be set, otherwise, GFA has an internal counter that is increased at each exposure
# When GFA boots, this counter is reset to 0. Image id can be set for each exposure or only set the first one, but
# GFA needs that each exposure has a different id.
# All exposure definitions must start with a new exposure command
stack.add_new_exposure_cmd(IMAGE_ID)

# Make sure all 4 amplifiers are enabled and image and storage clocks are enabled
stack.add_set_modes_cmd(True, True, True, True)


# Clear the full CCD
stack.add_dump_rows_cmd(geom.total_rows)
# Wait for 1.5 seconds of exposure
stack.add_wait_cmd(1500)
# Dump storage while moving image area to storage
stack.add_dump_rows_cmd(geom.storage_rows)
# Read image rows
stack.add_read_rows_cmd(geom.image_rows)
# All exposure definitions must end with a  None command
stack.add_none_cmd()

# To check each of the steps that will executed on the GFA:
print(stack)

print("Using GFAStandardExposureBuilder")
#If we want to define a standard exposure
exposure_definition = GFAStandardExposureBuilder(gfageomconf=geom)
exposure_definition.integration_time = 1500
exposure_definition.clear_before_integrate = True
stack2 = exposure_definition.build()

print(stack)

# we set this configuration into GFA
api.set_exposure_stack(stack)

# Right now we have some problems to debug with blocking, momentarily, use a time.sleep
api.expose(blocking=False)

time.sleep(3)

raws = api.get_raw_manager()

# we can recover the image
im = raws.get_image(IMAGE_ID)
# and then we can see what have we received
im.show_im()


# Always close the GFA when you are subscribed to async channel
api.close()
