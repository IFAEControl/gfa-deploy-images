#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureStack, GFAStandardExposureBuilder, GFACCDGeom, GFAExposeMode
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

if len(sys.argv) > 1:
    IP = sys.argv[1]
else:
    IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
IP='131.243.51.10'
PORT = 32000
APORT = 32001

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(IP, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa.adccontroller.adc_start_acq()
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:
    g = gfa.clockmanager.stack

    g.clear()
    # If we don't set an image_id, it will update its internal counter
    g.add_new_exposure_cmd()
    g.add_set_modes_cmd(True, True, True, True)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    g.add_wait_cmd(10)
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.storage_rows)
    g.add_read_rows_cmd(gfa.clockmanager.geom_conf.image_rows)
    g.add_none_cmd()

    # Stack can be printed so we can see its contents and also translates its commands
    # to human
    print('Exposure stack contents: {0}'.format(g))

    # Then we have to set to GFA
    gfa.clockmanager.remote_set_stack_contents()

    # If we are playing with the simulator and want to receive something that is not
    # zeros, we have to set which pattern do we want:
    gfa.buffers.remote_set_data_provider(0, 0)

    # So we can expose
    gfa.exposecontroller.remote_expose()

    # we wait, that should be done by registering at an async message (TBI)
    time.sleep(6)

    # get last image
    im_num = sorted(gfa.raws.list_images())[-1]
    im = gfa.raws.get_image(im_num)
    im.show_im()

    # If we were taking several images, probably it would be a good
    # idea to remove images we don't need anymore
    gfa.raws.rem_image(im_num)

    gfa.buffers.remote_get_buffers_status()
    print(gfa.buffers.status)
    gfa.buffers.remote_clear_buffers()
    #  gfa.buffers.remote_get_buffers_status()
    #  print gfa.buffers.status

except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
