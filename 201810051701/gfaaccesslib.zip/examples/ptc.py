#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
import logging
import time
import sys
import os
import socket

LIGHT_HOST = '172.16.17.44'
LIGHT_PORT = 1000

OUTFILES_PATH = os.path.abspath(os.path.expanduser('~/Desktop/ptc'))
os.makedirs(OUTFILES_PATH, exist_ok=True)

__author__ = 'otger'

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

IP_EMBEDDED = '172.16.17.140'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO

IP = os.environ.get('GFA_IP', None) or IP_DEFAULT
PORT = 32000
APORT = 32001


class PiLight(object):
    def __init__(self, host, port):
        self.host = host
        self.port = port

    def send_cmd(self, cmd):

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((self.host, self.port))
            s.sendall(cmd.encode('UTF-8'))

    def switch_on(self):
        self.send_cmd('on')

    def switch_off(self):
        self.send_cmd('off')


def setup_gfa(gfa_instance, lock):
    gfa_instance.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Previously, gain was set to 12dB
    # gfa.adccontroller.spi_write(0x2a, 0xcccc)
    gfa_instance.adccontroller.adc_start_acq()

    gfa_instance.buffers.remote_set_data_provider(0, 0)
    gfa_instance.async.add_end_exposure_callback(lock.async_callback_release)


def clear_ccd(gfa, lock):
    lock.acquire('clear')
    g = gfa.clockmanager.stack
    g.clear()
    # g.add_new_exposure_cmd()
    g.add_dump_rows_cmd(1500)
    g.add_none_cmd()

    gfa.clockmanager.remote_set_stack_contents()
    gfa.exposecontroller.remote_expose()

    lock.acquire('clearwait')
    lock.release('clearwait')

    # time.sleep(1.0)


def read_ccd(gfa, rows, lock):
    lock.acquire('read')
    print('read')
    g = gfa.clockmanager.stack
    g.clear()
    g.add_new_exposure_cmd()
    g.add_read_rows_cmd(rows)
    g.add_none_cmd()

    gfa.clockmanager.remote_set_stack_contents()
    gfa.exposecontroller.remote_expose()

    lock.acquire('readwait')
    lock.release('readwait')


def process_image(gfa_instance, path, exp_time):
    # recover image
    im_num = sorted(gfa_instance.raws.list_images())[-1]
    im = gfa_instance.raws.get_image(im_num)
    # save image
    im.save_to_files(path=path, base_name='exposure_{0}_{1}s'.format(im_num, exp_time))
    # delete image
    gfa_instance.raws.rem_image(im_num)


def ptc(times, output_path, control_light=True):
    try:
        gfa = GFA(IP, PORT, APORT)

        acq_lock = GFAExposureLock()
        setup_gfa(gfa, acq_lock)
        light = PiLight(LIGHT_HOST, LIGHT_PORT)
        if control_light:
            light.switch_off()
        for t in times:
            print('Launching exposure {0} seconds'.format(t))
            gfa.buffers.remote_get_buffers_status()
            # print(gfa.buffers.status)
            gfa.buffers.remote_clear_buffers()
            clear_ccd(gfa, lock=acq_lock)
            if control_light:
                light.switch_on()
            time.sleep(t)
            if control_light:
                light.switch_off()
            read_ccd(gfa=gfa, rows=1024, lock=acq_lock)

            # time.sleep(2)
            print('going ahead')
            process_image(gfa_instance=gfa, path=output_path, exp_time=t)
            time.sleep(0.5)
    except Exception as ex:
        log.exception('Exception happened: {0}'.format(ex))
    finally:
        gfa.close()


def run_lineal(samples=10, factor=2):
    times = [factor*x for x in range(1, samples+1)]
    ptc(times=times, output_path=OUTFILES_PATH)


def run_exponential(max_time, samples=10):

        t = 1
        times = [1, ]
        factor = max_time**(1.0/(samples-1))
        for _ in range(samples-1):
            t *= factor
            times.append(t)

        ptc(times=times, output_path=OUTFILES_PATH)


if __name__ == "__main__":
    t = [1, ]*500
    ptc(times=t, output_path=OUTFILES_PATH, control_light=False)
