#!/usr/bin/python3
# -*- coding: utf-8 -*-
from gfaaccesslib.gfa import GFA
from gfaaccesslib.api_helpers import GFAExposureLock
from gfaaccesslib.logger import log, formatter
import logging
from gfafunctionality.guiqwt_plotter import GUIQWTPlotter
from gfafunctionality.raws import RawImageFile, RawRepresentation
import time
import sys
import os
import argparse

__author__ = 'otger'

IP_EMBEDDED = '172.16.17.141'
IP_HOME = '192.168.0.164'
IP_NODHCP = '192.168.100.100'
IP_GFA_PROTO = '172.16.17.54'
IP_DEFAULT = IP_GFA_PROTO
IP = os.environ.get('GFA_IP', None) or IP_DEFAULT

PORT = 32000
APORT = 32001

parser = argparse.ArgumentParser()

parser.add_argument("--skip-rows", help="how many rows must be dumped", type=int, default=600)
parser.add_argument("--rows", help="how many rows to read", type=int, default=1)
parser.add_argument("--ip", help="IP of the GFA to interface", default=IP)
parser.add_argument("-t", "--debug-phase-time", help="Debug phase duration in nanoseconds", type=int)
parser.add_argument("-r", "--debug-reset", help="Use tdebug for reset phase", action="store_true")
parser.add_argument("-e", "--debug-reference", help="Use tdebug for reference phase", action="store_true")
parser.add_argument("-s", "--debug-signal", help="Use tdebug for signal phase", action="store_true")
parser.add_argument("-f", "--save-to-file", help="save received data to file")
parser.add_argument("-d", "--display", action="store_true", help="display data received graphically")
args = parser.parse_args()

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
log.addHandler(ch)

print("Connecting to GFA @{0}:{1};{2}".format(IP, PORT, APORT))
log.info('Configured GFA to ip {0} - port {1} - async port {2}'.format(IP, PORT, APORT))

# To take an exposure an receive the data we need to connect also to ASYNC port
gfa = GFA(args.ip, PORT, APORT)
# It is critic to close the async thread when out of the script
try:
    # configure gfa with selected debug phase time
    gfa.clockmanager.remote_get_clock_timings()
    gfa.clockmanager.time_conf.debug_phase = args.debug_phase_time
    gfa.clockmanager.remote_set_clock_timings()


    gfa.adccontroller.spi_write(0xf, 0x0)
    # Set Gain of ADC to 0db
    gfa.adccontroller.spi_write(0x2a, 0x0)
    # Wake up adc
    gfa.adccontroller.adc_start_acq()
    # Before taking an exposure we have to define which exposure we want to take
    # we can do it manually, taking the stack and filling it:
    g = gfa.clockmanager.stack

    g.clear()
    # If we don't set an image_id, it will update its internal counter
    g.add_set_modes_cmd(True, True, True, True)
    # Clear CCD
    g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows)
    # Expose CCD
    g.add_new_exposure_cmd(0)
    # g.add_wait_cmd(args.exposure_time * 1000)
    # Dump rows
    g.add_dump_rows_cmd(args.skip_rows)
    g.add_read_rows_debug_mode_cmd(args.rows, debug_reset=args.debug_reset,
                                   debug_reference=args.debug_reference,
                                   debug_signal=args.debug_signal)
    # dump other columns
    if gfa.clockmanager.geom_conf.total_rows > args.rows + args.skip_rows:
        g.add_dump_rows_cmd(gfa.clockmanager.geom_conf.total_rows - args.rows - args.skip_rows)
    g.add_none_cmd()

    # Stack can be printed so we can see its contents and also translates its commands
    # to human
    log.info('Exposure stack contents: {0}'.format(g))

    # Then we have to set to GFA
    gfa.clockmanager.remote_set_stack_contents()


    # Configure datamanager to send raw data
    gfa.buffers.remote_set_data_provider(0, 4)

    # Locking mode
    acq_lock = GFAExposureLock()
    gfa.async.add_end_exposure_callback(acq_lock.async_callback_release)
    acq_lock.acquire()
    # print('acquired')

    # So we can expose
    gfa.exposecontroller.remote_expose()

    acq_lock.acquire()
    # print('acquired')
    acq_lock.release()
    # print('released')

    # get last image
    im_num = sorted(gfa.raws.list_images())[-1]
    im = gfa.raws.get_image(im_num)
    for amp in im.amplifiers:
        print([row.data.size for row in amp.rows])
    # im.show_im()

    if args.save_to_file:
        RawImageFile(im).save_waveform_table(path='.', base_name=args.save_to_file)

    if args.display:
        GUIQWTPlotter(im).show_as_waveform(maxWidth=2000, max_lines=1)
    # # If we were taking several images, probably it would be a good
    # # idea to remove images we don't need anymore
    # gfa.raws.rem_image(im_num)


except Exception as ex:
    log.exception("Exception")
    print("There has been an exception: {0}".format(ex))
finally:
    gfa.close()
